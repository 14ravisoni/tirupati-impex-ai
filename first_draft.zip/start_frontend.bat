@echo off
REM Start Frontend React Server
echo ========================================
echo Starting Frontend React Server
echo ========================================
echo.

cd frontend

REM Check if node_modules exists
if not exist "node_modules" (
    echo Installing dependencies...
    C:\tools\node_v20.19.5\npm.cmd install
    if %ERRORLEVEL% NEQ 0 (
        echo Error: Failed to install dependencies
        pause
        exit /b 1
    )
)

REM Start the server
echo Starting Vite development server...
echo Server will be available at: http://localhost:5173
echo.
C:\tools\node_v20.19.5\npm.cmd run dev

pause

