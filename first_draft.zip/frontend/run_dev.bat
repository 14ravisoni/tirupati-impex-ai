@echo off
REM Start development server using custom Node.js installation

set NODE_PATH=C:\tools\node_v20.19.5
set PATH=%NODE_PATH%;%PATH%

if not exist "%NODE_PATH%\npm.cmd" (
    echo Error: Node.js not found at %NODE_PATH%
    echo Please verify the Node.js installation path.
    pause
    exit /b 1
)

if not exist "node_modules" (
    echo node_modules not found. Installing dependencies...
    "%NODE_PATH%\npm.cmd" install
)

echo Starting development server...
echo.
"%NODE_PATH%\npm.cmd" run dev

