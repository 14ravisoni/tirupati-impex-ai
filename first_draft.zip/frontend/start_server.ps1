# Frontend Server Start/Restart Script
# Checks if server is running, restarts if running, starts if not

$NODE_PATH = "C:\tools\node_v20.19.5"
$PORT = 5173
$FRONTEND_DIR = $PSScriptRoot

Write-Host "========================================" -ForegroundColor Cyan
Write-Host "Tirupati Impex - Frontend Server" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""

# Check if Node.js exists
if (-not (Test-Path "$NODE_PATH\node.exe")) {
    Write-Host "Error: Node.js not found at $NODE_PATH" -ForegroundColor Red
    Write-Host "Please verify the Node.js installation path." -ForegroundColor Yellow
    exit 1
}

# Function to check if port is in use
function Test-Port {
    param([int]$Port)
    $connection = Test-NetConnection -ComputerName localhost -Port $Port -WarningAction SilentlyContinue
    return $connection.TcpTestSucceeded
}

# Function to find and kill processes using the port
function Stop-PortProcess {
    param([int]$Port)
    try {
        $processes = Get-NetTCPConnection -LocalPort $Port -ErrorAction SilentlyContinue | 
            Select-Object -ExpandProperty OwningProcess -Unique
        
        if ($processes) {
            foreach ($pid in $processes) {
                $proc = Get-Process -Id $pid -ErrorAction SilentlyContinue
                if ($proc) {
                    Write-Host "Stopping process: $($proc.ProcessName) (PID: $pid)" -ForegroundColor Yellow
                    Stop-Process -Id $pid -Force -ErrorAction SilentlyContinue
                }
            }
            Start-Sleep -Seconds 2
        }
    } catch {
        # If Get-NetTCPConnection fails, try alternative method
        $netstat = netstat -ano | findstr ":$Port"
        if ($netstat) {
            $pids = $netstat | ForEach-Object {
                if ($_ -match '\s+(\d+)$') {
                    $matches[1]
                }
            } | Select-Object -Unique
            
            foreach ($pid in $pids) {
                try {
                    $proc = Get-Process -Id $pid -ErrorAction SilentlyContinue
                    if ($proc -and $proc.ProcessName -eq "node") {
                        Write-Host "Stopping Node.js process (PID: $pid)" -ForegroundColor Yellow
                        Stop-Process -Id $pid -Force -ErrorAction SilentlyContinue
                    }
                } catch {}
            }
            Start-Sleep -Seconds 2
        }
    }
}

# Check if server is running
Write-Host "Checking if frontend server is running on port $PORT..." -ForegroundColor Yellow
$isRunning = Test-Port -Port $PORT

if ($isRunning) {
    Write-Host "Server is already running on port $PORT" -ForegroundColor Green
    Write-Host "Restarting server..." -ForegroundColor Yellow
    Stop-PortProcess -Port $PORT
    Start-Sleep -Seconds 2
} else {
    Write-Host "Server is not running" -ForegroundColor Yellow
    Write-Host "Starting server..." -ForegroundColor Yellow
}

# Check if node_modules exists
if (-not (Test-Path "$FRONTEND_DIR\node_modules")) {
    Write-Host ""
    Write-Host "Dependencies not found. Installing..." -ForegroundColor Yellow
    & "$NODE_PATH\npm.cmd" install
    if ($LASTEXITCODE -ne 0) {
        Write-Host "Failed to install dependencies!" -ForegroundColor Red
        exit 1
    }
    Write-Host "Dependencies installed successfully!" -ForegroundColor Green
    Write-Host ""
}

# Change to frontend directory
Set-Location $FRONTEND_DIR

# Start the server
Write-Host "Starting Vite development server..." -ForegroundColor Cyan
Write-Host "Server will be available at: http://localhost:$PORT" -ForegroundColor Green
Write-Host ""
Write-Host "Press Ctrl+C to stop the server" -ForegroundColor Yellow
Write-Host ""

# Set PATH for this session
$env:PATH = "$NODE_PATH;$env:PATH"

# Start the server
& "$NODE_PATH\npm.cmd" run dev

