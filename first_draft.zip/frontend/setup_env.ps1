# Setup script for Node.js environment
# Run this script before using npm commands

$nodePath = "C:\tools\node_v20.19.5"
$npmPath = "$nodePath\npm.cmd"

# Add Node.js to PATH for this session
$env:PATH = "$nodePath;$env:PATH"

Write-Host "Node.js environment configured!" -ForegroundColor Green
Write-Host "Node.js path: $nodePath" -ForegroundColor Cyan
Write-Host ""
Write-Host "Verifying installation..." -ForegroundColor Yellow

# Verify Node.js
& "$nodePath\node.exe" --version
& "$nodePath\npm.cmd" --version

Write-Host ""
Write-Host "You can now run npm commands!" -ForegroundColor Green
Write-Host "Example: npm install" -ForegroundColor Cyan

