# Install Node.js and npm

Node.js is required to build and run the React frontend application.

## Installation Steps

### Option 1: Download from Official Website (Recommended)

1. **Visit Node.js website:**
   - Go to: https://nodejs.org/
   - Download the **LTS (Long Term Support)** version
   - Choose the Windows Installer (.msi) for your system (64-bit recommended)

2. **Run the Installer:**
   - Double-click the downloaded `.msi` file
   - Follow the installation wizard
   - **Important:** Make sure to check "Add to PATH" option during installation
   - Click "Install" and wait for completion

3. **Verify Installation:**
   - Close and reopen your terminal/PowerShell
   - Run these commands:
   ```powershell
   node --version
   npm --version
   ```
   - You should see version numbers (e.g., `v20.x.x` and `10.x.x`)

### Option 2: Using Chocolatey (If you have it)

If you have Chocolatey package manager installed:

```powershell
choco install nodejs-lts
```

### Option 3: Using Winget (Windows 11)

```powershell
winget install OpenJS.NodeJS.LTS
```

## After Installation

1. **Restart your terminal/PowerShell** (important for PATH to update)

2. **Verify installation:**
   ```powershell
   node --version
   npm --version
   ```

3. **Once Node.js is installed, you can create the frontend project:**
   ```powershell
   cd C:\Work\test_project_cursor
   npm create vite@latest frontend -- --template react-ts
   ```

## Troubleshooting

### If commands still don't work after installation:

1. **Restart your computer** (sometimes required for PATH changes)
2. **Check PATH manually:**
   - Press `Win + R`, type `sysdm.cpl`, press Enter
   - Go to "Advanced" tab → "Environment Variables"
   - Under "System variables", find "Path"
   - Make sure `C:\Program Files\nodejs\` is in the list
   - If not, add it and restart terminal

### Verify Node.js Installation Location

Node.js is typically installed at:
- `C:\Program Files\nodejs\` (64-bit)
- `C:\Program Files (x86)\nodejs\` (32-bit)

You can manually add this to PATH if needed.

## Next Steps

Once Node.js is installed:
1. Close and reopen your terminal
2. Navigate to project directory: `cd C:\Work\test_project_cursor`
3. Run: `npm create vite@latest frontend -- --template react-ts`
4. Follow the prompts to create the React project

