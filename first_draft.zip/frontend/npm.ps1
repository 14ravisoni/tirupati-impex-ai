# npm wrapper script for custom Node.js installation
param(
    [Parameter(ValueFromRemainingArguments=$true)]
    [string[]]$Arguments
)

$nodePath = "C:\tools\node_v20.19.5"
$npmPath = "$nodePath\npm.cmd"

if (-not (Test-Path $npmPath)) {
    Write-Host "Error: Node.js not found at $nodePath" -ForegroundColor Red
    Write-Host "Please verify the Node.js installation path." -ForegroundColor Yellow
    exit 1
}

# Add Node.js to PATH for this session
$env:PATH = "$nodePath;$env:PATH"

# Run npm with all arguments
& $npmPath $Arguments

