@echo off
REM Frontend Server Start/Restart Script for CMD
REM Checks if server is running, restarts if running, starts if not

set NODE_PATH=C:\tools\node_v20.19.5
set PORT=5173

echo ========================================
echo Tirupati Impex - Frontend Server
echo ========================================
echo.

REM Check if Node.js exists
if not exist "%NODE_PATH%\node.exe" (
    echo Error: Node.js not found at %NODE_PATH%
    echo Please verify the Node.js installation path.
    pause
    exit /b 1
)

REM Check if port is in use and kill the process
echo Checking if frontend server is running on port %PORT%...
netstat -ano | findstr ":%PORT%" >nul
if %ERRORLEVEL% EQU 0 (
    echo Server is already running on port %PORT%
    echo Stopping existing server...
    for /f "tokens=5" %%a in ('netstat -ano ^| findstr ":%PORT%"') do (
        taskkill /F /PID %%a >nul 2>&1
    )
    timeout /t 2 /nobreak >nul
) else (
    echo Server is not running
)

echo Starting server...
echo.

REM Check if node_modules exists
if not exist "node_modules" (
    echo Dependencies not found. Installing...
    "%NODE_PATH%\npm.cmd" install
    if %ERRORLEVEL% NEQ 0 (
        echo Failed to install dependencies!
        pause
        exit /b 1
    )
    echo Dependencies installed successfully!
    echo.
)

REM Set PATH for this session
set PATH=%NODE_PATH%;%PATH%

REM Start the server
echo Starting Vite development server...
echo Server will be available at: http://localhost:%PORT%
echo.
echo Press Ctrl+C to stop the server
echo.

"%NODE_PATH%\npm.cmd" run dev

