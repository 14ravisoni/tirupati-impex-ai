@echo off
REM npm wrapper batch script for custom Node.js installation

set NODE_PATH=C:\tools\node_v20.19.5
set PATH=%NODE_PATH%;%PATH%

if not exist "%NODE_PATH%\npm.cmd" (
    echo Error: Node.js not found at %NODE_PATH%
    echo Please verify the Node.js installation path.
    exit /b 1
)

"%NODE_PATH%\npm.cmd" %*

