# Quick Start Guide

## Step 1: Install Dependencies

Run the installation script:

```cmd
install.bat
```

Or manually:
```cmd
npm.bat install
```

## Step 2: Start Development Server

Run the development server:

```cmd
run_dev.bat
```

Or manually:
```cmd
npm.bat run dev
```

The app will be available at: **http://localhost:5173**

## Step 3: Test the Application

### As Client:

1. **Register a new client account:**
   - Go to http://localhost:5173/register
   - Fill in the registration form
   - You'll be automatically logged in

2. **Login (if already registered):**
   - Go to http://localhost:5173/login
   - Use your email and password

3. **Client Dashboard Features:**
   - View statistics
   - Add Workers
   - Create Jewels
   - Create and Assign Jobs
   - Manage Inventory (Add/Withdraw Metal & Points)
   - Create Sales
   - View all Jobs and their status
   - Approve or Send Back jobs submitted by workers

### As Worker:

1. **Login as Worker:**
   - Open a different browser or incognito window
   - Go to http://localhost:5173/login
   - Use worker credentials (created by client)

2. **Worker Dashboard Features:**
   - View statistics
   - See assigned jobs
   - Accept/Reject job assignments
   - Start jobs
   - Submit jobs for review
   - View job history

## Features Checklist

✅ Client Registration
✅ Client Login
✅ Add Workers
✅ Create Jewels
✅ Create and Assign Jobs
✅ Worker Login (separate browser)
✅ Worker Accept/Reject Jobs
✅ Worker Start Jobs
✅ Worker Submit Jobs
✅ Client View All Jobs
✅ Client Approve/Send Back Jobs
✅ Move Jobs Through Stages
✅ Complete/Sell Jewels
✅ Statistics in Both Portals
✅ Inventory Management
✅ Sales Management
✅ Notifications

## Troubleshooting

### Backend Not Running
- Make sure Django server is running on http://127.0.0.1:8000
- Check backend logs for errors

### CORS Errors
- Ensure backend CORS is configured correctly
- Check that `CORS_ALLOW_ALL_ORIGINS = True` in development settings

### API Connection Issues
- Verify `.env` file has correct `VITE_API_BASE_URL`
- Check browser console for API errors

