@echo off
REM Install dependencies using custom Node.js installation

set NODE_PATH=C:\tools\node_v20.19.5
set PATH=%NODE_PATH%;%PATH%

echo ========================================
echo Tirupati Impex Frontend - Installation
echo ========================================
echo.

if not exist "%NODE_PATH%\npm.cmd" (
    echo Error: Node.js not found at %NODE_PATH%
    echo Please verify the Node.js installation path.
    pause
    exit /b 1
)

echo Verifying Node.js installation...
"%NODE_PATH%\node.exe" --version
"%NODE_PATH%\npm.cmd" --version
echo.

echo Installing dependencies...
echo This may take a few minutes...
echo.

"%NODE_PATH%\npm.cmd" install

if %ERRORLEVEL% EQU 0 (
    echo.
    echo ========================================
    echo Installation completed successfully!
    echo ========================================
    echo.
    echo To start the development server, run:
    echo   npm run dev
    echo.
) else (
    echo.
    echo ========================================
    echo Installation failed!
    echo ========================================
    echo.
)

pause

