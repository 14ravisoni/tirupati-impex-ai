// User Types
export interface User {
  id: string;
  email: string;
  userType: 'client' | 'worker';
  phone?: string;
  created_at: string;
  client_profile?: ClientProfile;
  worker_profile?: WorkerProfile;
}

export interface ClientProfile {
  id: string;
  business_name: string;
  full_name: string;
  address?: string;
  metal_inventory: string;
  points_inventory: string;
  created_at: string;
}

export interface WorkerProfile {
  id: string;
  email?: string;
  phone?: string;
  full_name: string;
  nickname?: string;
  client: string;
  is_active?: boolean;
  total_jobs_assigned?: number;
  total_jobs_accepted?: number;
  total_jobs_rejected?: number;
  total_jobs_completed?: number;
  acceptance_rate?: number;
  created_at: string;
}

// Authentication Types
export interface LoginCredentials {
  email: string;
  password: string;
}

export interface RegisterData {
  email: string;
  password: string;
  business_name: string;
  full_name: string;
  phone?: string;
  address?: string;
}

export interface AuthResponse {
  access: string;
  refresh: string;
  user: User;
}

// Jewel Types
export interface Jewel {
  id: string;
  client: string;
  jewel_type: string;
  current_stage: JewelStage;
  ghatt_weight: string;
  stone_weight: string;
  net_weight: string;
  metal_weight: string;
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

export type JewelStage = 
  | 'ghatt' 
  | 'jadai' 
  | 'polish' 
  | 'stone_setting' 
  | 'final_polish' 
  | 'quality_check' 
  | 'ready_to_sell' 
  | 'sold';

// Job Types
export interface Job {
  id: string;
  jewel: string;
  jewel_details?: Jewel;
  client: string;
  worker: string;
  worker_details?: WorkerProfile;
  job_stage: JewelStage;
  status: JobStatus;
  job_description?: string;
  before_weight?: string;
  after_weight?: string;
  notes?: string;
  accepted_at?: string;
  started_at?: string;
  submitted_at?: string;
  completed_at?: string;
  client_send_back_count: number;
  created_at: string;
  updated_at: string;
}

export type JobStatus = 
  | 'pending_acceptance'
  | 'accepted'
  | 'rejected'
  | 'in_progress'
  | 'submitted_for_review'
  | 'sent_back_by_client'
  | 'completed';

// Inventory Types
export interface InventoryTransaction {
  id: string;
  client: string;
  transaction_type: 'add_metal' | 'withdraw_metal' | 'add_points' | 'withdraw_points';
  metal_amount?: string;
  points_amount?: string;
  balance_after_metal: string;
  balance_after_points: string;
  notes?: string;
  created_at: string;
}

// Sales Types
export interface Sale {
  id: string;
  jewel: string;
  jewel_details?: Jewel;
  client: string;
  buyer_name: string;
  buyer_phone?: string;
  buyer_type: 'retailer' | 'customer';
  payment_method: 'metal' | 'points' | 'cash';
  metal_amount?: string;
  points_amount?: string;
  final_amount: string;
  gold_price_per_gram?: string;
  created_at: string;
}

// Notification Types
export interface Notification {
  id: string;
  user: string;
  notification_type: string;
  title: string;
  message: string;
  is_read: boolean;
  created_at: string;
}

// Statistics Types
export interface ClientStatistics {
  total_jewels: number;
  jewels_by_stage: Record<JewelStage, number>;
  total_jobs: number;
  jobs_by_status: Record<JobStatus, number>;
  total_workers: number;
  active_workers: number;
  total_sales: number;
  total_revenue: string;
  metal_inventory: string;
  points_inventory: string;
}

export interface WorkerStatistics {
  total_jobs_assigned: number;
  jobs_by_status: Record<JobStatus, number>;
  acceptance_rate: number;
  completion_rate: number;
  average_completion_time?: number;
  total_jobs_completed: number;
}

// API Response Types
export interface ApiError {
  detail?: string;
  message?: string;
  [key: string]: any;
}

export interface PaginatedResponse<T> {
  count: number;
  next: string | null;
  previous: string | null;
  results: T[];
}

