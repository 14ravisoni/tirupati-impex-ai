import { useEffect, useState } from 'react';
import {
  Box,
  Button,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  Typography,
  Paper,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  IconButton,
  Chip,
} from '@mui/material';
import { Add, Edit, Delete } from '@mui/icons-material';
import { workerService } from '../../services/workerService';
import { WorkerProfile } from '../../types';
import { Loading } from '../../components/Loading';
import { ErrorAlert } from '../../components/ErrorAlert';
import { SuccessAlert } from '../../components/SuccessAlert';

export const WorkersPage = () => {
  const [workers, setWorkers] = useState<WorkerProfile[]>([]);
  const [loading, setLoading] = useState(true);
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<WorkerProfile | null>(null);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [formData, setFormData] = useState({
    email: '',
    password: '',
    full_name: '',
    nickname: '',
    phone: '',
  });

  useEffect(() => {
    loadWorkers();
  }, []);

  const loadWorkers = async () => {
    try {
      const data = await workerService.getWorkers();
      setWorkers(data);
    } catch (error) {
      setError('Failed to load workers');
    } finally {
      setLoading(false);
    }
  };

  const handleOpen = (worker?: WorkerProfile) => {
    if (worker) {
      setEditing(worker);
      setFormData({
        email: worker.email || '',
        password: '',
        full_name: worker.full_name,
        nickname: worker.nickname || '',
        phone: worker.phone || '',
      });
    } else {
      setEditing(null);
      setFormData({
        email: '',
        password: '',
        full_name: '',
        nickname: '',
        phone: '',
      });
    }
    setOpen(true);
  };

  const handleClose = () => {
    setOpen(false);
    setEditing(null);
    setFormData({
      email: '',
      password: '',
      full_name: '',
      nickname: '',
      phone: '',
    });
  };

  const handleSubmit = async () => {
    try {
      setError('');
      if (editing) {
        await workerService.updateWorker(editing.id, {
          full_name: formData.full_name,
          nickname: formData.nickname,
        });
        setSuccess('Worker updated successfully');
      } else {
        await workerService.createWorker(formData);
        setSuccess('Worker created successfully');
      }
      handleClose();
      loadWorkers();
      setTimeout(() => setSuccess(''), 3000);
    } catch (err: any) {
      setError(err.response?.data?.detail || 'Operation failed');
    }
  };

  const handleDelete = async (id: string) => {
    if (window.confirm('Are you sure you want to deactivate this worker?')) {
      try {
        await workerService.deactivateWorker(id);
        setSuccess('Worker deactivated successfully');
        loadWorkers();
        setTimeout(() => setSuccess(''), 3000);
      } catch (err: any) {
        setError(err.response?.data?.detail || 'Failed to deactivate worker');
      }
    }
  };

  if (loading) return <Loading />;

  return (
    <Box>
      <Box display="flex" justifyContent="space-between" alignItems="center" mb={3}>
        <Typography variant="h4">Workers</Typography>
        <Button variant="contained" startIcon={<Add />} onClick={() => handleOpen()}>
          Add Worker
        </Button>
      </Box>

      {error && <ErrorAlert message={error} onClose={() => setError('')} />}
      {success && <SuccessAlert message={success} onClose={() => setSuccess('')} />}

      <TableContainer component={Paper}>
        <Table>
          <TableHead>
            <TableRow>
              <TableCell>Name</TableCell>
              <TableCell>Nickname</TableCell>
              <TableCell>Email</TableCell>
              <TableCell>Phone</TableCell>
              <TableCell>Status</TableCell>
              <TableCell>Actions</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {workers.map((worker) => (
              <TableRow key={worker.id}>
                <TableCell>{worker.full_name}</TableCell>
                <TableCell>{worker.nickname || '-'}</TableCell>
                <TableCell>{worker.email || '-'}</TableCell>
                <TableCell>{worker.phone || '-'}</TableCell>
                <TableCell>
                  <Chip
                    label={worker.is_active !== false ? 'Active' : 'Inactive'}
                    color={worker.is_active !== false ? 'success' : 'default'}
                    size="small"
                  />
                </TableCell>
                <TableCell>
                  <IconButton size="small" onClick={() => handleOpen(worker)}>
                    <Edit />
                  </IconButton>
                  <IconButton
                    size="small"
                    onClick={() => handleDelete(worker.id)}
                    color="error"
                  >
                    <Delete />
                  </IconButton>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </TableContainer>

      <Dialog open={open} onClose={handleClose} maxWidth="sm" fullWidth>
        <DialogTitle>{editing ? 'Edit Worker' : 'Add New Worker'}</DialogTitle>
        <DialogContent>
          <Box sx={{ pt: 1 }}>
            <TextField
              fullWidth
              label="Email"
              type="email"
              value={formData.email}
              onChange={(e) => setFormData({ ...formData, email: e.target.value })}
              margin="normal"
              required
              disabled={!!editing}
            />
            {!editing && (
              <TextField
                fullWidth
                label="Password"
                type="password"
                value={formData.password}
                onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                margin="normal"
                required
              />
            )}
            <TextField
              fullWidth
              label="Full Name"
              value={formData.full_name}
              onChange={(e) => setFormData({ ...formData, full_name: e.target.value })}
              margin="normal"
              required
            />
            <TextField
              fullWidth
              label="Nickname"
              value={formData.nickname}
              onChange={(e) => setFormData({ ...formData, nickname: e.target.value })}
              margin="normal"
            />
            <TextField
              fullWidth
              label="Phone"
              value={formData.phone}
              onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
              margin="normal"
            />
          </Box>
        </DialogContent>
        <DialogActions>
          <Button onClick={handleClose}>Cancel</Button>
          <Button onClick={handleSubmit} variant="contained">
            {editing ? 'Update' : 'Create'}
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};

