import { useEffect, useState } from 'react';
import {
  Box,
  Button,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  Typography,
  Paper,
  Grid,
  Card,
  CardContent,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Tabs,
  Tab,
} from '@mui/material';
import { Add, Remove } from '@mui/icons-material';
import { inventoryService } from '../../services/inventoryService';
import { InventoryTransaction } from '../../types';
import { Loading } from '../../components/Loading';
import { ErrorAlert } from '../../components/ErrorAlert';
import { SuccessAlert } from '../../components/SuccessAlert';
import { formatDateTime } from '../../utils/dateUtils';

export const InventoryPage = () => {
  const [inventory, setInventory] = useState({ metal: '0', points: '0' });
  const [transactions, setTransactions] = useState<InventoryTransaction[]>([]);
  const [loading, setLoading] = useState(true);
  const [tab, setTab] = useState(0);
  const [open, setOpen] = useState(false);
  const [transactionType, setTransactionType] = useState<'add_metal' | 'withdraw_metal' | 'add_points' | 'withdraw_points'>('add_metal');
  const [formData, setFormData] = useState({ amount: '', notes: '' });
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const [inventoryData, transactionsData] = await Promise.all([
        inventoryService.getCurrentInventory(),
        inventoryService.getTransactions(),
      ]);
      setInventory(inventoryData);
      setTransactions(transactionsData);
    } catch (error) {
      setError('Failed to load inventory data');
    } finally {
      setLoading(false);
    }
  };

  const handleOpen = (type: typeof transactionType) => {
    setTransactionType(type);
    setFormData({ amount: '', notes: '' });
    setOpen(true);
  };

  const handleClose = () => {
    setOpen(false);
    setFormData({ amount: '', notes: '' });
  };

  const handleSubmit = async () => {
    try {
      setError('');
      const amount = parseFloat(formData.amount);
      if (isNaN(amount) || amount <= 0) {
        setError('Please enter a valid amount');
        return;
      }

      if (transactionType === 'add_metal') {
        await inventoryService.addMetal(amount, formData.notes);
      } else if (transactionType === 'withdraw_metal') {
        await inventoryService.withdrawMetal(amount, formData.notes);
      } else if (transactionType === 'add_points') {
        await inventoryService.addPoints(amount, formData.notes);
      } else {
        await inventoryService.withdrawPoints(amount, formData.notes);
      }

      setSuccess('Transaction completed successfully');
      handleClose();
      loadData();
      setTimeout(() => setSuccess(''), 3000);
    } catch (err: any) {
      setError(err.response?.data?.detail || 'Transaction failed');
    }
  };

  if (loading) return <Loading />;

  return (
    <Box>
      <Typography variant="h4" gutterBottom>
        Inventory Management
      </Typography>

      {error && <ErrorAlert message={error} onClose={() => setError('')} />}
      {success && <SuccessAlert message={success} onClose={() => setSuccess('')} />}

      <Grid container spacing={3} sx={{ mt: 2 }}>
        <Grid item xs={12} md={6}>
          <Card>
            <CardContent>
              <Box display="flex" justifyContent="space-between" alignItems="center" mb={2}>
                <Typography variant="h6">Metal Inventory</Typography>
                <Box>
                  <Button
                    size="small"
                    startIcon={<Add />}
                    onClick={() => handleOpen('add_metal')}
                    sx={{ mr: 1 }}
                  >
                    Add
                  </Button>
                  <Button
                    size="small"
                    startIcon={<Remove />}
                    onClick={() => handleOpen('withdraw_metal')}
                    color="error"
                  >
                    Withdraw
                  </Button>
                </Box>
              </Box>
              <Typography variant="h4">
                {parseFloat(inventory.metal).toFixed(3)} g
              </Typography>
            </CardContent>
          </Card>
        </Grid>
        <Grid item xs={12} md={6}>
          <Card>
            <CardContent>
              <Box display="flex" justifyContent="space-between" alignItems="center" mb={2}>
                <Typography variant="h6">Points Inventory</Typography>
                <Box>
                  <Button
                    size="small"
                    startIcon={<Add />}
                    onClick={() => handleOpen('add_points')}
                    sx={{ mr: 1 }}
                  >
                    Add
                  </Button>
                  <Button
                    size="small"
                    startIcon={<Remove />}
                    onClick={() => handleOpen('withdraw_points')}
                    color="error"
                  >
                    Withdraw
                  </Button>
                </Box>
              </Box>
              <Typography variant="h4">
                ₹{parseFloat(inventory.points).toFixed(2)}
              </Typography>
            </CardContent>
          </Card>
        </Grid>
      </Grid>

      <Paper sx={{ mt: 3 }}>
        <Typography variant="h6" sx={{ p: 2 }}>
          Transaction History
        </Typography>
        <TableContainer>
          <Table>
            <TableHead>
              <TableRow>
                <TableCell>Type</TableCell>
                <TableCell>Amount</TableCell>
                <TableCell>Balance After</TableCell>
                <TableCell>Notes</TableCell>
                <TableCell>Date</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {transactions.map((transaction) => (
                <TableRow key={transaction.id}>
                  <TableCell>
                    {transaction.transaction_type.replace('_', ' ').toUpperCase()}
                  </TableCell>
                  <TableCell>
                    {transaction.metal_amount
                      ? `${transaction.metal_amount} g`
                      : `₹${transaction.points_amount}`}
                  </TableCell>
                  <TableCell>
                    {transaction.metal_amount
                      ? `${transaction.balance_after_metal} g`
                      : `₹${transaction.balance_after_points}`}
                  </TableCell>
                  <TableCell>{transaction.notes || '-'}</TableCell>
                  <TableCell>{formatDateTime(transaction.created_at)}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TableContainer>
      </Paper>

      <Dialog open={open} onClose={handleClose}>
        <DialogTitle>
          {transactionType.includes('add') ? 'Add' : 'Withdraw'}{' '}
          {transactionType.includes('metal') ? 'Metal' : 'Points'}
        </DialogTitle>
        <DialogContent>
          <TextField
            fullWidth
            label={`Amount ${transactionType.includes('metal') ? '(grams)' : '(₹)'}`}
            type="number"
            value={formData.amount}
            onChange={(e) => setFormData({ ...formData, amount: e.target.value })}
            margin="normal"
            required
          />
          <TextField
            fullWidth
            label="Notes"
            value={formData.notes}
            onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
            margin="normal"
            multiline
            rows={3}
          />
        </DialogContent>
        <DialogActions>
          <Button onClick={handleClose}>Cancel</Button>
          <Button onClick={handleSubmit} variant="contained">
            {transactionType.includes('add') ? 'Add' : 'Withdraw'}
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};

