import { useEffect, useState } from 'react';
import {
  Box,
  Button,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  Typography,
  Paper,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Chip,
  Select,
  MenuItem,
  FormControl,
  InputLabel,
  IconButton,
} from '@mui/material';
import { Add, CheckCircle, Cancel, Send } from '@mui/icons-material';
import { jobService } from '../../services/jobService';
import { jewelService } from '../../services/jewelService';
import { workerService } from '../../services/workerService';
import { Job, Jewel, WorkerProfile } from '../../types';
import { JEWEL_STAGES, JOB_STATUSES } from '../../utils/constants';
import { Loading } from '../../components/Loading';
import { ErrorAlert } from '../../components/ErrorAlert';
import { SuccessAlert } from '../../components/SuccessAlert';
import { formatDate } from '../../utils/dateUtils';

export const JobsPage = () => {
  const [jobs, setJobs] = useState<Job[]>([]);
  const [jewels, setJewels] = useState<Jewel[]>([]);
  const [workers, setWorkers] = useState<WorkerProfile[]>([]);
  const [loading, setLoading] = useState(true);
  const [open, setOpen] = useState(false);
  const [approveOpen, setApproveOpen] = useState<Job | null>(null);
  const [sendBackOpen, setSendBackOpen] = useState<Job | null>(null);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [formData, setFormData] = useState({
    jewel: '',
    worker: '',
    job_stage: 'jadai',
    job_description: '',
    before_weight: '',
  });
  const [approveNotes, setApproveNotes] = useState('');
  const [sendBackData, setSendBackData] = useState({ reason: '', notes: '' });

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const [jobsData, jewelsData, workersData] = await Promise.all([
        jobService.getJobs(),
        jewelService.getJewels(),
        workerService.getWorkers(),
      ]);
      setJobs(jobsData);
      setJewels(jewelsData.filter((j) => j.is_active));
      setWorkers(workersData.filter((w) => w.is_active !== false));
    } catch (error) {
      setError('Failed to load data');
    } finally {
      setLoading(false);
    }
  };

  const handleOpen = () => {
    setFormData({
      jewel: '',
      worker: '',
      job_stage: 'jadai',
      job_description: '',
      before_weight: '',
    });
    setOpen(true);
  };

  const handleClose = () => {
    setOpen(false);
  };

  const handleSubmit = async () => {
    try {
      setError('');
      await jobService.createJob({
        ...formData,
        before_weight: parseFloat(formData.before_weight) || 0,
      });
      setSuccess('Job created successfully');
      handleClose();
      loadData();
      setTimeout(() => setSuccess(''), 3000);
    } catch (err: any) {
      setError(err.response?.data?.detail || 'Failed to create job');
    }
  };

  const handleApprove = async () => {
    if (!approveOpen) return;
    try {
      await jobService.approveJob(approveOpen.id, approveNotes);
      setSuccess('Job approved successfully');
      setApproveOpen(null);
      setApproveNotes('');
      loadData();
      setTimeout(() => setSuccess(''), 3000);
    } catch (err: any) {
      setError(err.response?.data?.detail || 'Failed to approve job');
    }
  };

  const handleSendBack = async () => {
    if (!sendBackOpen) return;
    try {
      await jobService.sendBackJob(sendBackOpen.id, sendBackData);
      setSuccess('Job sent back successfully');
      setSendBackOpen(null);
      setSendBackData({ reason: '', notes: '' });
      loadData();
      setTimeout(() => setSuccess(''), 3000);
    } catch (err: any) {
      setError(err.response?.data?.detail || 'Failed to send back job');
    }
  };

  const getStatusColor = (status: string) => {
    const statusObj = JOB_STATUSES.find((s) => s.value === status);
    return statusObj?.color || 'default';
  };

  if (loading) return <Loading />;

  return (
    <Box>
      <Box display="flex" justifyContent="space-between" alignItems="center" mb={3}>
        <Typography variant="h4">Jobs</Typography>
        <Button variant="contained" startIcon={<Add />} onClick={handleOpen}>
          Create Job
        </Button>
      </Box>

      {error && <ErrorAlert message={error} onClose={() => setError('')} />}
      {success && <SuccessAlert message={success} onClose={() => setSuccess('')} />}

      <TableContainer component={Paper}>
        <Table>
          <TableHead>
            <TableRow>
              <TableCell>Jewel</TableCell>
              <TableCell>Worker</TableCell>
              <TableCell>Stage</TableCell>
              <TableCell>Status</TableCell>
              <TableCell>Before Weight</TableCell>
              <TableCell>After Weight</TableCell>
              <TableCell>Created</TableCell>
              <TableCell>Actions</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {jobs.map((job) => (
              <TableRow key={job.id}>
                <TableCell>{job.jewel_details?.jewel_type || job.jewel}</TableCell>
                <TableCell>
                  {job.worker_details?.full_name || job.worker}
                </TableCell>
                <TableCell>
                  <Chip label={job.job_stage} size="small" />
                </TableCell>
                <TableCell>
                  <Chip
                    label={job.status}
                    color={getStatusColor(job.status) as any}
                    size="small"
                  />
                </TableCell>
                <TableCell>{job.before_weight || '-'} g</TableCell>
                <TableCell>{job.after_weight || '-'} g</TableCell>
                <TableCell>{formatDate(job.created_at)}</TableCell>
                <TableCell>
                  {job.status === 'submitted_for_review' && (
                    <>
                      <IconButton
                        size="small"
                        color="success"
                        onClick={() => setApproveOpen(job)}
                      >
                        <CheckCircle />
                      </IconButton>
                      <IconButton
                        size="small"
                        color="error"
                        onClick={() => setSendBackOpen(job)}
                      >
                        <Send />
                      </IconButton>
                    </>
                  )}
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </TableContainer>

      {/* Create Job Dialog */}
      <Dialog open={open} onClose={handleClose} maxWidth="sm" fullWidth>
        <DialogTitle>Create New Job</DialogTitle>
        <DialogContent>
          <Box sx={{ pt: 1 }}>
            <FormControl fullWidth margin="normal" required>
              <InputLabel>Jewel</InputLabel>
              <Select
                value={formData.jewel}
                label="Jewel"
                onChange={(e) => setFormData({ ...formData, jewel: e.target.value })}
              >
                {jewels.map((jewel) => (
                  <MenuItem key={jewel.id} value={jewel.id}>
                    {jewel.jewel_type} - {jewel.current_stage}
                  </MenuItem>
                ))}
              </Select>
            </FormControl>
            <FormControl fullWidth margin="normal" required>
              <InputLabel>Worker</InputLabel>
              <Select
                value={formData.worker}
                label="Worker"
                onChange={(e) => setFormData({ ...formData, worker: e.target.value })}
              >
                {workers.map((worker) => (
                  <MenuItem key={worker.id} value={worker.id}>
                    {worker.full_name} ({worker.nickname})
                  </MenuItem>
                ))}
              </Select>
            </FormControl>
            <FormControl fullWidth margin="normal" required>
              <InputLabel>Job Stage</InputLabel>
              <Select
                value={formData.job_stage}
                label="Job Stage"
                onChange={(e) => setFormData({ ...formData, job_stage: e.target.value })}
              >
                {JEWEL_STAGES.filter((s) => s.value !== 'sold').map((stage) => (
                  <MenuItem key={stage.value} value={stage.value}>
                    {stage.label}
                  </MenuItem>
                ))}
              </Select>
            </FormControl>
            <TextField
              fullWidth
              label="Job Description"
              value={formData.job_description}
              onChange={(e) => setFormData({ ...formData, job_description: e.target.value })}
              margin="normal"
              multiline
              rows={3}
            />
            <TextField
              fullWidth
              label="Before Weight (g)"
              type="number"
              value={formData.before_weight}
              onChange={(e) => setFormData({ ...formData, before_weight: e.target.value })}
              margin="normal"
            />
          </Box>
        </DialogContent>
        <DialogActions>
          <Button onClick={handleClose}>Cancel</Button>
          <Button onClick={handleSubmit} variant="contained">
            Create
          </Button>
        </DialogActions>
      </Dialog>

      {/* Approve Job Dialog */}
      <Dialog open={!!approveOpen} onClose={() => setApproveOpen(null)}>
        <DialogTitle>Approve Job</DialogTitle>
        <DialogContent>
          <TextField
            fullWidth
            label="Notes (optional)"
            value={approveNotes}
            onChange={(e) => setApproveNotes(e.target.value)}
            margin="normal"
            multiline
            rows={3}
          />
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setApproveOpen(null)}>Cancel</Button>
          <Button onClick={handleApprove} variant="contained" color="success">
            Approve
          </Button>
        </DialogActions>
      </Dialog>

      {/* Send Back Dialog */}
      <Dialog open={!!sendBackOpen} onClose={() => setSendBackOpen(null)}>
        <DialogTitle>Send Job Back</DialogTitle>
        <DialogContent>
          <TextField
            fullWidth
            label="Reason"
            value={sendBackData.reason}
            onChange={(e) =>
              setSendBackData({ ...sendBackData, reason: e.target.value })
            }
            margin="normal"
            required
          />
          <TextField
            fullWidth
            label="Notes"
            value={sendBackData.notes}
            onChange={(e) => setSendBackData({ ...sendBackData, notes: e.target.value })}
            margin="normal"
            multiline
            rows={3}
          />
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setSendBackOpen(null)}>Cancel</Button>
          <Button onClick={handleSendBack} variant="contained" color="error">
            Send Back
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};

