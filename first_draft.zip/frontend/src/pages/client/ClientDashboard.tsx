import { useEffect, useState } from 'react';
import {
  Grid,
  Paper,
  Typography,
  Box,
  Card,
  CardContent,
} from '@mui/material';
import {
  Diamond,
  People,
  Work,
  ShoppingCart,
  Inventory2,
  AccountBalance,
} from '@mui/icons-material';
import { statsService } from '../../services/statsService';
import { inventoryService } from '../../services/inventoryService';
import { ClientStatistics } from '../../types';
import { Loading } from '../../components/Loading';

const StatCard = ({ title, value, icon, color }: any) => (
  <Card>
    <CardContent>
      <Box display="flex" alignItems="center" justifyContent="space-between">
        <Box>
          <Typography color="textSecondary" gutterBottom variant="body2">
            {title}
          </Typography>
          <Typography variant="h4">{value}</Typography>
        </Box>
        <Box sx={{ color, fontSize: 40 }}>{icon}</Box>
      </Box>
    </CardContent>
  </Card>
);

export const ClientDashboard = () => {
  const [stats, setStats] = useState<ClientStatistics | null>(null);
  const [inventory, setInventory] = useState({ metal: '0', points: '0' });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const [statsData, inventoryData] = await Promise.all([
        statsService.getClientStats(),
        inventoryService.getCurrentInventory(),
      ]);
      setStats(statsData);
      setInventory(inventoryData);
    } catch (error) {
      console.error('Failed to load dashboard data', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) return <Loading />;

  return (
    <Box>
      <Typography variant="h4" gutterBottom>
        Dashboard
      </Typography>

      <Grid container spacing={3} sx={{ mt: 2 }}>
        <Grid item xs={12} sm={6} md={4}>
          <StatCard
            title="Total Jewels"
            value={stats?.total_jewels || 0}
            icon={<Diamond />}
            color="primary.main"
          />
        </Grid>
        <Grid item xs={12} sm={6} md={4}>
          <StatCard
            title="Total Workers"
            value={stats?.total_workers || 0}
            icon={<People />}
            color="success.main"
          />
        </Grid>
        <Grid item xs={12} sm={6} md={4}>
          <StatCard
            title="Total Jobs"
            value={stats?.total_jobs || 0}
            icon={<Work />}
            color="info.main"
          />
        </Grid>
        <Grid item xs={12} sm={6} md={4}>
          <StatCard
            title="Total Sales"
            value={stats?.total_sales || 0}
            icon={<ShoppingCart />}
            color="warning.main"
          />
        </Grid>
        <Grid item xs={12} sm={6} md={4}>
          <StatCard
            title="Metal Inventory"
            value={`${parseFloat(inventory.metal).toFixed(3)} g`}
            icon={<Inventory2 />}
            color="secondary.main"
          />
        </Grid>
        <Grid item xs={12} sm={6} md={4}>
          <StatCard
            title="Points Inventory"
            value={`₹${parseFloat(inventory.points).toFixed(2)}`}
            icon={<AccountBalance />}
            color="error.main"
          />
        </Grid>
      </Grid>

      <Grid container spacing={3} sx={{ mt: 2 }}>
        <Grid item xs={12} md={6}>
          <Paper sx={{ p: 2 }}>
            <Typography variant="h6" gutterBottom>
              Jewels by Stage
            </Typography>
            {stats?.jewels_by_stage && Object.entries(stats.jewels_by_stage).map(([stage, count]) => (
              <Box key={stage} display="flex" justifyContent="space-between" py={1}>
                <Typography>{stage}</Typography>
                <Typography fontWeight="bold">{count as number}</Typography>
              </Box>
            ))}
          </Paper>
        </Grid>
        <Grid item xs={12} md={6}>
          <Paper sx={{ p: 2 }}>
            <Typography variant="h6" gutterBottom>
              Jobs by Status
            </Typography>
            {stats?.jobs_by_status && Object.entries(stats.jobs_by_status).map(([status, count]) => (
              <Box key={status} display="flex" justifyContent="space-between" py={1}>
                <Typography>{status}</Typography>
                <Typography fontWeight="bold">{count as number}</Typography>
              </Box>
            ))}
          </Paper>
        </Grid>
      </Grid>
    </Box>
  );
};

