import { useEffect, useState } from 'react';
import {
  Box,
  Button,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  Typography,
  Paper,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  IconButton,
  Chip,
  Select,
  MenuItem,
  FormControl,
  InputLabel,
} from '@mui/material';
import { Add, Edit, Delete, Visibility } from '@mui/icons-material';
import { jewelService } from '../../services/jewelService';
import { Jewel, JewelStage } from '../../types';
import { JEWEL_STAGES } from '../../utils/constants';
import { Loading } from '../../components/Loading';
import { ErrorAlert } from '../../components/ErrorAlert';
import { SuccessAlert } from '../../components/SuccessAlert';
import { formatDate } from '../../utils/dateUtils';

export const JewelsPage = () => {
  const [jewels, setJewels] = useState<Jewel[]>([]);
  const [loading, setLoading] = useState(true);
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<Jewel | null>(null);
  const [filterStage, setFilterStage] = useState<JewelStage | ''>('');
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [formData, setFormData] = useState({
    jewel_type: '',
    ghatt_weight: '',
    stone_weight: '',
    net_weight: '',
    metal_weight: '',
    current_stage: 'ghatt' as JewelStage,
  });

  useEffect(() => {
    loadJewels();
  }, [filterStage]);

  const loadJewels = async () => {
    try {
      const data = await jewelService.getJewels(filterStage || undefined);
      setJewels(data);
    } catch (error) {
      setError('Failed to load jewels');
    } finally {
      setLoading(false);
    }
  };

  const handleOpen = (jewel?: Jewel) => {
    if (jewel) {
      setEditing(jewel);
      setFormData({
        jewel_type: jewel.jewel_type,
        ghatt_weight: jewel.ghatt_weight,
        stone_weight: jewel.stone_weight,
        net_weight: jewel.net_weight,
        metal_weight: jewel.metal_weight,
        current_stage: jewel.current_stage,
      });
    } else {
      setEditing(null);
      setFormData({
        jewel_type: '',
        ghatt_weight: '',
        stone_weight: '',
        net_weight: '',
        metal_weight: '',
        current_stage: 'ghatt',
      });
    }
    setOpen(true);
  };

  const handleClose = () => {
    setOpen(false);
    setEditing(null);
  };

  const handleSubmit = async () => {
    try {
      setError('');
      const data = {
        jewel_type: formData.jewel_type,
        ghatt_weight: parseFloat(formData.ghatt_weight),
        stone_weight: parseFloat(formData.stone_weight) || 0,
        net_weight: parseFloat(formData.net_weight) || 0,
        metal_weight: parseFloat(formData.metal_weight) || 0,
      };

      if (editing) {
        await jewelService.updateJewel(editing.id, {
          ...data,
          current_stage: formData.current_stage,
        });
        setSuccess('Jewel updated successfully');
      } else {
        await jewelService.createJewel(data);
        setSuccess('Jewel created successfully');
      }
      handleClose();
      loadJewels();
      setTimeout(() => setSuccess(''), 3000);
    } catch (err: any) {
      setError(err.response?.data?.detail || 'Operation failed');
    }
  };

  const handleDelete = async (id: string) => {
    if (window.confirm('Are you sure you want to delete this jewel?')) {
      try {
        await jewelService.deleteJewel(id);
        setSuccess('Jewel deleted successfully');
        loadJewels();
        setTimeout(() => setSuccess(''), 3000);
      } catch (err: any) {
        setError(err.response?.data?.detail || 'Failed to delete jewel');
      }
    }
  };

  if (loading) return <Loading />;

  return (
    <Box>
      <Box display="flex" justifyContent="space-between" alignItems="center" mb={3}>
        <Typography variant="h4">Jewels</Typography>
        <Box display="flex" gap={2}>
          <FormControl size="small" sx={{ minWidth: 200 }}>
            <InputLabel>Filter by Stage</InputLabel>
            <Select
              value={filterStage}
              label="Filter by Stage"
              onChange={(e) => setFilterStage(e.target.value as JewelStage | '')}
            >
              <MenuItem value="">All Stages</MenuItem>
              {JEWEL_STAGES.map((stage) => (
                <MenuItem key={stage.value} value={stage.value}>
                  {stage.label}
                </MenuItem>
              ))}
            </Select>
          </FormControl>
          <Button variant="contained" startIcon={<Add />} onClick={() => handleOpen()}>
            Add Jewel
          </Button>
        </Box>
      </Box>

      {error && <ErrorAlert message={error} onClose={() => setError('')} />}
      {success && <SuccessAlert message={success} onClose={() => setSuccess('')} />}

      <TableContainer component={Paper}>
        <Table>
          <TableHead>
            <TableRow>
              <TableCell>Type</TableCell>
              <TableCell>Stage</TableCell>
              <TableCell>Ghatt Weight</TableCell>
              <TableCell>Net Weight</TableCell>
              <TableCell>Metal Weight</TableCell>
              <TableCell>Created</TableCell>
              <TableCell>Status</TableCell>
              <TableCell>Actions</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {jewels.map((jewel) => (
              <TableRow key={jewel.id}>
                <TableCell>{jewel.jewel_type}</TableCell>
                <TableCell>
                  <Chip label={jewel.current_stage} size="small" />
                </TableCell>
                <TableCell>{jewel.ghatt_weight} g</TableCell>
                <TableCell>{jewel.net_weight} g</TableCell>
                <TableCell>{jewel.metal_weight} g</TableCell>
                <TableCell>{formatDate(jewel.created_at)}</TableCell>
                <TableCell>
                  <Chip
                    label={jewel.is_active ? 'Active' : 'Inactive'}
                    color={jewel.is_active ? 'success' : 'default'}
                    size="small"
                  />
                </TableCell>
                <TableCell>
                  <IconButton size="small" onClick={() => handleOpen(jewel)}>
                    <Edit />
                  </IconButton>
                  <IconButton
                    size="small"
                    onClick={() => handleDelete(jewel.id)}
                    color="error"
                  >
                    <Delete />
                  </IconButton>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </TableContainer>

      <Dialog open={open} onClose={handleClose} maxWidth="sm" fullWidth>
        <DialogTitle>{editing ? 'Edit Jewel' : 'Add New Jewel'}</DialogTitle>
        <DialogContent>
          <Box sx={{ pt: 1 }}>
            <TextField
              fullWidth
              label="Jewel Type"
              value={formData.jewel_type}
              onChange={(e) => setFormData({ ...formData, jewel_type: e.target.value })}
              margin="normal"
              required
            />
            <TextField
              fullWidth
              label="Ghatt Weight (g)"
              type="number"
              value={formData.ghatt_weight}
              onChange={(e) => setFormData({ ...formData, ghatt_weight: e.target.value })}
              margin="normal"
              required
            />
            <TextField
              fullWidth
              label="Stone Weight (g)"
              type="number"
              value={formData.stone_weight}
              onChange={(e) => setFormData({ ...formData, stone_weight: e.target.value })}
              margin="normal"
            />
            <TextField
              fullWidth
              label="Net Weight (g)"
              type="number"
              value={formData.net_weight}
              onChange={(e) => setFormData({ ...formData, net_weight: e.target.value })}
              margin="normal"
            />
            <TextField
              fullWidth
              label="Metal Weight (g)"
              type="number"
              value={formData.metal_weight}
              onChange={(e) => setFormData({ ...formData, metal_weight: e.target.value })}
              margin="normal"
            />
            {editing && (
              <FormControl fullWidth margin="normal">
                <InputLabel>Current Stage</InputLabel>
                <Select
                  value={formData.current_stage}
                  label="Current Stage"
                  onChange={(e) =>
                    setFormData({ ...formData, current_stage: e.target.value as JewelStage })
                  }
                >
                  {JEWEL_STAGES.map((stage) => (
                    <MenuItem key={stage.value} value={stage.value}>
                      {stage.label}
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
            )}
          </Box>
        </DialogContent>
        <DialogActions>
          <Button onClick={handleClose}>Cancel</Button>
          <Button onClick={handleSubmit} variant="contained">
            {editing ? 'Update' : 'Create'}
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};

