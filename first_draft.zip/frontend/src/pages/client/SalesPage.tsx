import { useEffect, useState } from 'react';
import {
  Box,
  Button,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  Typography,
  Paper,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Select,
  MenuItem,
  FormControl,
  InputLabel,
  Grid,
  Card,
  CardContent,
} from '@mui/material';
import { Add } from '@mui/icons-material';
import { salesService } from '../../services/salesService';
import { jewelService } from '../../services/jewelService';
import { Sale, Jewel } from '../../types';
import { PAYMENT_METHODS, BUYER_TYPES } from '../../utils/constants';
import { Loading } from '../../components/Loading';
import { ErrorAlert } from '../../components/ErrorAlert';
import { SuccessAlert } from '../../components/SuccessAlert';
import { formatDate } from '../../utils/dateUtils';

export const SalesPage = () => {
  const [sales, setSales] = useState<Sale[]>([]);
  const [jewels, setJewels] = useState<Jewel[]>([]);
  const [loading, setLoading] = useState(true);
  const [open, setOpen] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [formData, setFormData] = useState({
    jewel: '',
    buyer_name: '',
    buyer_phone: '',
    buyer_type: 'retailer' as 'retailer' | 'customer',
    payment_method: 'metal' as 'metal' | 'points' | 'cash',
    metal_amount: '',
    points_amount: '',
    final_amount: '',
    gold_price_per_gram: '',
  });

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const [salesData, jewelsData] = await Promise.all([
        salesService.getSales(),
        jewelService.getJewels(),
      ]);
      setSales(salesData);
      setJewels(jewelsData.filter((j) => j.current_stage === 'ready_to_sell' && j.is_active !== false));
    } catch (error) {
      setError('Failed to load sales data');
    } finally {
      setLoading(false);
    }
  };

  const handleOpen = () => {
    setFormData({
      jewel: '',
      buyer_name: '',
      buyer_phone: '',
      buyer_type: 'retailer',
      payment_method: 'metal',
      metal_amount: '',
      points_amount: '',
      final_amount: '',
      gold_price_per_gram: '',
    });
    setOpen(true);
  };

  const handleClose = () => {
    setOpen(false);
  };

  const handleSubmit = async () => {
    try {
      setError('');
      const data: any = {
        jewel: formData.jewel,
        buyer_name: formData.buyer_name,
        buyer_type: formData.buyer_type,
        payment_method: formData.payment_method,
        final_amount: parseFloat(formData.final_amount),
      };

      if (formData.buyer_phone) data.buyer_phone = formData.buyer_phone;
      if (formData.payment_method === 'metal') {
        data.metal_amount = parseFloat(formData.metal_amount);
        data.gold_price_per_gram = parseFloat(formData.gold_price_per_gram);
      } else if (formData.payment_method === 'points') {
        data.points_amount = parseFloat(formData.points_amount);
      }

      await salesService.createSale(data);
      setSuccess('Sale created successfully');
      handleClose();
      loadData();
      setTimeout(() => setSuccess(''), 3000);
    } catch (err: any) {
      setError(err.response?.data?.detail || 'Failed to create sale');
    }
  };

  const totalRevenue = sales.reduce((sum, sale) => sum + parseFloat(sale.final_amount), 0);

  if (loading) return <Loading />;

  return (
    <Box>
      <Box display="flex" justifyContent="space-between" alignItems="center" mb={3}>
        <Typography variant="h4">Sales</Typography>
        <Button variant="contained" startIcon={<Add />} onClick={handleOpen}>
          Create Sale
        </Button>
      </Box>

      {error && <ErrorAlert message={error} onClose={() => setError('')} />}
      {success && <SuccessAlert message={success} onClose={() => setSuccess('')} />}

      <Grid container spacing={3} sx={{ mb: 3 }}>
        <Grid item xs={12} md={4}>
          <Card>
            <CardContent>
              <Typography color="textSecondary" gutterBottom>
                Total Sales
              </Typography>
              <Typography variant="h4">{sales.length}</Typography>
            </CardContent>
          </Card>
        </Grid>
        <Grid item xs={12} md={4}>
          <Card>
            <CardContent>
              <Typography color="textSecondary" gutterBottom>
                Total Revenue
              </Typography>
              <Typography variant="h4">₹{totalRevenue.toFixed(2)}</Typography>
            </CardContent>
          </Card>
        </Grid>
        <Grid item xs={12} md={4}>
          <Card>
            <CardContent>
              <Typography color="textSecondary" gutterBottom>
                Average Sale
              </Typography>
              <Typography variant="h4">
                ₹{sales.length > 0 ? (totalRevenue / sales.length).toFixed(2) : '0.00'}
              </Typography>
            </CardContent>
          </Card>
        </Grid>
      </Grid>

      <TableContainer component={Paper}>
        <Table>
          <TableHead>
            <TableRow>
              <TableCell>Jewel</TableCell>
              <TableCell>Buyer</TableCell>
              <TableCell>Buyer Type</TableCell>
              <TableCell>Payment Method</TableCell>
              <TableCell>Amount</TableCell>
              <TableCell>Date</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {sales.map((sale) => (
              <TableRow key={sale.id}>
                <TableCell>{sale.jewel_details?.jewel_type || sale.jewel}</TableCell>
                <TableCell>{sale.buyer_name}</TableCell>
                <TableCell>{sale.buyer_type}</TableCell>
                <TableCell>{sale.payment_method}</TableCell>
                <TableCell>₹{parseFloat(sale.final_amount).toFixed(2)}</TableCell>
                <TableCell>{formatDate(sale.created_at)}</TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </TableContainer>

      <Dialog open={open} onClose={handleClose} maxWidth="sm" fullWidth>
        <DialogTitle>Create Sale</DialogTitle>
        <DialogContent>
          <Box sx={{ pt: 1 }}>
            <FormControl fullWidth margin="normal" required>
              <InputLabel>Jewel</InputLabel>
              <Select
                value={formData.jewel}
                label="Jewel"
                onChange={(e) => setFormData({ ...formData, jewel: e.target.value })}
              >
                {jewels.map((jewel) => (
                  <MenuItem key={jewel.id} value={jewel.id}>
                    {jewel.jewel_type} - {jewel.ghatt_weight}g
                  </MenuItem>
                ))}
              </Select>
            </FormControl>
            <TextField
              fullWidth
              label="Buyer Name"
              value={formData.buyer_name}
              onChange={(e) => setFormData({ ...formData, buyer_name: e.target.value })}
              margin="normal"
              required
            />
            <TextField
              fullWidth
              label="Buyer Phone"
              value={formData.buyer_phone}
              onChange={(e) => setFormData({ ...formData, buyer_phone: e.target.value })}
              margin="normal"
            />
            <FormControl fullWidth margin="normal" required>
              <InputLabel>Buyer Type</InputLabel>
              <Select
                value={formData.buyer_type}
                label="Buyer Type"
                onChange={(e) =>
                  setFormData({ ...formData, buyer_type: e.target.value as any })
                }
              >
                {BUYER_TYPES.map((type) => (
                  <MenuItem key={type.value} value={type.value}>
                    {type.label}
                  </MenuItem>
                ))}
              </Select>
            </FormControl>
            <FormControl fullWidth margin="normal" required>
              <InputLabel>Payment Method</InputLabel>
              <Select
                value={formData.payment_method}
                label="Payment Method"
                onChange={(e) =>
                  setFormData({ ...formData, payment_method: e.target.value as any })
                }
              >
                {PAYMENT_METHODS.map((method) => (
                  <MenuItem key={method.value} value={method.value}>
                    {method.label}
                  </MenuItem>
                ))}
              </Select>
            </FormControl>
            {formData.payment_method === 'metal' && (
              <>
                <TextField
                  fullWidth
                  label="Metal Amount (g)"
                  type="number"
                  value={formData.metal_amount}
                  onChange={(e) =>
                    setFormData({ ...formData, metal_amount: e.target.value })
                  }
                  margin="normal"
                  required
                />
                <TextField
                  fullWidth
                  label="Gold Price per Gram (₹)"
                  type="number"
                  value={formData.gold_price_per_gram}
                  onChange={(e) =>
                    setFormData({ ...formData, gold_price_per_gram: e.target.value })
                  }
                  margin="normal"
                  required
                />
              </>
            )}
            {formData.payment_method === 'points' && (
              <TextField
                fullWidth
                label="Points Amount (₹)"
                type="number"
                value={formData.points_amount}
                onChange={(e) =>
                  setFormData({ ...formData, points_amount: e.target.value })
                }
                margin="normal"
                required
              />
            )}
            <TextField
              fullWidth
              label="Final Amount (₹)"
              type="number"
              value={formData.final_amount}
              onChange={(e) => setFormData({ ...formData, final_amount: e.target.value })}
              margin="normal"
              required
            />
          </Box>
        </DialogContent>
        <DialogActions>
          <Button onClick={handleClose}>Cancel</Button>
          <Button onClick={handleSubmit} variant="contained">
            Create Sale
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};

