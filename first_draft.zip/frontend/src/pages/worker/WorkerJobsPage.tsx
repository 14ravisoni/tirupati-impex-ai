import { useEffect, useState } from 'react';
import {
  Box,
  Typography,
  Paper,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Chip,
  Button,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  Tabs,
  Tab,
} from '@mui/material';
import {
  CheckCircle,
  Cancel,
  PlayArrow,
  Send,
} from '@mui/icons-material';
import { jobService } from '../../services/jobService';
import { Job } from '../../types';
import { JOB_STATUSES } from '../../utils/constants';
import { Loading } from '../../components/Loading';
import { ErrorAlert } from '../../components/ErrorAlert';
import { SuccessAlert } from '../../components/SuccessAlert';
import { formatDate } from '../../utils/dateUtils';

export const WorkerJobsPage = () => {
  const [jobs, setJobs] = useState<Job[]>([]);
  const [pendingJobs, setPendingJobs] = useState<Job[]>([]);
  const [loading, setLoading] = useState(true);
  const [tab, setTab] = useState(0);
  const [actionDialog, setActionDialog] = useState<{
    open: boolean;
    job: Job | null;
    action: 'accept' | 'reject' | 'start' | 'submit' | null;
  }>({ open: false, job: null, action: null });
  const [submitData, setSubmitData] = useState({ after_weight: '', notes: '' });
  const [rejectReason, setRejectReason] = useState('');
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  useEffect(() => {
    loadJobs();
  }, [tab]);

  const loadJobs = async () => {
    try {
      if (tab === 0) {
        const data = await jobService.getMyJobs();
        setJobs(data);
      } else {
        const data = await jobService.getPendingJobs();
        setPendingJobs(data);
      }
    } catch (error) {
      setError('Failed to load jobs');
    } finally {
      setLoading(false);
    }
  };

  const handleAction = (job: Job, action: typeof actionDialog.action) => {
    setActionDialog({ open: true, job, action });
    if (action === 'submit') {
      setSubmitData({ after_weight: '', notes: '' });
    } else if (action === 'reject') {
      setRejectReason('');
    }
  };

  const handleClose = () => {
    setActionDialog({ open: false, job: null, action: null });
  };

  const handleAccept = async () => {
    if (!actionDialog.job) return;
    try {
      await jobService.acceptJob(actionDialog.job.id);
      setSuccess('Job accepted successfully');
      handleClose();
      loadJobs();
      setTimeout(() => setSuccess(''), 3000);
    } catch (err: any) {
      setError(err.response?.data?.detail || 'Failed to accept job');
    }
  };

  const handleReject = async () => {
    if (!actionDialog.job) return;
    try {
      await jobService.rejectJob(actionDialog.job.id, rejectReason);
      setSuccess('Job rejected');
      handleClose();
      loadJobs();
      setTimeout(() => setSuccess(''), 3000);
    } catch (err: any) {
      setError(err.response?.data?.detail || 'Failed to reject job');
    }
  };

  const handleStart = async () => {
    if (!actionDialog.job) return;
    try {
      await jobService.startJob(actionDialog.job.id);
      setSuccess('Job started');
      handleClose();
      loadJobs();
      setTimeout(() => setSuccess(''), 3000);
    } catch (err: any) {
      setError(err.response?.data?.detail || 'Failed to start job');
    }
  };

  const handleSubmit = async () => {
    if (!actionDialog.job) return;
    try {
      await jobService.submitJob(actionDialog.job.id, {
        after_weight: parseFloat(submitData.after_weight),
        notes: submitData.notes,
      });
      setSuccess('Job submitted for review');
      handleClose();
      loadJobs();
      setTimeout(() => setSuccess(''), 3000);
    } catch (err: any) {
      setError(err.response?.data?.detail || 'Failed to submit job');
    }
  };

  const getStatusColor = (status: string) => {
    const statusObj = JOB_STATUSES.find((s) => s.value === status);
    return statusObj?.color || 'default';
  };

  const displayJobs = tab === 0 ? jobs : pendingJobs;

  if (loading) return <Loading />;

  return (
    <Box>
      <Typography variant="h4" gutterBottom>
        My Jobs
      </Typography>

      {error && <ErrorAlert message={error} onClose={() => setError('')} />}
      {success && <SuccessAlert message={success} onClose={() => setSuccess('')} />}

      <Paper sx={{ mb: 3 }}>
        <Tabs value={tab} onChange={(_, newValue) => setTab(newValue)}>
          <Tab label="All Jobs" />
          <Tab label="Pending Acceptance" />
        </Tabs>
      </Paper>

      <TableContainer component={Paper}>
        <Table>
          <TableHead>
            <TableRow>
              <TableCell>Jewel</TableCell>
              <TableCell>Stage</TableCell>
              <TableCell>Status</TableCell>
              <TableCell>Before Weight</TableCell>
              <TableCell>After Weight</TableCell>
              <TableCell>Description</TableCell>
              <TableCell>Created</TableCell>
              <TableCell>Actions</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {displayJobs.map((job) => (
              <TableRow key={job.id}>
                <TableCell>{job.jewel_details?.jewel_type || job.jewel}</TableCell>
                <TableCell>
                  <Chip label={job.job_stage} size="small" />
                </TableCell>
                <TableCell>
                  <Chip
                    label={job.status}
                    color={getStatusColor(job.status) as any}
                    size="small"
                  />
                </TableCell>
                <TableCell>{job.before_weight || '-'} g</TableCell>
                <TableCell>{job.after_weight || '-'} g</TableCell>
                <TableCell>{job.job_description || '-'}</TableCell>
                <TableCell>{formatDate(job.created_at)}</TableCell>
                <TableCell>
                  {job.status === 'pending_acceptance' && (
                    <>
                      <Button
                        size="small"
                        startIcon={<CheckCircle />}
                        onClick={() => handleAction(job, 'accept')}
                        color="success"
                        sx={{ mr: 1 }}
                      >
                        Accept
                      </Button>
                      <Button
                        size="small"
                        startIcon={<Cancel />}
                        onClick={() => handleAction(job, 'reject')}
                        color="error"
                      >
                        Reject
                      </Button>
                    </>
                  )}
                  {job.status === 'accepted' && (
                    <Button
                      size="small"
                      startIcon={<PlayArrow />}
                      onClick={() => handleAction(job, 'start')}
                      variant="contained"
                    >
                      Start
                    </Button>
                  )}
                  {job.status === 'in_progress' && (
                    <Button
                      size="small"
                      startIcon={<Send />}
                      onClick={() => handleAction(job, 'submit')}
                      variant="contained"
                      color="primary"
                    >
                      Submit
                    </Button>
                  )}
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </TableContainer>

      {/* Accept Dialog */}
      <Dialog open={actionDialog.open && actionDialog.action === 'accept'} onClose={handleClose}>
        <DialogTitle>Accept Job</DialogTitle>
        <DialogContent>
          <Typography>Are you sure you want to accept this job?</Typography>
        </DialogContent>
        <DialogActions>
          <Button onClick={handleClose}>Cancel</Button>
          <Button onClick={handleAccept} variant="contained" color="success">
            Accept
          </Button>
        </DialogActions>
      </Dialog>

      {/* Reject Dialog */}
      <Dialog open={actionDialog.open && actionDialog.action === 'reject'} onClose={handleClose}>
        <DialogTitle>Reject Job</DialogTitle>
        <DialogContent>
          <TextField
            fullWidth
            label="Reason (optional)"
            value={rejectReason}
            onChange={(e) => setRejectReason(e.target.value)}
            margin="normal"
            multiline
            rows={3}
          />
        </DialogContent>
        <DialogActions>
          <Button onClick={handleClose}>Cancel</Button>
          <Button onClick={handleReject} variant="contained" color="error">
            Reject
          </Button>
        </DialogActions>
      </Dialog>

      {/* Start Dialog */}
      <Dialog open={actionDialog.open && actionDialog.action === 'start'} onClose={handleClose}>
        <DialogTitle>Start Job</DialogTitle>
        <DialogContent>
          <Typography>Are you sure you want to start this job?</Typography>
        </DialogContent>
        <DialogActions>
          <Button onClick={handleClose}>Cancel</Button>
          <Button onClick={handleStart} variant="contained">
            Start
          </Button>
        </DialogActions>
      </Dialog>

      {/* Submit Dialog */}
      <Dialog open={actionDialog.open && actionDialog.action === 'submit'} onClose={handleClose}>
        <DialogTitle>Submit Job for Review</DialogTitle>
        <DialogContent>
          <TextField
            fullWidth
            label="After Weight (g)"
            type="number"
            value={submitData.after_weight}
            onChange={(e) => setSubmitData({ ...submitData, after_weight: e.target.value })}
            margin="normal"
            required
          />
          <TextField
            fullWidth
            label="Notes"
            value={submitData.notes}
            onChange={(e) => setSubmitData({ ...submitData, notes: e.target.value })}
            margin="normal"
            multiline
            rows={3}
          />
        </DialogContent>
        <DialogActions>
          <Button onClick={handleClose}>Cancel</Button>
          <Button onClick={handleSubmit} variant="contained">
            Submit
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};

