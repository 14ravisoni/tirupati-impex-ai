import { useEffect, useState } from 'react';
import {
  Grid,
  Paper,
  Typography,
  Box,
  Card,
  CardContent,
} from '@mui/material';
import { Work, CheckCircle, HourglassEmpty, Cancel } from '@mui/icons-material';
import { statsService } from '../../services/statsService';
import { useAuthStore } from '../../store/authStore';
import { WorkerStatistics } from '../../types';
import { Loading } from '../../components/Loading';

const StatCard = ({ title, value, icon, color }: any) => (
  <Card>
    <CardContent>
      <Box display="flex" alignItems="center" justifyContent="space-between">
        <Box>
          <Typography color="textSecondary" gutterBottom variant="body2">
            {title}
          </Typography>
          <Typography variant="h4">{value}</Typography>
        </Box>
        <Box sx={{ color, fontSize: 40 }}>{icon}</Box>
      </Box>
    </CardContent>
  </Card>
);

export const WorkerDashboard = () => {
  const { user } = useAuthStore();
  const [stats, setStats] = useState<WorkerStatistics | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (user?.worker_profile?.id) {
      loadStats();
    }
  }, [user]);

  const loadStats = async () => {
    if (!user?.worker_profile?.id) return;
    try {
      const data = await statsService.getWorkerStats(user.worker_profile.id);
      setStats(data);
    } catch (error) {
      console.error('Failed to load worker stats', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) return <Loading />;

  return (
    <Box>
      <Typography variant="h4" gutterBottom>
        Dashboard
      </Typography>

      <Grid container spacing={3} sx={{ mt: 2 }}>
        <Grid item xs={12} sm={6} md={4}>
          <StatCard
            title="Total Jobs Assigned"
            value={stats?.total_jobs_assigned || 0}
            icon={<Work />}
            color="primary.main"
          />
        </Grid>
        <Grid item xs={12} sm={6} md={4}>
          <StatCard
            title="Jobs Completed"
            value={stats?.total_jobs_completed || 0}
            icon={<CheckCircle />}
            color="success.main"
          />
        </Grid>
        <Grid item xs={12} sm={6} md={4}>
          <StatCard
            title="Acceptance Rate"
            value={`${(stats?.acceptance_rate || 0).toFixed(1)}%`}
            icon={<HourglassEmpty />}
            color="info.main"
          />
        </Grid>
        <Grid item xs={12} sm={6} md={4}>
          <StatCard
            title="Completion Rate"
            value={`${(stats?.completion_rate || 0).toFixed(1)}%`}
            icon={<CheckCircle />}
            color="warning.main"
          />
        </Grid>
      </Grid>

      <Grid container spacing={3} sx={{ mt: 2 }}>
        <Grid item xs={12} md={6}>
          <Paper sx={{ p: 2 }}>
            <Typography variant="h6" gutterBottom>
              Jobs by Status
            </Typography>
            {stats?.jobs_by_status &&
              Object.entries(stats.jobs_by_status).map(([status, count]) => (
                <Box key={status} display="flex" justifyContent="space-between" py={1}>
                  <Typography>{status.replace('_', ' ')}</Typography>
                  <Typography fontWeight="bold">{count as number}</Typography>
                </Box>
              ))}
          </Paper>
        </Grid>
      </Grid>
    </Box>
  );
};

