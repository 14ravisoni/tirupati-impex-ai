import { useEffect } from 'react';
import {
  Box,
  Typography,
  Paper,
  List,
  ListItem,
  ListItemText,
  ListItemButton,
  IconButton,
  Chip,
  Button,
} from '@mui/material';
import { CheckCircle, CheckCircleOutline } from '@mui/icons-material';
import { useNotificationStore } from '../store/notificationStore';
import { Loading } from '../components/Loading';
import { formatRelativeTime } from '../utils/dateUtils';

export const NotificationsPage = () => {
  const { notifications, isLoading, loadNotifications, markAsRead, markAllAsRead } =
    useNotificationStore();

  useEffect(() => {
    loadNotifications();
  }, []);

  const handleMarkAsRead = async (id: string) => {
    await markAsRead(id);
  };

  const handleMarkAllAsRead = async () => {
    await markAllAsRead();
  };

  if (isLoading) return <Loading />;

  const unreadCount = notifications.filter((n) => !n.is_read).length;

  return (
    <Box>
      <Box display="flex" justifyContent="space-between" alignItems="center" mb={3}>
        <Typography variant="h4">Notifications</Typography>
        {unreadCount > 0 && (
          <Button onClick={handleMarkAllAsRead} variant="outlined">
            Mark All as Read
          </Button>
        )}
      </Box>

      <Paper>
        <List>
          {notifications.length === 0 ? (
            <ListItem>
              <ListItemText primary="No notifications" />
            </ListItem>
          ) : (
            notifications.map((notification) => (
              <ListItem
                key={notification.id}
                secondaryAction={
                  !notification.is_read && (
                    <IconButton
                      edge="end"
                      onClick={() => handleMarkAsRead(notification.id)}
                    >
                      <CheckCircleOutline />
                    </IconButton>
                  )
                }
                sx={{
                  bgcolor: notification.is_read ? 'transparent' : 'action.hover',
                }}
              >
                <ListItemButton>
                  <ListItemText
                    primary={
                      <Box display="flex" alignItems="center" gap={1}>
                        {notification.title}
                        {!notification.is_read && (
                          <Chip label="New" color="primary" size="small" />
                        )}
                      </Box>
                    }
                    secondary={
                      <>
                        {notification.message}
                        <Typography variant="caption" display="block" sx={{ mt: 0.5 }}>
                          {formatRelativeTime(notification.created_at)}
                        </Typography>
                      </>
                    }
                  />
                </ListItemButton>
              </ListItem>
            ))
          )}
        </List>
      </Paper>
    </Box>
  );
};

