import api from './api';
import { Job, JobStatus } from '../types';

export const jobService = {
  async getJobs(): Promise<Job[]> {
    const response = await api.get<Job[]>('/jobs/');
    return response.data;
  },

  async getJob(id: string): Promise<Job> {
    const response = await api.get<Job>(`/jobs/${id}/`);
    return response.data;
  },

  async createJob(data: {
    jewel: string;
    worker: string;
    job_stage: string;
    job_description?: string;
    before_weight?: number;
  }): Promise<Job> {
    const response = await api.post<Job>('/jobs/create/', data);
    return response.data;
  },

  async getMyJobs(): Promise<Job[]> {
    const response = await api.get<Job[]>('/jobs/my-jobs/');
    return response.data;
  },

  async getPendingJobs(): Promise<Job[]> {
    const response = await api.get<Job[]>('/jobs/my-jobs/pending/');
    return response.data;
  },

  async getPendingReviewJobs(): Promise<Job[]> {
    const response = await api.get<Job[]>('/jobs/pending-review/');
    return response.data;
  },

  // Worker actions
  async acceptJob(id: string): Promise<Job> {
    const response = await api.post<Job>(`/jobs/${id}/accept/`);
    return response.data;
  },

  async rejectJob(id: string, reason?: string): Promise<Job> {
    const response = await api.post<Job>(`/jobs/${id}/reject/`, { reason });
    return response.data;
  },

  async startJob(id: string): Promise<Job> {
    const response = await api.post<Job>(`/jobs/${id}/start/`);
    return response.data;
  },

  async submitJob(id: string, data: {
    after_weight: number;
    notes?: string;
  }): Promise<Job> {
    const response = await api.post<Job>(`/jobs/${id}/submit/`, data);
    return response.data;
  },

  // Client actions
  async approveJob(id: string, notes?: string): Promise<Job> {
    const response = await api.post<Job>(`/jobs/${id}/approve/`, { notes });
    return response.data;
  },

  async sendBackJob(id: string, data: {
    reason: string;
    notes?: string;
  }): Promise<Job> {
    const response = await api.post<Job>(`/jobs/${id}/send-back/`, data);
    return response.data;
  },
};

