import api from './api';
import { WorkerProfile, PaginatedResponse } from '../types';

export const workerService = {
  async getWorkers(): Promise<WorkerProfile[]> {
    const response = await api.get<WorkerProfile[]>('/workers/');
    return response.data;
  },

  async getWorker(id: string): Promise<WorkerProfile> {
    const response = await api.get<WorkerProfile>(`/workers/${id}/`);
    return response.data;
  },

  async createWorker(data: {
    email: string;
    password: string;
    full_name: string;
    nickname?: string;
    phone?: string;
  }): Promise<WorkerProfile> {
    const response = await api.post<WorkerProfile>('/workers/create/', data);
    return response.data;
  },

  async updateWorker(id: string, data: Partial<WorkerProfile>): Promise<WorkerProfile> {
    const response = await api.put<WorkerProfile>(`/workers/${id}/update/`, data);
    return response.data;
  },

  async deactivateWorker(id: string): Promise<void> {
    await api.delete(`/workers/${id}/deactivate/`);
  },

  async getWorkerJobs(id: string): Promise<any[]> {
    const response = await api.get(`/workers/${id}/jobs/`);
    return response.data;
  },

  async getWorkerStats(id: string): Promise<any> {
    const response = await api.get(`/workers/${id}/stats/`);
    return response.data;
  },
};

