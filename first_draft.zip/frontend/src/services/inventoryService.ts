import api from './api';
import { InventoryTransaction } from '../types';

export const inventoryService = {
  async getCurrentInventory(): Promise<{ metal: string; points: string }> {
    const response = await api.get('/inventory/current/');
    return response.data;
  },

  async addMetal(amount: number, notes?: string): Promise<InventoryTransaction> {
    const response = await api.post<InventoryTransaction>('/inventory/add-metal/', {
      amount,
      notes,
    });
    return response.data;
  },

  async withdrawMetal(amount: number, notes?: string): Promise<InventoryTransaction> {
    const response = await api.post<InventoryTransaction>('/inventory/withdraw-metal/', {
      amount,
      notes,
    });
    return response.data;
  },

  async addPoints(amount: number, notes?: string): Promise<InventoryTransaction> {
    const response = await api.post<InventoryTransaction>('/inventory/add-points/', {
      amount,
      notes,
    });
    return response.data;
  },

  async withdrawPoints(amount: number, notes?: string): Promise<InventoryTransaction> {
    const response = await api.post<InventoryTransaction>('/inventory/withdraw-points/', {
      amount,
      notes,
    });
    return response.data;
  },

  async getTransactions(): Promise<InventoryTransaction[]> {
    const response = await api.get<InventoryTransaction[]>('/inventory/transactions/');
    return response.data;
  },
};

