import api from './api';
import { Jewel, JewelStage } from '../types';

export const jewelService = {
  async getJewels(stage?: JewelStage): Promise<Jewel[]> {
    const params = stage ? { stage } : {};
    const response = await api.get<Jewel[]>('/jewels/', { params });
    return response.data;
  },

  async getJewel(id: string): Promise<Jewel> {
    const response = await api.get<Jewel>(`/jewels/${id}/`);
    return response.data;
  },

  async createJewel(data: {
    jewel_type: string;
    ghatt_weight: number;
    stone_weight?: number;
    net_weight?: number;
    metal_weight?: number;
  }): Promise<Jewel> {
    const response = await api.post<Jewel>('/jewels/create/', data);
    return response.data;
  },

  async updateJewel(id: string, data: Partial<Jewel>): Promise<Jewel> {
    const response = await api.put<Jewel>(`/jewels/${id}/update/`, data);
    return response.data;
  },

  async deleteJewel(id: string): Promise<void> {
    await api.delete(`/jewels/${id}/delete/`);
  },

  async getJewelsByStage(): Promise<Record<JewelStage, any>> {
    const response = await api.get('/jewels/by-stage/');
    return response.data;
  },

  async updateJewelWeight(id: string, data: {
    ghatt_weight?: number;
    net_weight?: number;
    metal_weight?: number;
  }): Promise<Jewel> {
    const response = await api.put<Jewel>(`/jewels/${id}/update-weight/`, data);
    return response.data;
  },
};

