import api from './api';
import { ClientStatistics, WorkerStatistics } from '../types';

export const statsService = {
  async getClientStats(): Promise<ClientStatistics> {
    // We'll need to aggregate this from various endpoints
    // For now, we'll create a composite response
    const [jewels, jobs, workers, sales] = await Promise.all([
      api.get('/jewels/'),
      api.get('/jobs/'),
      api.get('/workers/'),
      api.get('/sales/'),
    ]);

    const jewelsData = jewels.data;
    const jobsData = jobs.data;
    const workersData = workers.data;
    const salesData = sales.data;

    // Calculate statistics
    const jewelsByStage: Record<string, number> = {};
    const jobsByStatus: Record<string, number> = {};

    jewelsData.forEach((jewel: any) => {
      jewelsByStage[jewel.current_stage] = (jewelsByStage[jewel.current_stage] || 0) + 1;
    });

    jobsData.forEach((job: any) => {
      jobsByStatus[job.status] = (jobsByStatus[job.status] || 0) + 1;
    });

    const totalRevenue = salesData.reduce((sum: number, sale: any) => {
      return sum + parseFloat(sale.final_amount || 0);
    }, 0);

    return {
      total_jewels: jewelsData.length,
      jewels_by_stage: jewelsByStage as any,
      total_jobs: jobsData.length,
      jobs_by_status: jobsByStatus as any,
      total_workers: workersData.length,
      active_workers: workersData.filter((w: any) => w.user?.is_active).length,
      total_sales: salesData.length,
      total_revenue: totalRevenue.toFixed(2),
      metal_inventory: '0', // Will be fetched from inventory
      points_inventory: '0', // Will be fetched from inventory
    };
  },

  async getWorkerStats(workerId: string): Promise<WorkerStatistics> {
    const response = await api.get(`/workers/${workerId}/stats/`);
    return response.data;
  },
};

