import api from './api';
import { LoginCredentials, RegisterData, AuthResponse, User } from '../types';
import { STORAGE_KEYS } from '../utils/constants';

export const authService = {
  async register(data: RegisterData): Promise<AuthResponse> {
    const response = await api.post<AuthResponse>('/auth/register/client/', data);
    this.setAuthData(response.data);
    return response.data;
  },

  async login(credentials: LoginCredentials): Promise<AuthResponse> {
    const response = await api.post<AuthResponse>('/auth/login/', credentials);
    this.setAuthData(response.data);
    return response.data;
  },

  async logout(): Promise<void> {
    const refreshToken = localStorage.getItem(STORAGE_KEYS.REFRESH_TOKEN);
    if (refreshToken) {
      try {
        await api.post('/auth/logout/', { refresh: refreshToken });
      } catch (error) {
        console.error('Logout error:', error);
      }
    }
    this.clearAuthData();
  },

  async changePassword(oldPassword: string, newPassword: string, confirmPassword: string): Promise<void> {
    await api.post('/auth/change-password/', {
      old_password: oldPassword,
      new_password: newPassword,
      confirm_password: confirmPassword,
    });
  },

  async getCurrentUser(): Promise<User> {
    const response = await api.get<User>('/users/me/');
    return response.data;
  },

  setAuthData(data: AuthResponse): void {
    localStorage.setItem(STORAGE_KEYS.ACCESS_TOKEN, data.access);
    localStorage.setItem(STORAGE_KEYS.REFRESH_TOKEN, data.refresh);
    localStorage.setItem(STORAGE_KEYS.USER, JSON.stringify(data.user));
  },

  clearAuthData(): void {
    localStorage.removeItem(STORAGE_KEYS.ACCESS_TOKEN);
    localStorage.removeItem(STORAGE_KEYS.REFRESH_TOKEN);
    localStorage.removeItem(STORAGE_KEYS.USER);
  },

  getStoredUser(): User | null {
    const userStr = localStorage.getItem(STORAGE_KEYS.USER);
    return userStr ? JSON.parse(userStr) : null;
  },

  isAuthenticated(): boolean {
    return !!localStorage.getItem(STORAGE_KEYS.ACCESS_TOKEN);
  },
};

