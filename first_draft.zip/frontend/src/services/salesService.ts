import api from './api';
import { Sale } from '../types';

export const salesService = {
  async getSales(): Promise<Sale[]> {
    const response = await api.get<Sale[]>('/sales/');
    return response.data;
  },

  async getSale(id: string): Promise<Sale> {
    const response = await api.get<Sale>(`/sales/${id}/`);
    return response.data;
  },

  async createSale(data: {
    jewel: string;
    buyer_name: string;
    buyer_phone?: string;
    buyer_type: 'retailer' | 'customer';
    payment_method: 'metal' | 'points' | 'cash';
    metal_amount?: number;
    points_amount?: number;
    final_amount: number;
    gold_price_per_gram?: number;
  }): Promise<Sale> {
    const response = await api.post<Sale>('/sales/create/', data);
    return response.data;
  },

  async getSalesReport(): Promise<any> {
    const response = await api.get('/sales/report/');
    return response.data;
  },
};

