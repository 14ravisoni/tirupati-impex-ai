export const API_BASE_URL = import.meta.env.VITE_API_BASE_URL || 'http://127.0.0.1:8000/api/v1';

export const JEWEL_STAGES: { value: string; label: string }[] = [
  { value: 'ghatt', label: 'Ghatt' },
  { value: 'jadai', label: 'Jadai' },
  { value: 'polish', label: 'Polish' },
  { value: 'stone_setting', label: 'Stone Setting' },
  { value: 'final_polish', label: 'Final Polish' },
  { value: 'quality_check', label: 'Quality Check' },
  { value: 'ready_to_sell', label: 'Ready to Sell' },
  { value: 'sold', label: 'Sold' },
];

export const JOB_STATUSES: { value: string; label: string; color: string }[] = [
  { value: 'pending_acceptance', label: 'Pending Acceptance', color: 'warning' },
  { value: 'accepted', label: 'Accepted', color: 'info' },
  { value: 'rejected', label: 'Rejected', color: 'error' },
  { value: 'in_progress', label: 'In Progress', color: 'primary' },
  { value: 'submitted_for_review', label: 'Submitted for Review', color: 'secondary' },
  { value: 'sent_back_by_client', label: 'Sent Back', color: 'error' },
  { value: 'completed', label: 'Completed', color: 'success' },
];

export const PAYMENT_METHODS = [
  { value: 'metal', label: 'Metal' },
  { value: 'points', label: 'Points' },
  { value: 'cash', label: 'Cash' },
];

export const BUYER_TYPES = [
  { value: 'retailer', label: 'Retailer' },
  { value: 'customer', label: 'Customer' },
];

export const STORAGE_KEYS = {
  ACCESS_TOKEN: 'access_token',
  REFRESH_TOKEN: 'refresh_token',
  USER: 'user',
};

