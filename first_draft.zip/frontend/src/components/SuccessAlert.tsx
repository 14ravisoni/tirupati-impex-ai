import { Alert } from '@mui/material';

interface SuccessAlertProps {
  message: string;
  onClose?: () => void;
}

export const SuccessAlert = ({ message, onClose }: SuccessAlertProps) => {
  return (
    <Alert severity="success" onClose={onClose} sx={{ mb: 2 }}>
      {message}
    </Alert>
  );
};

