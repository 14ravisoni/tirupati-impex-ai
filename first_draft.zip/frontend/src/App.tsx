import { useEffect } from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { ThemeProvider, createTheme, CssBaseline } from '@mui/material';
import { useAuthStore } from './store/authStore';
import { useNotificationStore } from './store/notificationStore';
import { ClientLayout } from './layouts/ClientLayout';
import { WorkerLayout } from './layouts/WorkerLayout';
import { Login } from './pages/Login';
import { Register } from './pages/Register';
import { ClientDashboard } from './pages/client/ClientDashboard';
import { WorkersPage } from './pages/client/WorkersPage';
import { JewelsPage } from './pages/client/JewelsPage';
import { JobsPage } from './pages/client/JobsPage';
import { InventoryPage } from './pages/client/InventoryPage';
import { SalesPage } from './pages/client/SalesPage';
import { WorkerDashboard } from './pages/worker/WorkerDashboard';
import { WorkerJobsPage } from './pages/worker/WorkerJobsPage';
import { NotificationsPage } from './pages/NotificationsPage';
import { Loading } from './components/Loading';

const theme = createTheme({
  palette: {
    primary: {
      main: '#1976d2',
    },
    secondary: {
      main: '#dc004e',
    },
  },
});

const ProtectedRoute = ({ children, userType }: { children: JSX.Element; userType: 'client' | 'worker' }) => {
  const { user, isAuthenticated, isLoading } = useAuthStore();

  if (isLoading) {
    return <Loading />;
  }

  if (!isAuthenticated || !user) {
    return <Navigate to="/login" replace />;
  }

  if (user.userType !== userType) {
    return <Navigate to={user.userType === 'client' ? '/client/dashboard' : '/worker/dashboard'} replace />;
  }

  return children;
};

function App() {
  const { loadUser, isAuthenticated } = useAuthStore();
  const { loadUnreadCount } = useNotificationStore();

  useEffect(() => {
    loadUser();
  }, []);

  useEffect(() => {
    if (isAuthenticated) {
      loadUnreadCount();
      const interval = setInterval(loadUnreadCount, 30000); // Refresh every 30 seconds
      return () => clearInterval(interval);
    }
  }, [isAuthenticated]);

  return (
    <ThemeProvider theme={theme}>
      <CssBaseline />
      <BrowserRouter>
        <Routes>
          <Route path="/login" element={<Login />} />
          <Route path="/register" element={<Register />} />
          
          <Route
            path="/client/*"
            element={
              <ProtectedRoute userType="client">
                <ClientLayout />
              </ProtectedRoute>
            }
          >
            <Route path="dashboard" element={<ClientDashboard />} />
            <Route path="workers" element={<WorkersPage />} />
            <Route path="jewels" element={<JewelsPage />} />
            <Route path="jobs" element={<JobsPage />} />
            <Route path="inventory" element={<InventoryPage />} />
            <Route path="sales" element={<SalesPage />} />
            <Route path="notifications" element={<NotificationsPage />} />
            <Route path="profile" element={<div>Profile Page (Coming Soon)</div>} />
          </Route>

          <Route
            path="/worker/*"
            element={
              <ProtectedRoute userType="worker">
                <WorkerLayout />
              </ProtectedRoute>
            }
          >
            <Route path="dashboard" element={<WorkerDashboard />} />
            <Route path="jobs" element={<WorkerJobsPage />} />
            <Route path="notifications" element={<NotificationsPage />} />
          </Route>

          <Route path="/" element={<Navigate to="/login" replace />} />
        </Routes>
      </BrowserRouter>
    </ThemeProvider>
  );
}

export default App;

