# Tirupati Impex - Frontend Application

React + TypeScript frontend for the Tirupati Impex Jewelry Management System.

## Prerequisites

- **Node.js 20.19.5** installed at `C:\tools\node_v20.19.5\`
- Backend server running on http://127.0.0.1:8000

## Quick Start

### 1. Install Dependencies

Double-click `install.bat` or run:
```cmd
install.bat
```

### 2. Start Development Server

Double-click `run_dev.bat` or run:
```cmd
run_dev.bat
```

The app will be available at **http://localhost:5173**

## Features

### ✅ Client Portal
- Register new client account
- Login/Logout
- Dashboard with statistics
- Manage Workers (Add, View, Update, Deactivate)
- Manage Jewels (Create, View, Update, Filter by Stage)
- Create and Assign Jobs to Workers
- View all Jobs and their status
- Approve or Send Back jobs submitted by workers
- Move jobs through stages
- Complete/Sell jewels
- Inventory Management (Add/Withdraw Metal & Points)
- View Sales Reports
- Notifications

### ✅ Worker Portal
- Login/Logout
- Dashboard with statistics
- View assigned jobs
- Accept/Reject job assignments
- Start jobs
- Submit jobs for review
- View job history
- Notifications

## Project Structure

```
frontend/
├── src/
│   ├── components/      # Reusable UI components
│   ├── pages/           # Page components
│   │   ├── client/      # Client portal pages
│   │   └── worker/     # Worker portal pages
│   ├── layouts/         # Layout components
│   ├── services/        # API services
│   ├── store/           # State management (Zustand)
│   ├── hooks/           # Custom React hooks
│   ├── types/           # TypeScript type definitions
│   ├── utils/           # Utility functions
│   └── App.tsx          # Main app component
├── public/              # Static assets
├── install.bat          # Install dependencies
├── run_dev.bat         # Start dev server
└── package.json
```

## Available Scripts

- `install.bat` - Install all dependencies
- `run_dev.bat` - Start development server
- `run_build.bat` - Build for production
- `npm.bat <command>` - Run any npm command

## Environment Variables

The `.env` file should contain:
```env
VITE_API_BASE_URL=http://127.0.0.1:8000/api/v1
```

## Testing the Application

### As Client:

1. **Register:** http://localhost:5173/register
2. **Login:** http://localhost:5173/login
3. **Dashboard:** http://localhost:5173/client/dashboard

### As Worker:

1. **Login:** http://localhost:5173/login (use worker credentials)
2. **Dashboard:** http://localhost:5173/worker/dashboard

## Development

```bash
# Start dev server
run_dev.bat

# Build for production
run_build.bat

# Preview production build
npm.bat run preview
```

## API Integration

The frontend communicates with the Django REST API backend. All API calls are handled through services in `src/services/`.

## Authentication

Uses JWT tokens stored in localStorage. Tokens are automatically included in API requests and refreshed when expired.

## Troubleshooting

See `QUICK_START.md` for detailed troubleshooting guide.
