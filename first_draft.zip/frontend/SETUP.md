# Frontend Setup Guide

## Node.js Installation

Node.js is installed at: **`C:\tools\node_v20.19.5\`**

## Quick Start

### 1. Install Dependencies

Double-click `install.bat` or run in terminal:
```cmd
install.bat
```

This will:
- Verify Node.js installation
- Install all npm packages
- Set up the project

### 2. Start Development Server

Double-click `run_dev.bat` or run in terminal:
```cmd
run_dev.bat
```

The app will start at: **http://localhost:5173**

## Available Scripts

### Windows Batch Scripts (Easiest)

- **`install.bat`** - Install all dependencies
- **`run_dev.bat`** - Start development server
- **`run_build.bat`** - Build for production
- **`npm.bat`** - Wrapper for npm commands

### Using npm.bat Wrapper

You can use `npm.bat` like regular npm:

```cmd
npm.bat install
npm.bat run dev
npm.bat run build
npm.bat install <package-name>
```

### PowerShell Scripts

If you prefer PowerShell:

```powershell
# Setup environment
.\setup_env.ps1

# Then use npm normally
npm install
npm run dev
```

## Manual Setup (Alternative)

If you want to add Node.js to system PATH:

1. Open System Properties → Environment Variables
2. Edit "Path" under System variables
3. Add: `C:\tools\node_v20.19.5`
4. Restart terminal
5. Then use `npm` commands directly

## Troubleshooting

### "Node.js not found" Error

- Verify Node.js exists at: `C:\tools\node_v20.19.5\`
- Check that `node.exe` and `npm.cmd` are in that folder
- If Node.js is in a different location, update the path in:
  - `npm.bat` (line 3: `set NODE_PATH=...`)
  - `install.bat` (line 3: `set NODE_PATH=...`)
  - `run_dev.bat` (line 3: `set NODE_PATH=...`)
  - `run_build.bat` (line 3: `set NODE_PATH=...`)
  - `setup_env.ps1` (line 3: `$nodePath = ...`)

### Port Already in Use

If port 5173 is already in use:
- Change port in `vite.config.ts`:
  ```typescript
  server: {
    port: 5174,  // Change to different port
  }
  ```

## Project Structure

```
frontend/
├── src/              # Source code
├── public/           # Static assets
├── install.bat       # Install dependencies
├── run_dev.bat       # Start dev server
├── run_build.bat     # Build for production
├── npm.bat           # npm wrapper
└── package.json      # Dependencies
```

