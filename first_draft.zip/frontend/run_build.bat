@echo off
REM Build for production using custom Node.js installation

set NODE_PATH=C:\tools\node_v20.19.5
set PATH=%NODE_PATH%;%PATH%

if not exist "%NODE_PATH%\npm.cmd" (
    echo Error: Node.js not found at %NODE_PATH%
    echo Please verify the Node.js installation path.
    pause
    exit /b 1
)

echo Building for production...
echo.
"%NODE_PATH%\npm.cmd" run build

if %ERRORLEVEL% EQU 0 (
    echo.
    echo ========================================
    echo Build completed successfully!
    echo ========================================
    echo Output: dist/
    echo.
) else (
    echo.
    echo ========================================
    echo Build failed!
    echo ========================================
    echo.
)

pause

