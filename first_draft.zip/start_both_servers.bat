@echo off
REM Start Both Servers in Separate Windows
echo ========================================
echo Starting Both Servers
echo ========================================
echo.

REM Start backend in new window
echo Starting Backend Server in new window...
start "Backend Server" cmd /k "cd /d %~dp0backend && call .venv\Scripts\activate.bat && python manage.py runserver 127.0.0.1:8000"

REM Wait a moment
timeout /t 2 /nobreak >nul

REM Start frontend in new window
echo Starting Frontend Server in new window...
start "Frontend Server" cmd /k "cd /d %~dp0frontend && C:\tools\node_v20.19.5\npm.cmd run dev"

echo.
echo ========================================
echo Both servers are starting in separate windows
echo ========================================
echo.
echo Backend: http://127.0.0.1:8000
echo Frontend: http://localhost:5173
echo.
echo Check the separate windows for server logs and errors
echo.
pause

