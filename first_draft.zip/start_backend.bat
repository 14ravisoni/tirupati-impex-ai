@echo off
REM Start Backend Django Server
echo ========================================
echo Starting Backend Django Server
echo ========================================
echo.

cd backend

REM Activate virtual environment and run server
call .venv\Scripts\activate.bat
if %ERRORLEVEL% NEQ 0 (
    echo Error: Failed to activate virtual environment
    echo Trying direct Python path...
    .venv\Scripts\python.exe manage.py runserver 127.0.0.1:8000
) else (
    python manage.py runserver 127.0.0.1:8000
)

pause

