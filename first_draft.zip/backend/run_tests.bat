@echo off
REM Test Runner Batch Script for Windows

echo ========================================
echo Tirupati Impex Backend - Test Runner
echo ========================================
echo.

REM Activate virtual environment if it exists
if exist "..\venv\Scripts\activate.bat" (
    call ..\venv\Scripts\activate.bat
) else if exist "venv\Scripts\activate.bat" (
    call venv\Scripts\activate.bat
) else if exist "..\.venv\Scripts\activate.bat" (
    call ..\.venv\Scripts\activate.bat
)

REM Run the test script
python run_tests.py %*

echo.
echo ========================================
echo Test execution completed
echo ========================================
pause

