import pytest
from django.contrib.auth import get_user_model
from apps.users.models import Client
from apps.workers.models import Worker
from apps.jewels.models import Jewel, StoneType
from rest_framework.test import APIClient
from rest_framework_simplejwt.tokens import RefreshToken

User = get_user_model()


@pytest.fixture
def api_client():
    """Create an API client."""
    return APIClient()


@pytest.fixture
def client_user(db):
    """Create a test client user."""
    user = User.objects.create_user(
        email='client@test.com',
        password='testpass123',
        user_type='client',
        phone='+91-9876543210'
    )
    client = Client.objects.create(
        user=user,
        business_name='Test Jewelers',
        full_name='Test Client'
    )
    return user


@pytest.fixture
def client_profile(db, client_user):
    """Get client profile."""
    return client_user.client_profile


@pytest.fixture
def worker_user(db, client_profile):
    """Create a test worker user."""
    user = User.objects.create_user(
        email='worker@test.com',
        password='testpass123',
        user_type='worker'
    )
    worker = Worker.objects.create(
        user=user,
        client=client_profile,
        full_name='Test Worker',
        nickname='TW'
    )
    return user


@pytest.fixture
def worker_profile(db, worker_user):
    """Get worker profile."""
    return worker_user.worker_profile


@pytest.fixture
def authenticated_client(api_client, client_user):
    """Create an authenticated API client (client user)."""
    refresh = RefreshToken.for_user(client_user)
    api_client.credentials(HTTP_AUTHORIZATION=f'Bearer {refresh.access_token}')
    return api_client


@pytest.fixture
def authenticated_worker(api_client, worker_user):
    """Create an authenticated API client (worker user)."""
    refresh = RefreshToken.for_user(worker_user)
    api_client.credentials(HTTP_AUTHORIZATION=f'Bearer {refresh.access_token}')
    return api_client


@pytest.fixture
def stone_types(db):
    """Create stone types."""
    stones = []
    for name in ['Diamond', 'Emerald', 'Ruby', 'Sapphire', 'Pearl']:
        stone, _ = StoneType.objects.get_or_create(name=name)
        stones.append(stone)
    return stones


@pytest.fixture
def test_jewel(db, client_profile, stone_types):
    """Create a test jewel."""
    jewel = Jewel.objects.create(
        client=client_profile,
        jewel_type='Ring',
        current_stage='ghatt',
        ghatt_weight=10.5,
        stone_weight=0.5,
        net_weight=10.0,
        metal_weight=9.5
    )
    return jewel

