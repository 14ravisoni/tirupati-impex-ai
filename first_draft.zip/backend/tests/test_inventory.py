import pytest
from rest_framework import status
from apps.inventory.models import InventoryTransaction
from decimal import Decimal


@pytest.mark.django_db
class TestInventoryManagement:
    """Test inventory management endpoints."""
    
    def test_get_current_inventory(self, authenticated_client, client_profile):
        """Test getting current inventory."""
        response = authenticated_client.get('/api/v1/inventory/current/')
        assert response.status_code == status.HTTP_200_OK
        assert 'metal' in response.data
        assert 'points' in response.data
    
    def test_add_metal(self, authenticated_client, client_profile):
        """Test adding metal to inventory."""
        initial_metal = client_profile.metal_inventory
        data = {
            'amount': 5.5,
            'notes': 'Added metal'
        }
        response = authenticated_client.post('/api/v1/inventory/add-metal/', data)
        assert response.status_code == status.HTTP_201_CREATED
        client_profile.refresh_from_db()
        assert float(client_profile.metal_inventory) == float(initial_metal) + 5.5
        assert InventoryTransaction.objects.filter(
            client=client_profile,
            transaction_type='add_metal'
        ).exists()
    
    def test_withdraw_metal(self, authenticated_client, client_profile):
        """Test withdrawing metal from inventory."""
        client_profile.metal_inventory = Decimal('10.0')
        client_profile.save()
        
        data = {
            'amount': 3.0,
            'notes': 'Withdrawn metal'
        }
        response = authenticated_client.post('/api/v1/inventory/withdraw-metal/', data)
        assert response.status_code == status.HTTP_201_CREATED
        client_profile.refresh_from_db()
        assert float(client_profile.metal_inventory) == 7.0
    
    def test_withdraw_metal_insufficient(self, authenticated_client, client_profile):
        """Test withdrawing more metal than available."""
        client_profile.metal_inventory = Decimal('5.0')
        client_profile.save()
        
        data = {'amount': 10.0}
        response = authenticated_client.post('/api/v1/inventory/withdraw-metal/', data)
        assert response.status_code == status.HTTP_400_BAD_REQUEST
    
    def test_add_points(self, authenticated_client, client_profile):
        """Test adding points to inventory."""
        initial_points = client_profile.points_inventory
        data = {
            'amount': 1000.00,
            'notes': 'Added points'
        }
        response = authenticated_client.post('/api/v1/inventory/add-points/', data)
        assert response.status_code == status.HTTP_201_CREATED
        client_profile.refresh_from_db()
        assert float(client_profile.points_inventory) == float(initial_points) + 1000.00
    
    def test_withdraw_points(self, authenticated_client, client_profile):
        """Test withdrawing points from inventory."""
        client_profile.points_inventory = Decimal('5000.00')
        client_profile.save()
        
        data = {
            'amount': 2000.00,
            'notes': 'Withdrawn points'
        }
        response = authenticated_client.post('/api/v1/inventory/withdraw-points/', data)
        assert response.status_code == status.HTTP_201_CREATED
        client_profile.refresh_from_db()
        assert float(client_profile.points_inventory) == 3000.00
    
    def test_list_transactions(self, authenticated_client, client_profile):
        """Test listing inventory transactions."""
        InventoryTransaction.objects.create(
            client=client_profile,
            transaction_type='add_metal',
            metal_amount=Decimal('5.0'),
            balance_after_metal=Decimal('5.0'),
            balance_after_points=Decimal('0.0')
        )
        response = authenticated_client.get('/api/v1/inventory/transactions/')
        assert response.status_code == status.HTTP_200_OK
        assert len(response.data) >= 1

