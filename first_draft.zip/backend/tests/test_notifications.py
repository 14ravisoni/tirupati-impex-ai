import pytest
from rest_framework import status
from apps.notifications.models import Notification


@pytest.mark.django_db
class TestNotifications:
    """Test notification endpoints."""
    
    def test_list_notifications(self, authenticated_client, client_user):
        """Test listing notifications."""
        Notification.objects.create(
            user=client_user,
            notification_type='job_assigned',
            title='Test Notification',
            message='This is a test notification'
        )
        response = authenticated_client.get('/api/v1/notifications/')
        assert response.status_code == status.HTTP_200_OK
        assert len(response.data) >= 1
    
    def test_get_unread_notifications(self, authenticated_client, client_user):
        """Test getting unread notifications."""
        Notification.objects.create(
            user=client_user,
            notification_type='job_assigned',
            title='Unread Notification',
            message='This is unread',
            is_read=False
        )
        Notification.objects.create(
            user=client_user,
            notification_type='job_completed',
            title='Read Notification',
            message='This is read',
            is_read=True
        )
        response = authenticated_client.get('/api/v1/notifications/unread/')
        assert response.status_code == status.HTTP_200_OK
        assert all(not n['is_read'] for n in response.data)
    
    def test_get_unread_count(self, authenticated_client, client_user):
        """Test getting unread notification count."""
        Notification.objects.create(
            user=client_user,
            notification_type='job_assigned',
            title='Notification 1',
            message='Test',
            is_read=False
        )
        Notification.objects.create(
            user=client_user,
            notification_type='job_assigned',
            title='Notification 2',
            message='Test',
            is_read=False
        )
        response = authenticated_client.get('/api/v1/notifications/unread-count/')
        assert response.status_code == status.HTTP_200_OK
        assert response.data['unread_count'] >= 2
    
    def test_mark_notification_read(self, authenticated_client, client_user):
        """Test marking notification as read."""
        notification = Notification.objects.create(
            user=client_user,
            notification_type='job_assigned',
            title='Test Notification',
            message='Test',
            is_read=False
        )
        response = authenticated_client.post(f'/api/v1/notifications/{notification.id}/mark-read/')
        assert response.status_code == status.HTTP_200_OK
        notification.refresh_from_db()
        assert notification.is_read == True
    
    def test_mark_all_read(self, authenticated_client, client_user):
        """Test marking all notifications as read."""
        Notification.objects.create(
            user=client_user,
            notification_type='job_assigned',
            title='Notification 1',
            message='Test',
            is_read=False
        )
        Notification.objects.create(
            user=client_user,
            notification_type='job_assigned',
            title='Notification 2',
            message='Test',
            is_read=False
        )
        response = authenticated_client.post('/api/v1/notifications/mark-all-read/')
        assert response.status_code == status.HTTP_200_OK
        assert Notification.objects.filter(user=client_user, is_read=False).count() == 0

