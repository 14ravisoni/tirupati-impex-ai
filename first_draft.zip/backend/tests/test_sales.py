import pytest
from rest_framework import status
from apps.sales.models import Sale
from apps.jewels.models import Jewel


@pytest.mark.django_db
class TestSalesManagement:
    """Test sales management endpoints."""
    
    def test_create_sale_metal(self, authenticated_client, test_jewel):
        """Test creating a sale with metal payment."""
        test_jewel.current_stage = 'ready_to_sell'
        test_jewel.save()
        
        data = {
            'jewel': str(test_jewel.id),
            'buyer_name': 'Test Buyer',
            'buyer_phone': '+91-9876543213',
            'buyer_type': 'retailer',
            'payment_method': 'metal',
            'metal_amount': 8.5,
            'final_amount': 45000.00,
            'gold_price_per_gram': 5294.00
        }
        response = authenticated_client.post('/api/v1/sales/create/', data)
        assert response.status_code == status.HTTP_201_CREATED
        assert Sale.objects.filter(jewel=test_jewel).exists()
        
        # Verify jewel is marked as sold
        test_jewel.refresh_from_db()
        assert test_jewel.current_stage == 'sold'
        assert test_jewel.is_active == False
    
    def test_create_sale_points(self, authenticated_client, test_jewel):
        """Test creating a sale with points payment."""
        test_jewel.current_stage = 'ready_to_sell'
        test_jewel.save()
        
        data = {
            'jewel': str(test_jewel.id),
            'buyer_name': 'Test Buyer 2',
            'buyer_type': 'customer',
            'payment_method': 'points',
            'points_amount': 50000.00,
            'final_amount': 50000.00
        }
        response = authenticated_client.post('/api/v1/sales/create/', data)
        assert response.status_code == status.HTTP_201_CREATED
    
    def test_create_sale_wrong_stage(self, authenticated_client, test_jewel):
        """Test creating sale for jewel not ready to sell."""
        data = {
            'jewel': str(test_jewel.id),
            'buyer_name': 'Test Buyer',
            'buyer_type': 'retailer',
            'payment_method': 'metal',
            'metal_amount': 8.5,
            'final_amount': 45000.00
        }
        response = authenticated_client.post('/api/v1/sales/create/', data)
        assert response.status_code == status.HTTP_400_BAD_REQUEST
    
    def test_list_sales(self, authenticated_client, test_jewel):
        """Test listing sales."""
        test_jewel.current_stage = 'ready_to_sell'
        test_jewel.save()
        
        Sale.objects.create(
            jewel=test_jewel,
            client=test_jewel.client,
            buyer_name='Test Buyer',
            buyer_type='retailer',
            payment_method='metal',
            metal_amount=8.5,
            final_amount=45000.00
        )
        response = authenticated_client.get('/api/v1/sales/')
        assert response.status_code == status.HTTP_200_OK
        assert len(response.data) >= 1
    
    def test_get_sale_details(self, authenticated_client, test_jewel):
        """Test getting sale details."""
        test_jewel.current_stage = 'ready_to_sell'
        test_jewel.save()
        
        sale = Sale.objects.create(
            jewel=test_jewel,
            client=test_jewel.client,
            buyer_name='Test Buyer',
            buyer_type='retailer',
            payment_method='metal',
            metal_amount=8.5,
            final_amount=45000.00
        )
        response = authenticated_client.get(f'/api/v1/sales/{sale.id}/')
        assert response.status_code == status.HTTP_200_OK
        assert response.data['id'] == str(sale.id)
    
    def test_sales_report(self, authenticated_client, test_jewel):
        """Test generating sales report."""
        test_jewel.current_stage = 'ready_to_sell'
        test_jewel.save()
        
        Sale.objects.create(
            jewel=test_jewel,
            client=test_jewel.client,
            buyer_name='Test Buyer',
            buyer_type='retailer',
            payment_method='metal',
            metal_amount=8.5,
            final_amount=45000.00
        )
        response = authenticated_client.get('/api/v1/sales/report/')
        assert response.status_code == status.HTTP_200_OK
        assert 'summary' in response.data
        assert 'payment_methods' in response.data

