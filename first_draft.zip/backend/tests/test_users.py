import pytest
from rest_framework import status


@pytest.mark.django_db
class TestUserProfile:
    """Test user profile endpoints."""
    
    def test_get_current_user(self, authenticated_client, client_user):
        """Test getting current user profile."""
        response = authenticated_client.get('/api/v1/users/me/')
        assert response.status_code == status.HTTP_200_OK
        assert response.data['email'] == 'client@test.com'
        assert response.data['userType'] == 'client'
        assert 'client_profile' in response.data
    
    def test_get_current_user_unauthenticated(self, api_client):
        """Test getting user profile without authentication."""
        response = api_client.get('/api/v1/users/me/')
        assert response.status_code == status.HTTP_401_UNAUTHORIZED
    
    def test_update_profile(self, authenticated_client, client_profile):
        """Test updating user profile."""
        data = {
            'business_name': 'Updated Jewelers',
            'full_name': 'Updated Client',
            'phone': '+91-9999999999'
        }
        response = authenticated_client.put('/api/v1/users/me/update/', data)
        assert response.status_code == status.HTTP_200_OK
        assert response.data['client_profile']['business_name'] == 'Updated Jewelers'
        
        # Verify update
        client_profile.refresh_from_db()
        assert client_profile.business_name == 'Updated Jewelers'
        assert client_profile.full_name == 'Updated Client'
    
    def test_update_profile_partial(self, authenticated_client, client_profile):
        """Test partial profile update."""
        data = {'business_name': 'Partially Updated'}
        response = authenticated_client.put('/api/v1/users/me/update/', data)
        assert response.status_code == status.HTTP_200_OK
        client_profile.refresh_from_db()
        assert client_profile.business_name == 'Partially Updated'

