import pytest
from rest_framework import status
from apps.jewels.models import Jewel, JewelStone, JewelImage, StoneType


@pytest.mark.django_db
class TestJewelManagement:
    """Test jewel management endpoints."""
    
    def test_list_jewels(self, authenticated_client, test_jewel):
        """Test listing jewels."""
        response = authenticated_client.get('/api/v1/jewels/')
        assert response.status_code == status.HTTP_200_OK
        assert len(response.data) >= 1
    
    def test_create_jewel(self, authenticated_client):
        """Test creating a new jewel."""
        data = {
            'jewel_type': 'Necklace',
            'ghatt_weight': 15.5,
            'stone_weight': 1.0,
            'net_weight': 14.5,
            'metal_weight': 13.5
        }
        response = authenticated_client.post('/api/v1/jewels/create/', data)
        assert response.status_code == status.HTTP_201_CREATED
        assert response.data['jewel_type'] == 'Necklace'
        assert Jewel.objects.filter(jewel_type='Necklace').exists()
    
    def test_get_jewel_details(self, authenticated_client, test_jewel):
        """Test getting jewel details."""
        response = authenticated_client.get(f'/api/v1/jewels/{test_jewel.id}/')
        assert response.status_code == status.HTTP_200_OK
        assert response.data['id'] == str(test_jewel.id)
        assert response.data['jewel_type'] == 'Ring'
    
    def test_update_jewel(self, authenticated_client, test_jewel):
        """Test updating jewel."""
        data = {
            'jewel_type': 'Updated Ring',
            'current_stage': 'jadai'
        }
        response = authenticated_client.put(f'/api/v1/jewels/{test_jewel.id}/update/', data)
        assert response.status_code == status.HTTP_200_OK
        test_jewel.refresh_from_db()
        assert test_jewel.jewel_type == 'Updated Ring'
    
    def test_delete_jewel(self, authenticated_client, test_jewel):
        """Test soft deleting jewel."""
        response = authenticated_client.delete(f'/api/v1/jewels/{test_jewel.id}/delete/')
        assert response.status_code == status.HTTP_200_OK
        test_jewel.refresh_from_db()
        assert test_jewel.is_active == False
    
    def test_filter_jewels_by_stage(self, authenticated_client, test_jewel):
        """Test filtering jewels by stage."""
        response = authenticated_client.get('/api/v1/jewels/?stage=ghatt')
        assert response.status_code == status.HTTP_200_OK
        assert all(j['current_stage'] == 'ghatt' for j in response.data)
    
    def test_get_jewels_by_stage(self, authenticated_client, test_jewel):
        """Test getting jewels grouped by stage."""
        response = authenticated_client.get('/api/v1/jewels/by-stage/')
        assert response.status_code == status.HTTP_200_OK
        assert 'ghatt' in response.data
        assert isinstance(response.data['ghatt'], dict)


@pytest.mark.django_db
class TestJewelStones:
    """Test jewel stones endpoints."""
    
    def test_add_stone_to_jewel(self, authenticated_client, test_jewel, stone_types):
        """Test adding stone to jewel."""
        diamond = stone_types[0]
        data = {
            'stone_type_id': str(diamond.id),
            'quantity': 5,
            'carat': 2.5,
            'weight': 0.5,
            'price': 50000
        }
        response = authenticated_client.post(f'/api/v1/jewels/{test_jewel.id}/add-stone/', data)
        assert response.status_code == status.HTTP_201_CREATED
        assert JewelStone.objects.filter(jewel=test_jewel, stone_type=diamond).exists()
    
    def test_get_jewel_stones(self, authenticated_client, test_jewel, stone_types):
        """Test getting jewel stones."""
        diamond = stone_types[0]
        JewelStone.objects.create(
            jewel=test_jewel,
            stone_type=diamond,
            quantity=3,
            carat=1.5,
            weight=0.3,
            price=30000
        )
        response = authenticated_client.get(f'/api/v1/jewels/{test_jewel.id}/stones/')
        assert response.status_code == status.HTTP_200_OK
        assert len(response.data) >= 1


@pytest.mark.django_db
class TestJewelWeight:
    """Test jewel weight update."""
    
    def test_update_jewel_weight(self, authenticated_client, test_jewel):
        """Test updating jewel weight."""
        data = {
            'ghatt_weight': 11.0,
            'net_weight': 10.5,
            'metal_weight': 10.0
        }
        response = authenticated_client.put(f'/api/v1/jewels/{test_jewel.id}/update-weight/', data)
        assert response.status_code == status.HTTP_200_OK
        test_jewel.refresh_from_db()
        assert float(test_jewel.ghatt_weight) == 11.0

