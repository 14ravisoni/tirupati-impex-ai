import pytest
from rest_framework import status
from apps.jobs.models import Job
from apps.jewels.models import Jewel


@pytest.mark.django_db
class TestJobCreation:
    """Test job creation endpoints."""
    
    def test_create_job(self, authenticated_client, test_jewel, worker_profile):
        """Test creating a new job."""
        data = {
            'jewel': str(test_jewel.id),
            'worker': str(worker_profile.id),
            'job_stage': 'jadai',
            'job_description': 'Complete jadai work',
            'before_weight': 10.0
        }
        response = authenticated_client.post('/api/v1/jobs/create/', data)
        assert response.status_code == status.HTTP_201_CREATED
        assert response.data['job_stage'] == 'jadai'
        assert Job.objects.filter(jewel=test_jewel, worker=worker_profile).exists()
    
    def test_list_jobs(self, authenticated_client, test_jewel, worker_profile):
        """Test listing jobs."""
        Job.objects.create(
            jewel=test_jewel,
            client=test_jewel.client,
            worker=worker_profile,
            job_stage='jadai',
            before_weight=10.0
        )
        response = authenticated_client.get('/api/v1/jobs/')
        assert response.status_code == status.HTTP_200_OK
        assert len(response.data) >= 1
    
    def test_get_job_details(self, authenticated_client, test_jewel, worker_profile):
        """Test getting job details."""
        job = Job.objects.create(
            jewel=test_jewel,
            client=test_jewel.client,
            worker=worker_profile,
            job_stage='jadai',
            before_weight=10.0
        )
        response = authenticated_client.get(f'/api/v1/jobs/{job.id}/')
        assert response.status_code == status.HTTP_200_OK
        assert response.data['id'] == str(job.id)


@pytest.mark.django_db
class TestJobWorkflow:
    """Test job workflow endpoints."""
    
    def test_worker_accept_job(self, authenticated_worker, test_jewel, worker_profile):
        """Test worker accepting a job."""
        job = Job.objects.create(
            jewel=test_jewel,
            client=test_jewel.client,
            worker=worker_profile,
            job_stage='jadai',
            before_weight=10.0,
            status='pending_acceptance'
        )
        response = authenticated_worker.post(f'/api/v1/jobs/{job.id}/accept/')
        assert response.status_code == status.HTTP_200_OK
        job.refresh_from_db()
        assert job.status == 'accepted'
        assert job.accepted_at is not None
    
    def test_worker_reject_job(self, authenticated_worker, test_jewel, worker_profile):
        """Test worker rejecting a job."""
        job = Job.objects.create(
            jewel=test_jewel,
            client=test_jewel.client,
            worker=worker_profile,
            job_stage='jadai',
            before_weight=10.0,
            status='pending_acceptance'
        )
        data = {'reason': 'Too busy'}
        response = authenticated_worker.post(f'/api/v1/jobs/{job.id}/reject/', data)
        assert response.status_code == status.HTTP_200_OK
        job.refresh_from_db()
        assert job.status == 'rejected'
    
    def test_worker_start_job(self, authenticated_worker, test_jewel, worker_profile):
        """Test worker starting a job."""
        job = Job.objects.create(
            jewel=test_jewel,
            client=test_jewel.client,
            worker=worker_profile,
            job_stage='jadai',
            before_weight=10.0,
            status='accepted'
        )
        response = authenticated_worker.post(f'/api/v1/jobs/{job.id}/start/')
        assert response.status_code == status.HTTP_200_OK
        job.refresh_from_db()
        assert job.status == 'in_progress'
    
    def test_worker_submit_job(self, authenticated_worker, test_jewel, worker_profile):
        """Test worker submitting a job."""
        job = Job.objects.create(
            jewel=test_jewel,
            client=test_jewel.client,
            worker=worker_profile,
            job_stage='jadai',
            before_weight=10.0,
            status='in_progress'
        )
        data = {
            'after_weight': 9.8,
            'notes': 'Completed successfully'
        }
        response = authenticated_worker.post(f'/api/v1/jobs/{job.id}/submit/', data)
        assert response.status_code == status.HTTP_200_OK
        job.refresh_from_db()
        assert job.status == 'submitted_for_review'
        assert float(job.after_weight) == 9.8
    
    def test_client_approve_job(self, authenticated_client, test_jewel, worker_profile):
        """Test client approving a job."""
        job = Job.objects.create(
            jewel=test_jewel,
            client=test_jewel.client,
            worker=worker_profile,
            job_stage='jadai',
            before_weight=10.0,
            status='submitted_for_review'
        )
        data = {'notes': 'Approved'}
        response = authenticated_client.post(f'/api/v1/jobs/{job.id}/approve/', data)
        assert response.status_code == status.HTTP_200_OK
        job.refresh_from_db()
        assert job.status == 'completed'
        assert job.completed_at is not None
    
    def test_client_send_back_job(self, authenticated_client, test_jewel, worker_profile):
        """Test client sending job back."""
        job = Job.objects.create(
            jewel=test_jewel,
            client=test_jewel.client,
            worker=worker_profile,
            job_stage='jadai',
            before_weight=10.0,
            status='submitted_for_review'
        )
        data = {
            'reason': 'Weight mismatch',
            'notes': 'Please check weight'
        }
        response = authenticated_client.post(f'/api/v1/jobs/{job.id}/send-back/', data)
        assert response.status_code == status.HTTP_200_OK
        job.refresh_from_db()
        assert job.status == 'sent_back_by_client'
        assert job.client_send_back_count == 1


@pytest.mark.django_db
class TestJobListings:
    """Test job listing endpoints."""
    
    def test_get_my_jobs_worker(self, authenticated_worker, test_jewel, worker_profile):
        """Test worker getting their jobs."""
        Job.objects.create(
            jewel=test_jewel,
            client=test_jewel.client,
            worker=worker_profile,
            job_stage='jadai',
            before_weight=10.0
        )
        response = authenticated_worker.get('/api/v1/jobs/my-jobs/')
        assert response.status_code == status.HTTP_200_OK
        assert len(response.data) >= 1
    
    def test_get_pending_jobs(self, authenticated_worker, test_jewel, worker_profile):
        """Test getting pending acceptance jobs."""
        Job.objects.create(
            jewel=test_jewel,
            client=test_jewel.client,
            worker=worker_profile,
            job_stage='jadai',
            before_weight=10.0,
            status='pending_acceptance'
        )
        response = authenticated_worker.get('/api/v1/jobs/my-jobs/pending/')
        assert response.status_code == status.HTTP_200_OK
        assert len(response.data) >= 1
    
    def test_get_pending_review_jobs(self, authenticated_client, test_jewel, worker_profile):
        """Test getting pending review jobs."""
        Job.objects.create(
            jewel=test_jewel,
            client=test_jewel.client,
            worker=worker_profile,
            job_stage='jadai',
            before_weight=10.0,
            status='submitted_for_review'
        )
        response = authenticated_client.get('/api/v1/jobs/pending-review/')
        assert response.status_code == status.HTTP_200_OK
        assert len(response.data) >= 1

