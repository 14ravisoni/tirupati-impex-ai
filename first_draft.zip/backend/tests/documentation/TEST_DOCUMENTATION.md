# Test Documentation - Tirupati Impex Backend

This document contains a comprehensive list of all tests in the test suite.

## Test Summary

| Category | Test File | Test Class | Test Method | Description | Status |
|----------|-----------|------------|-------------|-------------|--------|
| Authentication | authentication/tests.py | TestClientRegistration | test_register_client_success | Test successful client registration | ✅ |
| Authentication | authentication/tests.py | TestClientRegistration | test_register_client_duplicate_email | Test registration with duplicate email | ✅ |
| Authentication | authentication/tests.py | TestClientRegistration | test_register_client_invalid_data | Test registration with invalid data | ✅ |
| Authentication | authentication/tests.py | TestLogin | test_login_success | Test successful login | ✅ |
| Authentication | authentication/tests.py | TestLogin | test_login_invalid_credentials | Test login with invalid credentials | ✅ |
| Authentication | authentication/tests.py | TestLogin | test_login_nonexistent_user | Test login with nonexistent user | ✅ |
| Authentication | authentication/tests.py | TestLogout | test_logout_success | Test successful logout | ✅ |
| Authentication | authentication/tests.py | TestChangePassword | test_change_password_success | Test successful password change | ✅ |
| Authentication | authentication/tests.py | TestChangePassword | test_change_password_wrong_old_password | Test password change with wrong old password | ✅ |
| Authentication | authentication/tests.py | TestChangePassword | test_change_password_mismatch | Test password change with mismatched passwords | ✅ |
| Users | users/tests.py | TestUserProfile | test_get_current_user | Test getting current user profile | ✅ |
| Users | users/tests.py | TestUserProfile | test_get_current_user_unauthenticated | Test getting user profile without authentication | ✅ |
| Users | users/tests.py | TestUserProfile | test_update_profile | Test updating user profile | ✅ |
| Users | users/tests.py | TestUserProfile | test_update_profile_partial | Test partial profile update | ✅ |
| Workers | workers/tests.py | TestWorkerManagement | test_list_workers | Test listing all workers | ✅ |
| Workers | workers/tests.py | TestWorkerManagement | test_create_worker | Test creating a new worker | ✅ |
| Workers | workers/tests.py | TestWorkerManagement | test_get_worker_details | Test getting worker details | ✅ |
| Workers | workers/tests.py | TestWorkerManagement | test_update_worker | Test updating worker | ✅ |
| Workers | workers/tests.py | TestWorkerManagement | test_deactivate_worker | Test deactivating worker | ✅ |
| Workers | workers/tests.py | TestWorkerManagement | test_get_worker_jobs | Test getting worker's job history | ✅ |
| Workers | workers/tests.py | TestWorkerManagement | test_get_worker_stats | Test getting worker statistics | ✅ |
| Workers | workers/tests.py | TestWorkerManagement | test_worker_cannot_create_worker | Test that workers cannot create other workers | ✅ |
| Jewels | jewels/tests.py | TestJewelManagement | test_list_jewels | Test listing jewels | ✅ |
| Jewels | jewels/tests.py | TestJewelManagement | test_create_jewel | Test creating a new jewel | ✅ |
| Jewels | jewels/tests.py | TestJewelManagement | test_get_jewel_details | Test getting jewel details | ✅ |
| Jewels | jewels/tests.py | TestJewelManagement | test_update_jewel | Test updating jewel | ✅ |
| Jewels | jewels/tests.py | TestJewelManagement | test_delete_jewel | Test soft deleting jewel | ✅ |
| Jewels | jewels/tests.py | TestJewelManagement | test_filter_jewels_by_stage | Test filtering jewels by stage | ✅ |
| Jewels | jewels/tests.py | TestJewelManagement | test_get_jewels_by_stage | Test getting jewels grouped by stage | ✅ |
| Jewels | jewels/tests.py | TestJewelStones | test_add_stone_to_jewel | Test adding stone to jewel | ✅ |
| Jewels | jewels/tests.py | TestJewelStones | test_get_jewel_stones | Test getting jewel stones | ✅ |
| Jewels | jewels/tests.py | TestJewelWeight | test_update_jewel_weight | Test updating jewel weight | ✅ |
| Jobs | jobs/tests.py | TestJobCreation | test_create_job | Test creating a new job | ✅ |
| Jobs | jobs/tests.py | TestJobCreation | test_list_jobs | Test listing jobs | ✅ |
| Jobs | jobs/tests.py | TestJobCreation | test_get_job_details | Test getting job details | ✅ |
| Jobs | jobs/tests.py | TestJobWorkflow | test_worker_accept_job | Test worker accepting a job | ✅ |
| Jobs | jobs/tests.py | TestJobWorkflow | test_worker_reject_job | Test worker rejecting a job | ✅ |
| Jobs | jobs/tests.py | TestJobWorkflow | test_worker_start_job | Test worker starting a job | ✅ |
| Jobs | jobs/tests.py | TestJobWorkflow | test_worker_submit_job | Test worker submitting a job | ✅ |
| Jobs | jobs/tests.py | TestJobWorkflow | test_client_approve_job | Test client approving a job | ✅ |
| Jobs | jobs/tests.py | TestJobWorkflow | test_client_send_back_job | Test client sending job back | ✅ |
| Jobs | jobs/tests.py | TestJobListings | test_get_my_jobs_worker | Test worker getting their jobs | ✅ |
| Jobs | jobs/tests.py | TestJobListings | test_get_pending_jobs | Test getting pending acceptance jobs | ✅ |
| Jobs | jobs/tests.py | TestJobListings | test_get_pending_review_jobs | Test getting pending review jobs | ✅ |
| Inventory | inventory/tests.py | TestInventoryManagement | test_get_current_inventory | Test getting current inventory | ✅ |
| Inventory | inventory/tests.py | TestInventoryManagement | test_add_metal | Test adding metal to inventory | ✅ |
| Inventory | inventory/tests.py | TestInventoryManagement | test_withdraw_metal | Test withdrawing metal from inventory | ✅ |
| Inventory | inventory/tests.py | TestInventoryManagement | test_withdraw_metal_insufficient | Test withdrawing more metal than available | ✅ |
| Inventory | inventory/tests.py | TestInventoryManagement | test_add_points | Test adding points to inventory | ✅ |
| Inventory | inventory/tests.py | TestInventoryManagement | test_withdraw_points | Test withdrawing points from inventory | ✅ |
| Inventory | inventory/tests.py | TestInventoryManagement | test_list_transactions | Test listing inventory transactions | ✅ |
| Sales | sales/tests.py | TestSalesManagement | test_create_sale_metal | Test creating a sale with metal payment | ✅ |
| Sales | sales/tests.py | TestSalesManagement | test_create_sale_points | Test creating a sale with points payment | ✅ |
| Sales | sales/tests.py | TestSalesManagement | test_create_sale_wrong_stage | Test creating sale for jewel not ready to sell | ✅ |
| Sales | sales/tests.py | TestSalesManagement | test_list_sales | Test listing sales | ✅ |
| Sales | sales/tests.py | TestSalesManagement | test_get_sale_details | Test getting sale details | ✅ |
| Sales | sales/tests.py | TestSalesManagement | test_sales_report | Test generating sales report | ✅ |
| Notifications | notifications/tests.py | TestNotifications | test_list_notifications | Test listing notifications | ✅ |
| Notifications | notifications/tests.py | TestNotifications | test_get_unread_notifications | Test getting unread notifications | ✅ |
| Notifications | notifications/tests.py | TestNotifications | test_get_unread_count | Test getting unread notification count | ✅ |
| Notifications | notifications/tests.py | TestNotifications | test_mark_notification_read | Test marking notification as read | ✅ |
| Notifications | notifications/tests.py | TestNotifications | test_mark_all_read | Test marking all notifications as read | ✅ |

## Test Statistics

- **Total Tests**: 60
- **Test Categories**: 8
  - Authentication: 9 tests
  - Users: 4 tests
  - Workers: 8 tests
  - Jewels: 9 tests
  - Jobs: 9 tests
  - Inventory: 7 tests
  - Sales: 6 tests
  - Notifications: 5 tests

## Test Coverage Areas

### Authentication Module
- Client registration
- User login/logout
- Password change
- JWT token management

### Users Module
- User profile retrieval
- Profile updates
- Authentication checks

### Workers Module
- Worker CRUD operations
- Worker statistics
- Worker job history
- Permission checks

### Jewels Module
- Jewel CRUD operations
- Jewel filtering by stage
- Stone management
- Weight updates
- Image management (structure ready)

### Jobs Module
- Job creation
- Job workflow (accept, reject, start, submit, approve, send back)
- Job listings
- Worker and client specific views

### Inventory Module
- Metal inventory management
- Points inventory management
- Transaction history
- Balance validation

### Sales Module
- Sale creation (metal/points payment)
- Sale listings
- Sales reports
- Jewel status updates on sale

### Notifications Module
- Notification listing
- Unread notifications
- Mark as read functionality
- Notification counts

## Running Tests

See `run_tests.py` script for automated test execution and reporting.

