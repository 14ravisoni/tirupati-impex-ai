# Testing Guide - Tirupati Impex Backend

## Overview

This project includes comprehensive pytest test suite covering all API endpoints and business logic.

## Test Statistics

- **Total Tests**: 60
- **Test Categories**: 8 modules
- **Coverage**: All major endpoints and workflows

## Quick Start

### Install Test Dependencies

```bash
pip install -r requirements/development.txt
```

### Run All Tests

**Windows:**
```cmd
python run_tests.py
```

**Linux/Mac:**
```bash
python run_tests.py
```

Or use the convenience scripts:
- Windows: `run_tests.bat`
- Linux/Mac: `run_tests.sh` (make executable: `chmod +x run_tests.sh`)

### Run Tests with Options

```bash
# Verbose output
python run_tests.py --verbose

# Generate JSON coverage report
python run_tests.py --json

# Both
python run_tests.py --verbose --json
```

### Run Tests Directly with pytest

```bash
# Run all tests
pytest

# Run specific test file
pytest apps/authentication/tests.py

# Run specific test class
pytest apps/authentication/tests.py::TestLogin

# Run specific test
pytest apps/authentication/tests.py::TestLogin::test_login_success

# Run with coverage
pytest --cov=apps --cov-report=html

# Run in parallel (faster)
pytest -n auto
```

## Test Structure

```
apps/
├── authentication/
│   └── tests.py          # 9 tests - Registration, login, logout, password
├── users/
│   └── tests.py          # 4 tests - Profile management
├── workers/
│   └── tests.py          # 8 tests - Worker CRUD and management
├── jewels/
│   └── tests.py          # 9 tests - Jewel CRUD, stones, weight
├── jobs/
│   └── tests.py          # 9 tests - Job workflow and management
├── inventory/
│   └── tests.py          # 7 tests - Inventory operations
├── sales/
│   └── tests.py          # 6 tests - Sales management
└── notifications/
    └── tests.py          # 5 tests - Notification system
```

## Test Documentation

- **TEST_DOCUMENTATION.md** - Detailed markdown documentation
- **TEST_DOCUMENTATION.csv** - Test list in CSV format (can be opened in Excel)

## Test Reports

After running tests, you'll find:

- **test_report.txt** - Text summary report
- **test_report.json** - JSON summary report
- **htmlcov/** - HTML coverage report (open `htmlcov/index.html` in browser)
- **coverage.json** - JSON coverage data (if --json flag used)

## Test Coverage

The test suite covers:

### Authentication (9 tests)
- ✅ Client registration (success, duplicate, invalid)
- ✅ Login (success, invalid credentials, nonexistent user)
- ✅ Logout
- ✅ Password change (success, wrong password, mismatch)

### Users (4 tests)
- ✅ Get current user profile
- ✅ Unauthenticated access
- ✅ Update profile (full and partial)

### Workers (8 tests)
- ✅ List workers
- ✅ Create worker
- ✅ Get worker details
- ✅ Update worker
- ✅ Deactivate worker
- ✅ Get worker jobs
- ✅ Get worker statistics
- ✅ Permission checks

### Jewels (9 tests)
- ✅ List jewels
- ✅ Create jewel
- ✅ Get jewel details
- ✅ Update jewel
- ✅ Delete jewel (soft delete)
- ✅ Filter by stage
- ✅ Get jewels by stage
- ✅ Add stones to jewel
- ✅ Update jewel weight

### Jobs (9 tests)
- ✅ Create job
- ✅ List jobs
- ✅ Get job details
- ✅ Worker accept job
- ✅ Worker reject job
- ✅ Worker start job
- ✅ Worker submit job
- ✅ Client approve job
- ✅ Client send back job
- ✅ Job listings (my jobs, pending, pending review)

### Inventory (7 tests)
- ✅ Get current inventory
- ✅ Add metal
- ✅ Withdraw metal
- ✅ Insufficient metal check
- ✅ Add points
- ✅ Withdraw points
- ✅ List transactions

### Sales (6 tests)
- ✅ Create sale (metal payment)
- ✅ Create sale (points payment)
- ✅ Create sale wrong stage
- ✅ List sales
- ✅ Get sale details
- ✅ Sales report

### Notifications (5 tests)
- ✅ List notifications
- ✅ Get unread notifications
- ✅ Get unread count
- ✅ Mark notification as read
- ✅ Mark all as read

## Running Specific Test Categories

```bash
# Run only authentication tests
pytest apps/authentication/tests.py

# Run only job workflow tests
pytest apps/jobs/tests.py::TestJobWorkflow

# Run tests matching a pattern
pytest -k "test_create"

# Run tests excluding a pattern
pytest -k "not test_create"
```

## Continuous Integration

The test suite is designed to run in CI/CD pipelines:

```yaml
# Example GitHub Actions
- name: Run tests
  run: |
    pip install -r requirements/development.txt
    pytest --cov=apps --cov-report=xml
```

## Troubleshooting

### Tests fail with database errors
- Ensure PostgreSQL is running
- Check database connection in `.env`
- Run migrations: `python manage.py migrate`

### Import errors
- Ensure virtual environment is activated
- Install dependencies: `pip install -r requirements/development.txt`

### Coverage not showing
- Ensure pytest-cov is installed
- Check that `--cov=apps` is in pytest.ini or command

## Best Practices

1. **Run tests before committing**: `python run_tests.py`
2. **Check coverage**: Aim for >80% coverage
3. **Fix failing tests immediately**: Don't commit with failing tests
4. **Add tests for new features**: Every new endpoint should have tests
5. **Keep tests isolated**: Each test should be independent

## Test Fixtures

The test suite uses pytest fixtures defined in `conftest.py`:

- `api_client` - Unauthenticated API client
- `client_user` - Test client user
- `client_profile` - Client profile
- `worker_user` - Test worker user
- `worker_profile` - Worker profile
- `authenticated_client` - Authenticated client API client
- `authenticated_worker` - Authenticated worker API client
- `stone_types` - Pre-created stone types
- `test_jewel` - Test jewel instance

## Adding New Tests

When adding new tests:

1. Create test in appropriate app's `tests.py`
2. Use existing fixtures from `conftest.py`
3. Follow naming convention: `test_<functionality>`
4. Add test to TEST_DOCUMENTATION.csv
5. Update TEST_DOCUMENTATION.md

Example:
```python
@pytest.mark.django_db
class TestNewFeature:
    def test_new_endpoint(self, authenticated_client):
        response = authenticated_client.get('/api/v1/new-endpoint/')
        assert response.status_code == status.HTTP_200_OK
```

