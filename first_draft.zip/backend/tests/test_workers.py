import pytest
from rest_framework import status
from apps.workers.models import Worker


@pytest.mark.django_db
class TestWorkerManagement:
    """Test worker management endpoints."""
    
    def test_list_workers(self, authenticated_client, worker_profile):
        """Test listing all workers."""
        response = authenticated_client.get('/api/v1/workers/')
        assert response.status_code == status.HTTP_200_OK
        assert len(response.data) >= 1
        assert any(w['id'] == str(worker_profile.id) for w in response.data)
    
    def test_create_worker(self, authenticated_client, client_profile):
        """Test creating a new worker."""
        data = {
            'email': 'newworker@test.com',
            'password': 'workerpass123',
            'full_name': 'New Worker',
            'nickname': 'NW',
            'phone': '+91-9876543212'
        }
        response = authenticated_client.post('/api/v1/workers/create/', data)
        assert response.status_code == status.HTTP_201_CREATED
        assert response.data['full_name'] == 'New Worker'
        assert Worker.objects.filter(user__email='newworker@test.com').exists()
    
    def test_get_worker_details(self, authenticated_client, worker_profile):
        """Test getting worker details."""
        response = authenticated_client.get(f'/api/v1/workers/{worker_profile.id}/')
        assert response.status_code == status.HTTP_200_OK
        assert response.data['id'] == str(worker_profile.id)
        assert response.data['full_name'] == 'Test Worker'
    
    def test_update_worker(self, authenticated_client, worker_profile):
        """Test updating worker."""
        data = {
            'full_name': 'Updated Worker',
            'nickname': 'UW'
        }
        response = authenticated_client.put(f'/api/v1/workers/{worker_profile.id}/update/', data)
        assert response.status_code == status.HTTP_200_OK
        worker_profile.refresh_from_db()
        assert worker_profile.full_name == 'Updated Worker'
    
    def test_deactivate_worker(self, authenticated_client, worker_profile):
        """Test deactivating worker."""
        response = authenticated_client.delete(f'/api/v1/workers/{worker_profile.id}/deactivate/')
        assert response.status_code == status.HTTP_200_OK
        worker_profile.user.refresh_from_db()
        assert worker_profile.user.is_active == False
    
    def test_get_worker_jobs(self, authenticated_client, worker_profile):
        """Test getting worker's job history."""
        response = authenticated_client.get(f'/api/v1/workers/{worker_profile.id}/jobs/')
        assert response.status_code == status.HTTP_200_OK
        assert isinstance(response.data, list)
    
    def test_get_worker_stats(self, authenticated_client, worker_profile):
        """Test getting worker statistics."""
        response = authenticated_client.get(f'/api/v1/workers/{worker_profile.id}/stats/')
        assert response.status_code == status.HTTP_200_OK
        assert 'total_jobs_assigned' in response.data
        assert 'acceptance_rate' in response.data
    
    def test_worker_cannot_create_worker(self, authenticated_worker):
        """Test that workers cannot create other workers."""
        data = {
            'email': 'unauthorized@test.com',
            'password': 'pass123',
            'full_name': 'Unauthorized Worker'
        }
        response = authenticated_worker.post('/api/v1/workers/create/', data)
        assert response.status_code == status.HTTP_403_FORBIDDEN

