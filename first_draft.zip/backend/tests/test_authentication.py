import pytest
from django.contrib.auth import get_user_model
from apps.users.models import Client
from rest_framework import status

User = get_user_model()


@pytest.mark.django_db
class TestClientRegistration:
    """Test client registration endpoint."""
    
    def test_register_client_success(self, api_client):
        """Test successful client registration."""
        data = {
            'email': 'newclient@test.com',
            'password': 'testpass123',
            'business_name': 'New Jewelers',
            'full_name': 'New Client',
            'phone': '+91-9876543211'
        }
        response = api_client.post('/api/v1/auth/register/client/', data)
        assert response.status_code == status.HTTP_201_CREATED
        assert 'access' in response.data
        assert 'refresh' in response.data
        assert 'user' in response.data
        assert response.data['user']['email'] == 'newclient@test.com'
        assert response.data['user']['userType'] == 'client'
    
    def test_register_client_duplicate_email(self, api_client, client_user):
        """Test registration with duplicate email."""
        data = {
            'email': 'client@test.com',
            'password': 'testpass123',
            'business_name': 'Duplicate Jewelers',
            'full_name': 'Duplicate Client'
        }
        response = api_client.post('/api/v1/auth/register/client/', data)
        assert response.status_code == status.HTTP_400_BAD_REQUEST
    
    def test_register_client_invalid_data(self, api_client):
        """Test registration with invalid data."""
        data = {
            'email': 'invalid-email',
            'password': '123',  # Too short
        }
        response = api_client.post('/api/v1/auth/register/client/', data)
        assert response.status_code == status.HTTP_400_BAD_REQUEST


@pytest.mark.django_db
class TestLogin:
    """Test login endpoint."""
    
    def test_login_success(self, api_client, client_user):
        """Test successful login."""
        data = {
            'email': 'client@test.com',
            'password': 'testpass123'
        }
        response = api_client.post('/api/v1/auth/login/', data)
        assert response.status_code == status.HTTP_200_OK
        assert 'access' in response.data
        assert 'refresh' in response.data
        assert 'user' in response.data
    
    def test_login_invalid_credentials(self, api_client):
        """Test login with invalid credentials."""
        data = {
            'email': 'client@test.com',
            'password': 'wrongpassword'
        }
        response = api_client.post('/api/v1/auth/login/', data)
        assert response.status_code == status.HTTP_401_UNAUTHORIZED
    
    def test_login_nonexistent_user(self, api_client):
        """Test login with nonexistent user."""
        data = {
            'email': 'nonexistent@test.com',
            'password': 'testpass123'
        }
        response = api_client.post('/api/v1/auth/login/', data)
        assert response.status_code == status.HTTP_401_UNAUTHORIZED


@pytest.mark.django_db
class TestLogout:
    """Test logout endpoint."""
    
    def test_logout_success(self, authenticated_client, client_user):
        """Test successful logout."""
        # Get refresh token
        from rest_framework_simplejwt.tokens import RefreshToken
        refresh = RefreshToken.for_user(client_user)
        
        data = {'refresh': str(refresh)}
        response = authenticated_client.post('/api/v1/auth/logout/', data)
        assert response.status_code == status.HTTP_200_OK


@pytest.mark.django_db
class TestChangePassword:
    """Test change password endpoint."""
    
    def test_change_password_success(self, authenticated_client, client_user):
        """Test successful password change."""
        data = {
            'old_password': 'testpass123',
            'new_password': 'newpass123',
            'confirm_password': 'newpass123'
        }
        response = authenticated_client.post('/api/v1/auth/change-password/', data)
        assert response.status_code == status.HTTP_200_OK
        
        # Verify new password works
        from rest_framework.test import APIClient
        client = APIClient()
        login_data = {
            'email': 'client@test.com',
            'password': 'newpass123'
        }
        login_response = client.post('/api/v1/auth/login/', login_data)
        assert login_response.status_code == status.HTTP_200_OK
    
    def test_change_password_wrong_old_password(self, authenticated_client):
        """Test password change with wrong old password."""
        data = {
            'old_password': 'wrongpassword',
            'new_password': 'newpass123',
            'confirm_password': 'newpass123'
        }
        response = authenticated_client.post('/api/v1/auth/change-password/', data)
        assert response.status_code == status.HTTP_400_BAD_REQUEST
    
    def test_change_password_mismatch(self, authenticated_client):
        """Test password change with mismatched passwords."""
        data = {
            'old_password': 'testpass123',
            'new_password': 'newpass123',
            'confirm_password': 'differentpass'
        }
        response = authenticated_client.post('/api/v1/auth/change-password/', data)
        assert response.status_code == status.HTTP_400_BAD_REQUEST

