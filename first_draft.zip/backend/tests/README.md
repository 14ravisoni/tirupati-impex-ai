# Testing Guide - Tirupati Impex Backend

## Overview

This directory contains all test files for the Tirupati Impex Backend project. Tests are organized by module and use pytest for execution.

## Directory Structure

```
tests/
├── __init__.py
├── conftest.py              # Shared pytest fixtures
├── test_authentication.py   # Authentication tests
├── test_users.py           # User profile tests
├── test_workers.py         # Worker management tests
├── test_jewels.py          # Jewel management tests
├── test_jobs.py            # Job workflow tests
├── test_inventory.py       # Inventory management tests
├── test_sales.py           # Sales management tests
├── test_notifications.py   # Notification tests
├── documentation/          # Test documentation
│   ├── TEST_DOCUMENTATION.md
│   ├── TEST_DOCUMENTATION.csv
│   └── TEST_README.md
└── output/                 # Test output and reports
    ├── test_report.txt
    ├── test_report.json
    ├── coverage.json
    └── htmlcov/
        └── index.html
```

## Quick Start

### Install Test Dependencies

```bash
pip install -r requirements/development.txt
```

### Run All Tests

**Windows:**
```cmd
python run_tests.py
```

**Linux/Mac:**
```bash
python run_tests.py
```

Or use the convenience scripts:
- Windows: `run_tests.bat`
- Linux/Mac: `run_tests.sh` (make executable: `chmod +x run_tests.sh`)

### Run Tests with Options

```bash
# Verbose output
python run_tests.py --verbose

# Generate JSON coverage report
python run_tests.py --json

# Both
python run_tests.py --verbose --json
```

### Run Tests Directly with pytest

```bash
# Run all tests
pytest

# Run specific test file
pytest tests/test_authentication.py

# Run specific test class
pytest tests/test_authentication.py::TestLogin

# Run specific test
pytest tests/test_authentication.py::TestLogin::test_login_success

# Run with coverage
pytest --cov=apps --cov-report=html:tests/output/htmlcov

# Run in parallel (faster)
pytest -n auto
```

## Test Statistics

- **Total Tests**: 60
- **Test Categories**: 8 modules
- **Coverage**: All major endpoints and workflows

## Test Coverage Areas

### Authentication Module (9 tests)
- Client registration
- User login/logout
- Password change
- JWT token management

### Users Module (4 tests)
- User profile retrieval
- Profile updates
- Authentication checks

### Workers Module (8 tests)
- Worker CRUD operations
- Worker statistics
- Worker job history
- Permission checks

### Jewels Module (9 tests)
- Jewel CRUD operations
- Jewel filtering by stage
- Stone management
- Weight updates

### Jobs Module (9 tests)
- Job creation
- Job workflow (accept, reject, start, submit, approve, send back)
- Job listings
- Worker and client specific views

### Inventory Module (7 tests)
- Metal inventory management
- Points inventory management
- Transaction history
- Balance validation

### Sales Module (6 tests)
- Sale creation (metal/points payment)
- Sale listings
- Sales reports
- Jewel status updates on sale

### Notifications Module (5 tests)
- Notification listing
- Unread notifications
- Mark as read functionality
- Notification counts

## Test Reports

After running tests, you'll find reports in `tests/output/`:

- **test_report.txt** - Text summary report
- **test_report.json** - JSON summary report
- **htmlcov/index.html** - HTML coverage report (open in browser)
- **coverage.json** - JSON coverage data (if --json flag used)

## Test Documentation

See `tests/documentation/` for:
- **TEST_DOCUMENTATION.md** - Detailed markdown documentation
- **TEST_DOCUMENTATION.csv** - Test list in CSV format (can be opened in Excel)
- **TEST_README.md** - Complete testing guide

## Running Specific Test Categories

```bash
# Run only authentication tests
pytest tests/test_authentication.py

# Run only job workflow tests
pytest tests/test_jobs.py::TestJobWorkflow

# Run tests matching a pattern
pytest -k "test_create"

# Run tests excluding a pattern
pytest -k "not test_create"
```

## Continuous Integration

The test suite is designed to run in CI/CD pipelines:

```yaml
# Example GitHub Actions
- name: Run tests
  run: |
    pip install -r requirements/development.txt
    pytest --cov=apps --cov-report=xml:tests/output/coverage.xml
```

## Troubleshooting

### Tests fail with database errors
- Ensure PostgreSQL is running
- Check database connection in `.env`
- Run migrations: `python manage.py migrate`
- Ensure user has CREATEDB permission: `ALTER USER tirupati CREATEDB;`

### Import errors
- Ensure virtual environment is activated
- Install dependencies: `pip install -r requirements/development.txt`

### Coverage not showing
- Ensure pytest-cov is installed
- Check that `--cov=apps` is in pytest.ini or command

## Best Practices

1. **Run tests before committing**: `python run_tests.py`
2. **Check coverage**: Aim for >80% coverage
3. **Fix failing tests immediately**: Don't commit with failing tests
4. **Add tests for new features**: Every new endpoint should have tests
5. **Keep tests isolated**: Each test should be independent

## Test Fixtures

The test suite uses pytest fixtures defined in `tests/conftest.py`:

- `api_client` - Unauthenticated API client
- `client_user` - Test client user
- `client_profile` - Client profile
- `worker_user` - Test worker user
- `worker_profile` - Worker profile
- `authenticated_client` - Authenticated client API client
- `authenticated_worker` - Authenticated worker API client
- `stone_types` - Pre-created stone types
- `test_jewel` - Test jewel instance

## Adding New Tests

When adding new tests:

1. Create test in appropriate `test_*.py` file in `tests/` directory
2. Use existing fixtures from `tests/conftest.py`
3. Follow naming convention: `test_<functionality>`
4. Add test to `tests/documentation/TEST_DOCUMENTATION.csv`
5. Update `tests/documentation/TEST_DOCUMENTATION.md`

Example:
```python
@pytest.mark.django_db
class TestNewFeature:
    def test_new_endpoint(self, authenticated_client):
        response = authenticated_client.get('/api/v1/new-endpoint/')
        assert response.status_code == status.HTTP_200_OK
```

