from django.urls import path
from . import views

urlpatterns = [
    path('me/', views.get_current_user, name='get_current_user'),
    path('me/update/', views.update_profile, name='update_profile'),
]

