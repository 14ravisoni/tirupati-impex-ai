from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from apps.jewels.models import Jewel
from apps.jobs.models import Job
from apps.sales.models import Sale
from django.db.models import Count, Sum, Q
from django.utils import timezone
from datetime import timedelta


@api_view(['GET'])
@permission_classes([IsAuthenticated])
def dashboard_summary(request):
    user = request.user
    if user.user_type != 'client' or not hasattr(user, 'client_profile'):
        return Response({'error': 'Only clients can access dashboard'}, status=403)
    
    client = user.client_profile
    
    # Jewel statistics
    total_jewels = Jewel.objects.filter(client=client, is_active=True).count()
    jewels_by_stage = Jewel.objects.filter(client=client, is_active=True).values('current_stage').annotate(count=Count('id'))
    
    # Job statistics
    total_jobs = Job.objects.filter(client=client).count()
    pending_jobs = Job.objects.filter(client=client, status='pending_acceptance').count()
    in_progress_jobs = Job.objects.filter(client=client, status__in=['accepted', 'in_progress']).count()
    pending_review_jobs = Job.objects.filter(client=client, status='submitted_for_review').count()
    
    # Sales statistics (last 30 days)
    thirty_days_ago = timezone.now() - timedelta(days=30)
    recent_sales = Sale.objects.filter(client=client, created_at__gte=thirty_days_ago)
    total_sales_amount = recent_sales.aggregate(total=Sum('final_amount'))['total'] or 0
    total_sales_count = recent_sales.count()
    
    return Response({
        'jewels': {
            'total': total_jewels,
            'by_stage': {item['current_stage']: item['count'] for item in jewels_by_stage}
        },
        'jobs': {
            'total': total_jobs,
            'pending_acceptance': pending_jobs,
            'in_progress': in_progress_jobs,
            'pending_review': pending_review_jobs
        },
        'sales': {
            'total_count': total_sales_count,
            'total_amount': float(total_sales_amount),
            'period': 'last_30_days'
        },
        'inventory': {
            'metal': float(client.metal_inventory),
            'points': float(client.points_inventory)
        }
    })


@api_view(['GET'])
@permission_classes([IsAuthenticated])
def jewels_by_stage(request):
    user = request.user
    if user.user_type != 'client' or not hasattr(user, 'client_profile'):
        return Response({'error': 'Only clients can access dashboard'}, status=403)
    
    client = user.client_profile
    jewels_by_stage = Jewel.objects.filter(client=client, is_active=True).values('current_stage').annotate(count=Count('id'))
    
    stage_data = {item['current_stage']: item['count'] for item in jewels_by_stage}
    
    # Ensure all stages are represented
    all_stages = ['ghatt', 'jadai', 'chilai', 'pakai', 'gold_ready', 'ready_to_sell', 'sold']
    result = {stage: stage_data.get(stage, 0) for stage in all_stages}
    
    return Response(result)

