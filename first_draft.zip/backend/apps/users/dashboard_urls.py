from django.urls import path
from . import dashboard_views

urlpatterns = [
    path('summary/', dashboard_views.dashboard_summary, name='dashboard_summary'),
    path('jewels-by-stage/', dashboard_views.jewels_by_stage, name='jewels_by_stage'),
]

