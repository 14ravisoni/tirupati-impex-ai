from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework import status
from django.contrib.auth import update_session_auth_hash
from .serializers import UserSerializer, ClientSerializer, ChangePasswordSerializer


@api_view(['GET'])
@permission_classes([IsAuthenticated])
def get_current_user(request):
    serializer = UserSerializer(request.user)
    return Response(serializer.data)


@api_view(['PUT'])
@permission_classes([IsAuthenticated])
def update_profile(request):
    user = request.user
    if user.user_type == 'client' and hasattr(user, 'client_profile'):
        serializer = ClientSerializer(user.client_profile, data=request.data, partial=True)
        if serializer.is_valid():
            serializer.save()
            # Update phone if provided
            if 'phone' in request.data:
                user.phone = request.data['phone']
                user.save(update_fields=['phone'])
            return Response(UserSerializer(user).data)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
    return Response({'error': 'Invalid user type'}, status=status.HTTP_400_BAD_REQUEST)

