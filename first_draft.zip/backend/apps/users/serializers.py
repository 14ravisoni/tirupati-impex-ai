from rest_framework import serializers
from .models import User, Client


class ClientSerializer(serializers.ModelSerializer):
    class Meta:
        model = Client
        fields = ['id', 'business_name', 'full_name', 'address', 
                  'metal_inventory', 'points_inventory', 'created_at']


class UserSerializer(serializers.ModelSerializer):
    client_profile = ClientSerializer(read_only=True)
    userType = serializers.CharField(source='user_type', read_only=True)
    
    class Meta:
        model = User
        fields = ['id', 'email', 'userType', 'phone', 'client_profile', 'created_at']


class ChangePasswordSerializer(serializers.Serializer):
    old_password = serializers.CharField(required=True, write_only=True)
    new_password = serializers.CharField(required=True, write_only=True, min_length=8)
    confirm_password = serializers.CharField(required=True, write_only=True)
    
    def validate(self, attrs):
        if attrs['new_password'] != attrs['confirm_password']:
            raise serializers.ValidationError("New passwords don't match")
        return attrs

