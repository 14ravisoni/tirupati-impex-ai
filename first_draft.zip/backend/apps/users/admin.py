from django.contrib import admin
from django.contrib.auth.admin import UserAdmin as BaseUserAdmin
from .models import User, Client


@admin.register(User)
class UserAdmin(BaseUserAdmin):
    list_display = ['email', 'user_type', 'phone', 'is_active', 'is_staff', 'created_at']
    list_filter = ['user_type', 'is_active', 'is_staff', 'created_at']
    search_fields = ['email', 'phone']
    ordering = ['-created_at']
    
    # Remove filter_horizontal since our User model doesn't have groups/user_permissions
    filter_horizontal = []
    
    # Fieldsets for add/edit form
    fieldsets = (
        (None, {'fields': ('email', 'password')}),
        ('Permissions', {'fields': ('is_active', 'is_staff', 'is_superuser')}),
        ('Custom Fields', {'fields': ('user_type', 'phone')}),
        ('Important dates', {'fields': ('last_login', 'created_at', 'updated_at')}),
    )
    
    # Fieldsets for add form
    add_fieldsets = (
        (None, {
            'classes': ('wide',),
            'fields': ('email', 'password1', 'password2', 'user_type', 'phone', 'is_staff', 'is_superuser'),
        }),
    )
    
    readonly_fields = ['last_login', 'created_at', 'updated_at']


@admin.register(Client)
class ClientAdmin(admin.ModelAdmin):
    list_display = ['business_name', 'full_name', 'email', 'metal_inventory', 'points_inventory', 'created_at']
    list_filter = ['created_at']
    search_fields = ['business_name', 'full_name', 'user__email']
    readonly_fields = ['created_at', 'updated_at']
    
    def email(self, obj):
        return obj.user.email
    email.short_description = 'Email'

