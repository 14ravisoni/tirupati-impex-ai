from rest_framework import serializers
from .models import Sale
from apps.jewels.serializers import JewelSerializer


class SaleSerializer(serializers.ModelSerializer):
    jewel = JewelSerializer(read_only=True)
    jewel_id = serializers.UUIDField(write_only=True)
    
    class Meta:
        model = Sale
        fields = ['id', 'jewel', 'jewel_id', 'buyer_name', 'buyer_phone', 'buyer_type',
                  'payment_method', 'metal_amount', 'points_amount', 'final_amount',
                  'gold_price_per_gram', 'notes', 'created_at']
    
    def create(self, validated_data):
        jewel_id = validated_data.pop('jewel_id')
        jewel = self.context['jewel']
        client = self.context['request'].user.client_profile
        return Sale.objects.create(jewel=jewel, client=client, **validated_data)


class SaleCreateSerializer(serializers.ModelSerializer):
    class Meta:
        model = Sale
        fields = ['jewel', 'buyer_name', 'buyer_phone', 'buyer_type', 'payment_method',
                  'metal_amount', 'points_amount', 'final_amount', 'gold_price_per_gram', 'notes']
    
    def validate(self, attrs):
        payment_method = attrs.get('payment_method')
        metal_amount = attrs.get('metal_amount')
        points_amount = attrs.get('points_amount')
        
        if payment_method == 'metal' and not metal_amount:
            raise serializers.ValidationError("metal_amount is required for metal payment")
        if payment_method == 'points' and not points_amount:
            raise serializers.ValidationError("points_amount is required for points payment")
        
        return attrs
    
    def create(self, validated_data):
        client = self.context['request'].user.client_profile
        return Sale.objects.create(client=client, **validated_data)

