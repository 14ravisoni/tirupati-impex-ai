from django.db.models.signals import post_save
from django.dispatch import receiver
from .models import Sale
from apps.inventory.models import InventoryTransaction


@receiver(post_save, sender=Sale)
def update_inventory_on_sale(sender, instance, created, **kwargs):
    if created:
        client = instance.client
        
        if instance.payment_method == 'metal':
            # Add metal to inventory
            client.metal_inventory += instance.metal_amount
            client.save(update_fields=['metal_inventory'])
            
            # Create transaction
            InventoryTransaction.objects.create(
                client=client,
                transaction_type='sale_metal',
                metal_amount=instance.metal_amount,
                balance_after_metal=client.metal_inventory,
                balance_after_points=client.points_inventory,
                reference_id=instance.id,
                notes=f'Sale of {instance.jewel.jewel_type}'
            )
        elif instance.payment_method == 'points':
            # Add points to inventory
            client.points_inventory += instance.points_amount
            client.save(update_fields=['points_inventory'])
            
            # Create transaction
            InventoryTransaction.objects.create(
                client=client,
                transaction_type='sale_points',
                points_amount=instance.points_amount,
                balance_after_metal=client.metal_inventory,
                balance_after_points=client.points_inventory,
                reference_id=instance.id,
                notes=f'Sale of {instance.jewel.jewel_type}'
            )

