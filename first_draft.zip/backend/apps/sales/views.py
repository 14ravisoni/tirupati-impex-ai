from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework import status
from django.shortcuts import get_object_or_404
from django.db.models import Sum
from django.utils import timezone
from datetime import timedelta
from .models import Sale
from .serializers import SaleSerializer, SaleCreateSerializer
from apps.authentication.permissions import IsClient
from apps.jewels.models import Jewel


@api_view(['GET'])
@permission_classes([IsAuthenticated, IsClient])
def list_sales(request):
    client = request.user.client_profile
    sales = Sale.objects.filter(client=client)
    
    # Filtering
    payment_method = request.query_params.get('payment_method')
    if payment_method:
        sales = sales.filter(payment_method=payment_method)
    
    buyer_type = request.query_params.get('buyer_type')
    if buyer_type:
        sales = sales.filter(buyer_type=buyer_type)
    
    serializer = SaleSerializer(sales, many=True)
    return Response(serializer.data)


@api_view(['POST'])
@permission_classes([IsAuthenticated, IsClient])
def create_sale(request):
    serializer = SaleCreateSerializer(data=request.data, context={'request': request})
    if serializer.is_valid():
        jewel_id = serializer.validated_data['jewel'].id
        jewel = get_object_or_404(Jewel, id=jewel_id, client=request.user.client_profile)
        
        if jewel.current_stage != 'ready_to_sell':
            return Response({'error': 'Jewel must be in ready_to_sell stage'}, status=status.HTTP_400_BAD_REQUEST)
        
        sale = serializer.save()
        
        # Update jewel status
        jewel.current_stage = 'sold'
        jewel.is_active = False
        jewel.sold_at = timezone.now()
        jewel.sold_stage_at = timezone.now()
        jewel.save()
        
        return Response(SaleSerializer(sale).data, status=status.HTTP_201_CREATED)
    return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


@api_view(['GET'])
@permission_classes([IsAuthenticated, IsClient])
def get_sale(request, sale_id):
    client = request.user.client_profile
    sale = get_object_or_404(Sale, id=sale_id, client=client)
    serializer = SaleSerializer(sale)
    return Response(serializer.data)


@api_view(['GET'])
@permission_classes([IsAuthenticated, IsClient])
def sales_report(request):
    client = request.user.client_profile
    
    # Date range filtering
    start_date = request.query_params.get('start_date')
    end_date = request.query_params.get('end_date')
    
    sales = Sale.objects.filter(client=client)
    
    if start_date:
        sales = sales.filter(created_at__gte=start_date)
    if end_date:
        sales = sales.filter(created_at__lte=end_date)
    
    # If no date range, default to last 30 days
    if not start_date and not end_date:
        thirty_days_ago = timezone.now() - timedelta(days=30)
        sales = sales.filter(created_at__gte=thirty_days_ago)
    
    total_sales = sales.count()
    total_amount = sales.aggregate(total=Sum('final_amount'))['total'] or 0
    
    # Payment method breakdown
    metal_sales = sales.filter(payment_method='metal')
    points_sales = sales.filter(payment_method='points')
    
    metal_total = metal_sales.aggregate(total=Sum('final_amount'))['total'] or 0
    points_total = points_sales.aggregate(total=Sum('final_amount'))['total'] or 0
    
    # Buyer type breakdown
    retailer_sales = sales.filter(buyer_type='retailer').count()
    customer_sales = sales.filter(buyer_type='customer').count()
    
    return Response({
        'period': {
            'start_date': start_date or (timezone.now() - timedelta(days=30)).isoformat(),
            'end_date': end_date or timezone.now().isoformat()
        },
        'summary': {
            'total_sales': total_sales,
            'total_amount': float(total_amount),
            'average_sale': float(total_amount / total_sales) if total_sales > 0 else 0
        },
        'payment_methods': {
            'metal': {
                'count': metal_sales.count(),
                'total': float(metal_total)
            },
            'points': {
                'count': points_sales.count(),
                'total': float(points_total)
            }
        },
        'buyer_types': {
            'retailer': retailer_sales,
            'customer': customer_sales
        }
    })

