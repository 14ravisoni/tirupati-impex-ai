import uuid
from django.db import models
from apps.jewels.models import Jewel
from apps.users.models import Client


class Sale(models.Model):
    PAYMENT_METHOD_CHOICES = [
        ('metal', 'Metal'),
        ('points', 'Points'),
    ]
    
    BUYER_TYPE_CHOICES = [
        ('retailer', 'Retailer'),
        ('customer', 'Customer'),
    ]
    
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    jewel = models.ForeignKey(Jewel, on_delete=models.CASCADE, related_name='sales')
    client = models.ForeignKey(Client, on_delete=models.CASCADE, related_name='sales')
    buyer_name = models.CharField(max_length=255)
    buyer_phone = models.CharField(max_length=20, blank=True)
    buyer_type = models.CharField(max_length=20, choices=BUYER_TYPE_CHOICES)
    payment_method = models.CharField(max_length=10, choices=PAYMENT_METHOD_CHOICES)
    metal_amount = models.DecimalField(max_digits=10, decimal_places=3, null=True, blank=True)
    points_amount = models.DecimalField(max_digits=12, decimal_places=2, null=True, blank=True)
    final_amount = models.DecimalField(max_digits=12, decimal_places=2)
    gold_price_per_gram = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True)
    notes = models.TextField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    
    class Meta:
        db_table = 'sales'
        ordering = ['-created_at']
    
    def __str__(self):
        return f"Sale - {self.jewel.jewel_type} - {self.buyer_name}"

