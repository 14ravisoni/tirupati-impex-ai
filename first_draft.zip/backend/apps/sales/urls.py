from django.urls import path
from . import views

urlpatterns = [
    path('', views.list_sales, name='list_sales'),
    path('create/', views.create_sale, name='create_sale'),
    path('<uuid:sale_id>/', views.get_sale, name='get_sale'),
    path('report/', views.sales_report, name='sales_report'),
]

