from django.contrib import admin
from .models import Sale


@admin.register(Sale)
class SaleAdmin(admin.ModelAdmin):
    list_display = ['jewel', 'buyer_name', 'buyer_type', 'payment_method',
                    'final_amount', 'created_at']
    list_filter = ['buyer_type', 'payment_method', 'created_at']
    search_fields = ['buyer_name', 'buyer_phone', 'jewel__jewel_type']
    readonly_fields = ['created_at']

