from rest_framework import serializers
from .models import InventoryTransaction


class InventoryTransactionSerializer(serializers.ModelSerializer):
    class Meta:
        model = InventoryTransaction
        fields = ['id', 'transaction_type', 'metal_amount', 'points_amount',
                  'balance_after_metal', 'balance_after_points', 'reference_id',
                  'notes', 'created_at']


class AddMetalSerializer(serializers.Serializer):
    amount = serializers.DecimalField(max_digits=10, decimal_places=3, required=True)
    notes = serializers.CharField(required=False, allow_blank=True)


class WithdrawMetalSerializer(serializers.Serializer):
    amount = serializers.DecimalField(max_digits=10, decimal_places=3, required=True)
    notes = serializers.CharField(required=False, allow_blank=True)


class AddPointsSerializer(serializers.Serializer):
    amount = serializers.DecimalField(max_digits=12, decimal_places=2, required=True)
    notes = serializers.CharField(required=False, allow_blank=True)


class WithdrawPointsSerializer(serializers.Serializer):
    amount = serializers.DecimalField(max_digits=12, decimal_places=2, required=True)
    notes = serializers.CharField(required=False, allow_blank=True)

