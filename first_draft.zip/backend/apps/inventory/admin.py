from django.contrib import admin
from .models import InventoryTransaction


@admin.register(InventoryTransaction)
class InventoryTransactionAdmin(admin.ModelAdmin):
    list_display = ['client', 'transaction_type', 'metal_amount', 'points_amount',
                    'balance_after_metal', 'balance_after_points', 'created_at']
    list_filter = ['transaction_type', 'created_at']
    search_fields = ['client__business_name']
    readonly_fields = ['created_at']

