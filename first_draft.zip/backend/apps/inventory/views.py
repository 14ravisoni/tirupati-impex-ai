from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework import status
from decimal import Decimal
from django.utils import timezone
from .models import InventoryTransaction
from .serializers import (
    InventoryTransactionSerializer, AddMetalSerializer, WithdrawMetalSerializer,
    AddPointsSerializer, WithdrawPointsSerializer
)
from apps.authentication.permissions import IsClient


@api_view(['GET'])
@permission_classes([IsAuthenticated, IsClient])
def list_transactions(request):
    client = request.user.client_profile
    transactions = InventoryTransaction.objects.filter(client=client)
    
    # Filtering
    transaction_type = request.query_params.get('type')
    if transaction_type:
        transactions = transactions.filter(transaction_type=transaction_type)
    
    serializer = InventoryTransactionSerializer(transactions, many=True)
    return Response(serializer.data)


@api_view(['POST'])
@permission_classes([IsAuthenticated, IsClient])
def add_metal(request):
    client = request.user.client_profile
    serializer = AddMetalSerializer(data=request.data)
    
    if serializer.is_valid():
        amount = serializer.validated_data['amount']
        client.metal_inventory += amount
        client.save(update_fields=['metal_inventory'])
        
        transaction = InventoryTransaction.objects.create(
            client=client,
            transaction_type='add_metal',
            metal_amount=amount,
            balance_after_metal=client.metal_inventory,
            balance_after_points=client.points_inventory,
            notes=serializer.validated_data.get('notes', '')
        )
        
        return Response(InventoryTransactionSerializer(transaction).data, status=status.HTTP_201_CREATED)
    return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


@api_view(['POST'])
@permission_classes([IsAuthenticated, IsClient])
def withdraw_metal(request):
    client = request.user.client_profile
    serializer = WithdrawMetalSerializer(data=request.data)
    
    if serializer.is_valid():
        amount = serializer.validated_data['amount']
        
        if client.metal_inventory < amount:
            return Response({'error': 'Insufficient metal inventory'}, status=status.HTTP_400_BAD_REQUEST)
        
        client.metal_inventory -= amount
        client.save(update_fields=['metal_inventory'])
        
        transaction = InventoryTransaction.objects.create(
            client=client,
            transaction_type='withdraw_metal',
            metal_amount=amount,
            balance_after_metal=client.metal_inventory,
            balance_after_points=client.points_inventory,
            notes=serializer.validated_data.get('notes', '')
        )
        
        return Response(InventoryTransactionSerializer(transaction).data, status=status.HTTP_201_CREATED)
    return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


@api_view(['POST'])
@permission_classes([IsAuthenticated, IsClient])
def add_points(request):
    client = request.user.client_profile
    serializer = AddPointsSerializer(data=request.data)
    
    if serializer.is_valid():
        amount = serializer.validated_data['amount']
        client.points_inventory += amount
        client.save(update_fields=['points_inventory'])
        
        transaction = InventoryTransaction.objects.create(
            client=client,
            transaction_type='add_points',
            points_amount=amount,
            balance_after_metal=client.metal_inventory,
            balance_after_points=client.points_inventory,
            notes=serializer.validated_data.get('notes', '')
        )
        
        return Response(InventoryTransactionSerializer(transaction).data, status=status.HTTP_201_CREATED)
    return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


@api_view(['POST'])
@permission_classes([IsAuthenticated, IsClient])
def withdraw_points(request):
    client = request.user.client_profile
    serializer = WithdrawPointsSerializer(data=request.data)
    
    if serializer.is_valid():
        amount = serializer.validated_data['amount']
        
        if client.points_inventory < amount:
            return Response({'error': 'Insufficient points inventory'}, status=status.HTTP_400_BAD_REQUEST)
        
        client.points_inventory -= amount
        client.save(update_fields=['points_inventory'])
        
        transaction = InventoryTransaction.objects.create(
            client=client,
            transaction_type='withdraw_points',
            points_amount=amount,
            balance_after_metal=client.metal_inventory,
            balance_after_points=client.points_inventory,
            notes=serializer.validated_data.get('notes', '')
        )
        
        return Response(InventoryTransactionSerializer(transaction).data, status=status.HTTP_201_CREATED)
    return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


@api_view(['GET'])
@permission_classes([IsAuthenticated, IsClient])
def get_current_inventory(request):
    client = request.user.client_profile
    return Response({
        'metal': float(client.metal_inventory),
        'points': float(client.points_inventory)
    })

