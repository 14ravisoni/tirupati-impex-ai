import uuid
from django.db import models
from apps.users.models import Client


class InventoryTransaction(models.Model):
    TRANSACTION_TYPE_CHOICES = [
        ('add_metal', 'Add Metal'),
        ('withdraw_metal', 'Withdraw Metal'),
        ('add_points', 'Add Points'),
        ('withdraw_points', 'Withdraw Points'),
        ('sale_metal', 'Sale - Metal Payment'),
        ('sale_points', 'Sale - Points Payment'),
    ]
    
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    client = models.ForeignKey(Client, on_delete=models.CASCADE, related_name='inventory_transactions')
    transaction_type = models.CharField(max_length=20, choices=TRANSACTION_TYPE_CHOICES)
    metal_amount = models.DecimalField(max_digits=10, decimal_places=3, null=True, blank=True)
    points_amount = models.DecimalField(max_digits=12, decimal_places=2, null=True, blank=True)
    balance_after_metal = models.DecimalField(max_digits=10, decimal_places=3)
    balance_after_points = models.DecimalField(max_digits=12, decimal_places=2)
    reference_id = models.UUIDField(null=True, blank=True)  # For linking to sales, jobs, etc.
    notes = models.TextField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    
    class Meta:
        db_table = 'inventory_transactions'
        ordering = ['-created_at']
    
    def __str__(self):
        return f"{self.client.business_name} - {self.transaction_type}"

