from django.urls import path
from . import views

urlpatterns = [
    path('transactions/', views.list_transactions, name='list_transactions'),
    path('add-metal/', views.add_metal, name='add_metal'),
    path('add-points/', views.add_points, name='add_points'),
    path('withdraw-metal/', views.withdraw_metal, name='withdraw_metal'),
    path('withdraw-points/', views.withdraw_points, name='withdraw_points'),
    path('current/', views.get_current_inventory, name='get_current_inventory'),
]

