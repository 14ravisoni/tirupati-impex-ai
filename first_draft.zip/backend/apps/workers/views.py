from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework import status
from django.shortcuts import get_object_or_404
from .models import Worker
from .serializers import WorkerSerializer, WorkerCreateSerializer, WorkerUpdateSerializer, WorkerStatsSerializer
from apps.authentication.permissions import IsClient
from apps.jobs.models import Job


@api_view(['GET'])
@permission_classes([IsAuthenticated, IsClient])
def list_workers(request):
    client = request.user.client_profile
    workers = Worker.objects.filter(client=client, user__is_active=True)
    serializer = WorkerSerializer(workers, many=True)
    return Response(serializer.data)


@api_view(['POST'])
@permission_classes([IsAuthenticated, IsClient])
def create_worker(request):
    serializer = WorkerCreateSerializer(data=request.data, context={'request': request})
    if serializer.is_valid():
        worker = serializer.save()
        return Response(WorkerSerializer(worker).data, status=status.HTTP_201_CREATED)
    return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


@api_view(['GET'])
@permission_classes([IsAuthenticated])
def get_worker(request, worker_id):
    worker = get_object_or_404(Worker, id=worker_id)
    
    # Check permissions
    if request.user.user_type == 'client':
        if worker.client != request.user.client_profile:
            return Response({'error': 'Permission denied'}, status=status.HTTP_403_FORBIDDEN)
    elif request.user.user_type == 'worker':
        if worker.user != request.user:
            return Response({'error': 'Permission denied'}, status=status.HTTP_403_FORBIDDEN)
    
    serializer = WorkerSerializer(worker)
    return Response(serializer.data)


@api_view(['PUT'])
@permission_classes([IsAuthenticated, IsClient])
def update_worker(request, worker_id):
    client = request.user.client_profile
    worker = get_object_or_404(Worker, id=worker_id, client=client)
    serializer = WorkerUpdateSerializer(worker, data=request.data, partial=True, context={'request': request})
    if serializer.is_valid():
        serializer.save()
        return Response(WorkerSerializer(worker).data)
    return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


@api_view(['DELETE'])
@permission_classes([IsAuthenticated, IsClient])
def deactivate_worker(request, worker_id):
    client = request.user.client_profile
    worker = get_object_or_404(Worker, id=worker_id, client=client)
    worker.user.is_active = False
    worker.user.save(update_fields=['is_active'])
    return Response({'message': 'Worker deactivated successfully'})


@api_view(['GET'])
@permission_classes([IsAuthenticated])
def get_worker_jobs(request, worker_id):
    worker = get_object_or_404(Worker, id=worker_id)
    
    # Check permissions
    if request.user.user_type == 'client':
        if worker.client != request.user.client_profile:
            return Response({'error': 'Permission denied'}, status=status.HTTP_403_FORBIDDEN)
    elif request.user.user_type == 'worker':
        if worker.user != request.user:
            return Response({'error': 'Permission denied'}, status=status.HTTP_403_FORBIDDEN)
    
    jobs = Job.objects.filter(worker=worker).order_by('-created_at')
    from apps.jobs.serializers import JobListSerializer
    serializer = JobListSerializer(jobs, many=True)
    return Response(serializer.data)


@api_view(['GET'])
@permission_classes([IsAuthenticated])
def get_worker_stats(request, worker_id):
    worker = get_object_or_404(Worker, id=worker_id)
    
    # Check permissions
    if request.user.user_type == 'client':
        if worker.client != request.user.client_profile:
            return Response({'error': 'Permission denied'}, status=status.HTTP_403_FORBIDDEN)
    elif request.user.user_type == 'worker':
        if worker.user != request.user:
            return Response({'error': 'Permission denied'}, status=status.HTTP_403_FORBIDDEN)
    
    serializer = WorkerStatsSerializer(worker)
    return Response(serializer.data)

