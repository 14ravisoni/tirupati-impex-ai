from rest_framework import serializers
from .models import Worker
from apps.users.models import User


class WorkerSerializer(serializers.ModelSerializer):
    email = serializers.EmailField(source='user.email', read_only=True)
    phone = serializers.CharField(source='user.phone', read_only=True)
    is_active = serializers.BooleanField(source='user.is_active', read_only=True)
    
    class Meta:
        model = Worker
        fields = ['id', 'email', 'phone', 'full_name', 'nickname', 'client', 
                  'total_jobs_assigned', 'total_jobs_accepted', 'total_jobs_rejected',
                  'total_jobs_completed', 'total_jobs_sent_back', 'current_active_jobs',
                  'acceptance_rate', 'is_active', 'created_at']


class WorkerCreateSerializer(serializers.Serializer):
    email = serializers.EmailField()
    password = serializers.CharField(write_only=True, min_length=8)
    full_name = serializers.CharField(max_length=255)
    nickname = serializers.CharField(max_length=100, required=False, allow_blank=True)
    phone = serializers.CharField(max_length=20, required=False, allow_blank=True)
    
    def create(self, validated_data):
        user_data = validated_data.copy()
        password = user_data.pop('password')
        email = user_data.pop('email')
        phone = user_data.pop('phone', '')
        
        # Get client from request
        client = self.context['request'].user.client_profile
        
        # Create user
        user = User.objects.create_user(
            email=email,
            password=password,
            user_type='worker',
            phone=phone
        )
        
        # Create worker
        worker = Worker.objects.create(
            user=user,
            client=client,
            full_name=user_data['full_name'],
            nickname=user_data.get('nickname', '')
        )
        
        return worker


class WorkerUpdateSerializer(serializers.ModelSerializer):
    class Meta:
        model = Worker
        fields = ['full_name', 'nickname']
    
    def update(self, instance, validated_data):
        # Also update user phone if provided
        if 'phone' in self.context.get('request', {}).data:
            instance.user.phone = self.context['request'].data['phone']
            instance.user.save(update_fields=['phone'])
        return super().update(instance, validated_data)


class WorkerStatsSerializer(serializers.ModelSerializer):
    class Meta:
        model = Worker
        fields = ['total_jobs_assigned', 'total_jobs_accepted', 'total_jobs_rejected',
                  'total_jobs_completed', 'total_jobs_sent_back', 'current_active_jobs',
                  'acceptance_rate']

