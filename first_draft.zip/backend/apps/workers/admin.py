from django.contrib import admin
from .models import Worker


@admin.register(Worker)
class WorkerAdmin(admin.ModelAdmin):
    list_display = ['full_name', 'nickname', 'client', 'total_jobs_completed', 
                    'acceptance_rate', 'current_active_jobs', 'created_at']
    list_filter = ['client', 'created_at']
    search_fields = ['full_name', 'nickname', 'user__email']
    readonly_fields = ['total_jobs_assigned', 'total_jobs_accepted', 'total_jobs_rejected',
                      'total_jobs_completed', 'total_jobs_sent_back', 'current_active_jobs',
                      'acceptance_rate', 'created_at', 'updated_at']

