import uuid
from django.db import models
from apps.users.models import User, Client


class Worker(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name='worker_profile')
    client = models.ForeignKey(Client, on_delete=models.CASCADE, related_name='workers')
    full_name = models.CharField(max_length=255)
    nickname = models.CharField(max_length=100, blank=True)
    total_jobs_assigned = models.IntegerField(default=0)
    total_jobs_accepted = models.IntegerField(default=0)
    total_jobs_rejected = models.IntegerField(default=0)
    total_jobs_completed = models.IntegerField(default=0)
    total_jobs_sent_back = models.IntegerField(default=0)
    current_active_jobs = models.IntegerField(default=0)
    acceptance_rate = models.DecimalField(max_digits=5, decimal_places=2, default=0)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    class Meta:
        db_table = 'workers'
        ordering = ['-created_at']
    
    def __str__(self):
        return self.full_name
    
    def calculate_acceptance_rate(self):
        if self.total_jobs_assigned > 0:
            self.acceptance_rate = (self.total_jobs_accepted / self.total_jobs_assigned) * 100
        else:
            self.acceptance_rate = 0
        self.save(update_fields=['acceptance_rate'])

