from django.urls import path
from . import views

urlpatterns = [
    path('', views.list_workers, name='list_workers'),
    path('create/', views.create_worker, name='create_worker'),
    path('<uuid:worker_id>/', views.get_worker, name='get_worker'),
    path('<uuid:worker_id>/update/', views.update_worker, name='update_worker'),
    path('<uuid:worker_id>/deactivate/', views.deactivate_worker, name='deactivate_worker'),
    path('<uuid:worker_id>/jobs/', views.get_worker_jobs, name='get_worker_jobs'),
    path('<uuid:worker_id>/stats/', views.get_worker_stats, name='get_worker_stats'),
]

