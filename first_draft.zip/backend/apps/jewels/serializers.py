from rest_framework import serializers
from .models import Jewel, JewelStone, JewelImage, StoneType


class StoneTypeSerializer(serializers.ModelSerializer):
    class Meta:
        model = StoneType
        fields = ['id', 'name']


class JewelStoneSerializer(serializers.ModelSerializer):
    stone_type = StoneTypeSerializer(read_only=True)
    stone_type_id = serializers.UUIDField(write_only=True)
    
    class Meta:
        model = JewelStone
        fields = ['id', 'stone_type', 'stone_type_id', 'quantity', 'carat', 'weight', 'price', 'created_at']
    
    def create(self, validated_data):
        stone_type_id = validated_data.pop('stone_type_id')
        stone_type = StoneType.objects.get(id=stone_type_id)
        validated_data['stone_type'] = stone_type
        return super().create(validated_data)


class JewelImageSerializer(serializers.ModelSerializer):
    class Meta:
        model = JewelImage
        fields = ['id', 'image', 'stage', 'created_at']


class JewelSerializer(serializers.ModelSerializer):
    stones = JewelStoneSerializer(many=True, read_only=True)
    images = JewelImageSerializer(many=True, read_only=True)
    
    class Meta:
        model = Jewel
        fields = ['id', 'jewel_type', 'current_stage', 'ghatt_weight', 'stone_weight',
                  'net_weight', 'metal_weight', 'is_active', 'sold_at',
                  'ghatt_stage_at', 'jadai_stage_at', 'chilai_stage_at', 'pakai_stage_at',
                  'gold_ready_stage_at', 'ready_to_sell_stage_at', 'sold_stage_at',
                  'stones', 'images', 'created_at', 'updated_at']


class JewelCreateSerializer(serializers.ModelSerializer):
    class Meta:
        model = Jewel
        fields = ['jewel_type', 'ghatt_weight', 'stone_weight', 'net_weight', 'metal_weight']
    
    def create(self, validated_data):
        client = self.context['request'].user.client_profile
        return Jewel.objects.create(client=client, **validated_data)


class JewelUpdateSerializer(serializers.ModelSerializer):
    class Meta:
        model = Jewel
        fields = ['jewel_type', 'current_stage', 'ghatt_weight', 'stone_weight',
                  'net_weight', 'metal_weight']


class JewelWeightUpdateSerializer(serializers.Serializer):
    ghatt_weight = serializers.DecimalField(max_digits=10, decimal_places=3, required=False)
    stone_weight = serializers.DecimalField(max_digits=10, decimal_places=3, required=False)
    net_weight = serializers.DecimalField(max_digits=10, decimal_places=3, required=False)
    metal_weight = serializers.DecimalField(max_digits=10, decimal_places=3, required=False)


class JewelStoneCreateSerializer(serializers.ModelSerializer):
    stone_type_id = serializers.UUIDField()
    
    class Meta:
        model = JewelStone
        fields = ['stone_type_id', 'quantity', 'carat', 'weight', 'price']
    
    def create(self, validated_data):
        stone_type_id = validated_data.pop('stone_type_id')
        stone_type = StoneType.objects.get(id=stone_type_id)
        jewel = self.context['jewel']
        return JewelStone.objects.create(jewel=jewel, stone_type=stone_type, **validated_data)

