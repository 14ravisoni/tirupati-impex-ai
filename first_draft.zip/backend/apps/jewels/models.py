import uuid
from django.db import models
from apps.users.models import Client


class StoneType(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    name = models.CharField(max_length=100, unique=True)
    created_at = models.DateTimeField(auto_now_add=True)
    
    class Meta:
        db_table = 'stone_types'
        ordering = ['name']
    
    def __str__(self):
        return self.name


class Jewel(models.Model):
    STAGE_CHOICES = [
        ('ghatt', 'Ghatt'),
        ('jadai', 'Jadai'),
        ('chilai', 'Chilai'),
        ('pakai', 'Pakai'),
        ('gold_ready', 'Gold Ready'),
        ('ready_to_sell', 'Ready to Sell'),
        ('sold', 'Sold'),
    ]
    
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    client = models.ForeignKey(Client, on_delete=models.CASCADE, related_name='jewels')
    jewel_type = models.CharField(max_length=100)
    current_stage = models.CharField(max_length=20, choices=STAGE_CHOICES, default='ghatt')
    ghatt_weight = models.DecimalField(max_digits=10, decimal_places=3)
    stone_weight = models.DecimalField(max_digits=10, decimal_places=3, default=0)
    net_weight = models.DecimalField(max_digits=10, decimal_places=3)
    metal_weight = models.DecimalField(max_digits=10, decimal_places=3, default=0)
    is_active = models.BooleanField(default=True)
    sold_at = models.DateTimeField(null=True, blank=True)
    
    # Stage timestamps
    ghatt_stage_at = models.DateTimeField(auto_now_add=True)
    jadai_stage_at = models.DateTimeField(null=True, blank=True)
    chilai_stage_at = models.DateTimeField(null=True, blank=True)
    pakai_stage_at = models.DateTimeField(null=True, blank=True)
    gold_ready_stage_at = models.DateTimeField(null=True, blank=True)
    ready_to_sell_stage_at = models.DateTimeField(null=True, blank=True)
    sold_stage_at = models.DateTimeField(null=True, blank=True)
    
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    class Meta:
        db_table = 'jewels'
        ordering = ['-created_at']
    
    def __str__(self):
        return f"{self.jewel_type} - {self.current_stage}"


class JewelStone(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    jewel = models.ForeignKey(Jewel, on_delete=models.CASCADE, related_name='stones')
    stone_type = models.ForeignKey(StoneType, on_delete=models.CASCADE)
    quantity = models.IntegerField(default=1)
    carat = models.DecimalField(max_digits=10, decimal_places=3, default=0)
    weight = models.DecimalField(max_digits=10, decimal_places=3, default=0)
    price = models.DecimalField(max_digits=12, decimal_places=2, default=0)
    created_at = models.DateTimeField(auto_now_add=True)
    
    class Meta:
        db_table = 'jewel_stones'
    
    def __str__(self):
        return f"{self.jewel.jewel_type} - {self.stone_type.name}"


class JewelImage(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    jewel = models.ForeignKey(Jewel, on_delete=models.CASCADE, related_name='images')
    image = models.ImageField(upload_to='jewels/')
    stage = models.CharField(max_length=20, choices=Jewel.STAGE_CHOICES)
    created_at = models.DateTimeField(auto_now_add=True)
    
    class Meta:
        db_table = 'jewel_images'
        ordering = ['-created_at']
    
    def __str__(self):
        return f"{self.jewel.jewel_type} - {self.stage}"

