from django.urls import path
from . import views

urlpatterns = [
    path('', views.list_jewels, name='list_jewels'),
    path('create/', views.create_jewel, name='create_jewel'),
    path('<uuid:jewel_id>/', views.get_jewel, name='get_jewel'),
    path('<uuid:jewel_id>/update/', views.update_jewel, name='update_jewel'),
    path('<uuid:jewel_id>/delete/', views.delete_jewel, name='delete_jewel'),
    path('<uuid:jewel_id>/upload-image/', views.upload_jewel_image, name='upload_jewel_image'),
    path('<uuid:jewel_id>/images/', views.get_jewel_images, name='get_jewel_images'),
    path('<uuid:jewel_id>/add-stone/', views.add_stone_to_jewel, name='add_stone_to_jewel'),
    path('<uuid:jewel_id>/stones/', views.get_jewel_stones, name='get_jewel_stones'),
    path('<uuid:jewel_id>/update-weight/', views.update_jewel_weight, name='update_jewel_weight'),
    path('by-stage/', views.get_jewels_by_stage, name='get_jewels_by_stage'),
]

