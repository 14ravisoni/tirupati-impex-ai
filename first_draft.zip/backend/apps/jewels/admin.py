from django.contrib import admin
from .models import Jewel, JewelStone, JewelImage, StoneType


@admin.register(StoneType)
class StoneTypeAdmin(admin.ModelAdmin):
    list_display = ['name', 'created_at']
    search_fields = ['name']


@admin.register(Jewel)
class JewelAdmin(admin.ModelAdmin):
    list_display = ['jewel_type', 'client', 'current_stage', 'ghatt_weight', 
                    'net_weight', 'is_active', 'created_at']
    list_filter = ['current_stage', 'is_active', 'created_at']
    search_fields = ['jewel_type', 'client__business_name']
    readonly_fields = ['created_at', 'updated_at', 'sold_at']


@admin.register(JewelStone)
class JewelStoneAdmin(admin.ModelAdmin):
    list_display = ['jewel', 'stone_type', 'quantity', 'carat', 'weight', 'price']
    list_filter = ['stone_type']
    search_fields = ['jewel__jewel_type']


@admin.register(JewelImage)
class JewelImageAdmin(admin.ModelAdmin):
    list_display = ['jewel', 'stage', 'created_at']
    list_filter = ['stage', 'created_at']
    search_fields = ['jewel__jewel_type']

