default_app_config = 'apps.jewels.apps.JewelsConfig'

