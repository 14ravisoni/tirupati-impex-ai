from django.apps import AppConfig


class JewelsConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'apps.jewels'
    
    def ready(self):
        import apps.jewels.signals

