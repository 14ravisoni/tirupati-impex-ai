from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework import status
from django.shortcuts import get_object_or_404
from django_filters.rest_framework import DjangoFilterBackend
from rest_framework import filters
from .models import Jewel, JewelStone, JewelImage, StoneType
from .serializers import (
    JewelSerializer, JewelCreateSerializer, JewelUpdateSerializer,
    JewelWeightUpdateSerializer, JewelStoneSerializer, JewelStoneCreateSerializer,
    JewelImageSerializer, StoneTypeSerializer
)
from apps.authentication.permissions import IsClient


@api_view(['GET'])
@permission_classes([IsAuthenticated])
def list_jewels(request):
    if request.user.user_type == 'client':
        jewels = Jewel.objects.filter(client=request.user.client_profile, is_active=True)
    else:
        # Worker can see jewels they have jobs for
        from apps.jobs.models import Job
        job_jewel_ids = Job.objects.filter(worker__user=request.user).values_list('jewel_id', flat=True)
        jewels = Jewel.objects.filter(id__in=job_jewel_ids, is_active=True)
    
    # Filtering
    stage = request.query_params.get('stage')
    if stage:
        jewels = jewels.filter(current_stage=stage)
    
    jewel_type = request.query_params.get('jewel_type')
    if jewel_type:
        jewels = jewels.filter(jewel_type__icontains=jewel_type)
    
    serializer = JewelSerializer(jewels, many=True)
    return Response(serializer.data)


@api_view(['POST'])
@permission_classes([IsAuthenticated, IsClient])
def create_jewel(request):
    serializer = JewelCreateSerializer(data=request.data, context={'request': request})
    if serializer.is_valid():
        jewel = serializer.save()
        return Response(JewelSerializer(jewel).data, status=status.HTTP_201_CREATED)
    return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


@api_view(['GET'])
@permission_classes([IsAuthenticated])
def get_jewel(request, jewel_id):
    jewel = get_object_or_404(Jewel, id=jewel_id)
    
    # Check permissions
    if request.user.user_type == 'client':
        if jewel.client != request.user.client_profile:
            return Response({'error': 'Permission denied'}, status=status.HTTP_403_FORBIDDEN)
    else:
        # Worker can only see if they have a job for this jewel
        from apps.jobs.models import Job
        if not Job.objects.filter(jewel=jewel, worker__user=request.user).exists():
            return Response({'error': 'Permission denied'}, status=status.HTTP_403_FORBIDDEN)
    
    serializer = JewelSerializer(jewel)
    return Response(serializer.data)


@api_view(['PUT'])
@permission_classes([IsAuthenticated, IsClient])
def update_jewel(request, jewel_id):
    client = request.user.client_profile
    jewel = get_object_or_404(Jewel, id=jewel_id, client=client)
    serializer = JewelUpdateSerializer(jewel, data=request.data, partial=True)
    if serializer.is_valid():
        serializer.save()
        return Response(JewelSerializer(jewel).data)
    return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


@api_view(['DELETE'])
@permission_classes([IsAuthenticated, IsClient])
def delete_jewel(request, jewel_id):
    client = request.user.client_profile
    jewel = get_object_or_404(Jewel, id=jewel_id, client=client)
    jewel.is_active = False
    jewel.save(update_fields=['is_active'])
    return Response({'message': 'Jewel deleted successfully'})


@api_view(['POST'])
@permission_classes([IsAuthenticated, IsClient])
def upload_jewel_image(request, jewel_id):
    client = request.user.client_profile
    jewel = get_object_or_404(Jewel, id=jewel_id, client=client)
    
    if 'image' not in request.FILES:
        return Response({'error': 'No image provided'}, status=status.HTTP_400_BAD_REQUEST)
    
    stage = request.data.get('stage', jewel.current_stage)
    image = JewelImage.objects.create(
        jewel=jewel,
        image=request.FILES['image'],
        stage=stage
    )
    return Response(JewelImageSerializer(image).data, status=status.HTTP_201_CREATED)


@api_view(['GET'])
@permission_classes([IsAuthenticated])
def get_jewel_images(request, jewel_id):
    jewel = get_object_or_404(Jewel, id=jewel_id)
    
    # Check permissions
    if request.user.user_type == 'client':
        if jewel.client != request.user.client_profile:
            return Response({'error': 'Permission denied'}, status=status.HTTP_403_FORBIDDEN)
    
    images = jewel.images.all()
    serializer = JewelImageSerializer(images, many=True)
    return Response(serializer.data)


@api_view(['POST'])
@permission_classes([IsAuthenticated, IsClient])
def add_stone_to_jewel(request, jewel_id):
    client = request.user.client_profile
    jewel = get_object_or_404(Jewel, id=jewel_id, client=client)
    
    serializer = JewelStoneCreateSerializer(data=request.data, context={'jewel': jewel})
    if serializer.is_valid():
        stone = serializer.save()
        return Response(JewelStoneSerializer(stone).data, status=status.HTTP_201_CREATED)
    return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


@api_view(['GET'])
@permission_classes([IsAuthenticated])
def get_jewel_stones(request, jewel_id):
    jewel = get_object_or_404(Jewel, id=jewel_id)
    
    # Check permissions
    if request.user.user_type == 'client':
        if jewel.client != request.user.client_profile:
            return Response({'error': 'Permission denied'}, status=status.HTTP_403_FORBIDDEN)
    
    stones = jewel.stones.all()
    serializer = JewelStoneSerializer(stones, many=True)
    return Response(serializer.data)


@api_view(['PUT'])
@permission_classes([IsAuthenticated, IsClient])
def update_jewel_weight(request, jewel_id):
    client = request.user.client_profile
    jewel = get_object_or_404(Jewel, id=jewel_id, client=client)
    
    serializer = JewelWeightUpdateSerializer(data=request.data)
    if serializer.is_valid():
        for field, value in serializer.validated_data.items():
            setattr(jewel, field, value)
        jewel.save()
        return Response(JewelSerializer(jewel).data)
    return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


@api_view(['GET'])
@permission_classes([IsAuthenticated, IsClient])
def get_jewels_by_stage(request):
    client = request.user.client_profile
    jewels_by_stage = {}
    
    for stage_code, stage_name in Jewel.STAGE_CHOICES:
        jewels = Jewel.objects.filter(client=client, current_stage=stage_code, is_active=True)
        serializer = JewelSerializer(jewels, many=True)
        jewels_by_stage[stage_code] = {
            'name': stage_name,
            'count': jewels.count(),
            'jewels': serializer.data
        }
    
    return Response(jewels_by_stage)

