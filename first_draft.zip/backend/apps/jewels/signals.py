# Signals for jewels are handled in jobs app when stage changes
pass

