from django.db.models.signals import post_save, pre_save
from django.dispatch import receiver
from django.utils import timezone
from .models import Job
from apps.notifications.models import Notification
from apps.jewels.models import Jewel

# Store old status in a thread-local way
_old_status_cache = {}


@receiver(pre_save, sender=Job)
def store_old_status_and_update_timestamps(sender, instance, **kwargs):
    if instance.pk:
        try:
            old_instance = Job.objects.get(pk=instance.pk)
            # Store old status for use in post_save
            _old_status_cache[instance.pk] = old_instance.status
            
            if old_instance.status != instance.status:
                # Update timestamps based on status change
                if instance.status == 'accepted' and old_instance.status != 'accepted':
                    instance.accepted_at = timezone.now()
                elif instance.status == 'rejected' and old_instance.status != 'rejected':
                    instance.rejected_at = timezone.now()
                elif instance.status == 'in_progress' and old_instance.status != 'in_progress':
                    instance.started_at = timezone.now()
                elif instance.status == 'submitted_for_review' and old_instance.status != 'submitted_for_review':
                    instance.submitted_at = timezone.now()
                elif instance.status == 'completed' and old_instance.status != 'completed':
                    instance.completed_at = timezone.now()
        except Job.DoesNotExist:
            _old_status_cache[instance.pk] = None


@receiver(post_save, sender=Job)
def update_worker_stats_and_progress_jewel(sender, instance, created, **kwargs):
    worker = instance.worker
    
    if created:
        worker.total_jobs_assigned += 1
        worker.save(update_fields=['total_jobs_assigned'])
    else:
        # Get old status from cache
        old_status = _old_status_cache.pop(instance.pk, None)
        
        # Only update if status actually changed
        if old_status is not None and old_status != instance.status:
            if instance.status == 'accepted' and old_status != 'accepted':
                worker.total_jobs_accepted += 1
                worker.current_active_jobs += 1
                worker.calculate_acceptance_rate()
            elif instance.status == 'rejected' and old_status != 'rejected':
                worker.total_jobs_rejected += 1
                worker.calculate_acceptance_rate()
            elif instance.status == 'completed' and old_status != 'completed':
                worker.total_jobs_completed += 1
                worker.current_active_jobs = max(0, worker.current_active_jobs - 1)
                worker.save(update_fields=['total_jobs_completed', 'current_active_jobs'])
                
                # Progress jewel to next stage
                jewel = instance.jewel
                stage_progression = {
                    'jadai': 'chilai',
                    'chilai': 'pakai',
                    'pakai': 'gold_ready',
                }
                if instance.job_stage in stage_progression:
                    next_stage = stage_progression[instance.job_stage]
                    jewel.current_stage = next_stage
                    setattr(jewel, f'{next_stage}_stage_at', timezone.now())
                    jewel.save()
            elif instance.status in ['sent_back_by_worker', 'sent_back_by_client']:
                if old_status not in ['sent_back_by_worker', 'sent_back_by_client']:
                    worker.total_jobs_sent_back += 1
                    worker.save(update_fields=['total_jobs_sent_back'])

