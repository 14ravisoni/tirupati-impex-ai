from django.urls import path
from . import views

urlpatterns = [
    # Client & Worker common
    path('', views.list_jobs, name='list_jobs'),
    path('<uuid:job_id>/', views.get_job, name='get_job'),
    
    # Client only
    path('create/', views.create_job, name='create_job'),
    path('<uuid:job_id>/reassign/', views.reassign_job, name='reassign_job'),
    path('<uuid:job_id>/approve/', views.approve_job, name='approve_job'),
    path('<uuid:job_id>/send-back/', views.client_send_back, name='client_send_back'),
    path('pending-review/', views.get_pending_review_jobs, name='get_pending_review_jobs'),
    
    # Worker only
    path('my-jobs/', views.get_my_jobs, name='get_my_jobs'),
    path('my-jobs/pending/', views.get_pending_jobs, name='get_pending_jobs'),
    path('<uuid:job_id>/accept/', views.accept_job, name='accept_job'),
    path('<uuid:job_id>/reject/', views.reject_job, name='reject_job'),
    path('<uuid:job_id>/start/', views.start_job, name='start_job'),
    path('<uuid:job_id>/upload-before-image/', views.upload_before_image, name='upload_before_image'),
    path('<uuid:job_id>/upload-after-image/', views.upload_after_image, name='upload_after_image'),
    path('<uuid:job_id>/submit/', views.submit_job, name='submit_job'),
    path('<uuid:job_id>/send-back/', views.worker_send_back, name='worker_send_back'),
]

