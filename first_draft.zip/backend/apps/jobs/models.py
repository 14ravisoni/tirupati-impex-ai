import uuid
from django.db import models
from apps.jewels.models import Jewel
from apps.users.models import Client
from apps.workers.models import Worker


class Job(models.Model):
    JOB_STAGE_CHOICES = [
        ('jadai', 'Jadai'),
        ('chilai', 'Chilai'),
        ('pakai', 'Pakai'),
    ]
    
    STATUS_CHOICES = [
        ('pending_acceptance', 'Pending Acceptance'),
        ('accepted', 'Accepted'),
        ('rejected', 'Rejected'),
        ('in_progress', 'In Progress'),
        ('submitted_for_review', 'Submitted for Review'),
        ('sent_back_by_worker', 'Sent Back by Worker'),
        ('sent_back_by_client', 'Sent Back by Client'),
        ('completed', 'Completed'),
    ]
    
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    job_number = models.CharField(max_length=50, unique=True, editable=False)
    jewel = models.ForeignKey(Jewel, on_delete=models.CASCADE, related_name='jobs')
    client = models.ForeignKey(Client, on_delete=models.CASCADE, related_name='jobs')
    worker = models.ForeignKey(Worker, on_delete=models.CASCADE, related_name='jobs')
    job_stage = models.CharField(max_length=20, choices=JOB_STAGE_CHOICES)
    job_description = models.TextField(blank=True)
    status = models.CharField(max_length=30, choices=STATUS_CHOICES, default='pending_acceptance')
    before_weight = models.DecimalField(max_digits=10, decimal_places=3, null=True, blank=True)
    after_weight = models.DecimalField(max_digits=10, decimal_places=3, null=True, blank=True)
    worker_send_back_count = models.IntegerField(default=0)
    client_send_back_count = models.IntegerField(default=0)
    last_send_back_reason = models.TextField(blank=True)
    
    # Timestamps
    assigned_at = models.DateTimeField(auto_now_add=True)
    accepted_at = models.DateTimeField(null=True, blank=True)
    rejected_at = models.DateTimeField(null=True, blank=True)
    started_at = models.DateTimeField(null=True, blank=True)
    submitted_at = models.DateTimeField(null=True, blank=True)
    completed_at = models.DateTimeField(null=True, blank=True)
    
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    class Meta:
        db_table = 'jobs'
        ordering = ['-created_at']
    
    def __str__(self):
        return f"{self.job_number} - {self.job_stage}"
    
    def save(self, *args, **kwargs):
        if not self.job_number:
            # Generate job number: JOB-YYYY-00001
            from django.utils import timezone
            year = timezone.now().year
            last_job = Job.objects.filter(job_number__startswith=f'JOB-{year}').order_by('-job_number').first()
            if last_job:
                try:
                    last_num = int(last_job.job_number.split('-')[-1])
                    new_num = last_num + 1
                except (ValueError, IndexError):
                    new_num = 1
            else:
                new_num = 1
            self.job_number = f'JOB-{year}-{new_num:05d}'
        super().save(*args, **kwargs)


class JobImage(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    job = models.ForeignKey(Job, on_delete=models.CASCADE, related_name='images')
    image = models.ImageField(upload_to='jobs/')
    image_type = models.CharField(max_length=10, choices=[('before', 'Before'), ('after', 'After')])
    created_at = models.DateTimeField(auto_now_add=True)
    
    class Meta:
        db_table = 'job_images'
        ordering = ['-created_at']
    
    def __str__(self):
        return f"{self.job.job_number} - {self.image_type}"


class JobHistory(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    job = models.ForeignKey(Job, on_delete=models.CASCADE, related_name='history')
    old_status = models.CharField(max_length=30, blank=True)
    new_status = models.CharField(max_length=30)
    changed_by = models.CharField(max_length=50)  # user email or system
    notes = models.TextField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    
    class Meta:
        db_table = 'job_history'
        ordering = ['-created_at']
    
    def __str__(self):
        return f"{self.job.job_number} - {self.old_status} -> {self.new_status}"

