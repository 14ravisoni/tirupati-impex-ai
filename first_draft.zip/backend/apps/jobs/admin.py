from django.contrib import admin
from .models import Job, JobImage, JobHistory


@admin.register(Job)
class JobAdmin(admin.ModelAdmin):
    list_display = ['job_number', 'jewel', 'worker', 'job_stage', 'status', 
                    'before_weight', 'after_weight', 'created_at']
    list_filter = ['job_stage', 'status', 'created_at']
    search_fields = ['job_number', 'jewel__jewel_type', 'worker__full_name']
    readonly_fields = ['job_number', 'assigned_at', 'accepted_at', 'rejected_at',
                      'started_at', 'submitted_at', 'completed_at', 'created_at', 'updated_at']


@admin.register(JobImage)
class JobImageAdmin(admin.ModelAdmin):
    list_display = ['job', 'image_type', 'created_at']
    list_filter = ['image_type', 'created_at']
    search_fields = ['job__job_number']


@admin.register(JobHistory)
class JobHistoryAdmin(admin.ModelAdmin):
    list_display = ['job', 'old_status', 'new_status', 'changed_by', 'created_at']
    list_filter = ['new_status', 'created_at']
    search_fields = ['job__job_number', 'changed_by']
    readonly_fields = ['created_at']

