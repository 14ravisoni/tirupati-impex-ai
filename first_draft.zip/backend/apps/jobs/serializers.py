from rest_framework import serializers
from .models import Job, JobImage, JobHistory
from apps.jewels.serializers import JewelSerializer
from apps.workers.serializers import WorkerSerializer


class JobImageSerializer(serializers.ModelSerializer):
    class Meta:
        model = JobImage
        fields = ['id', 'image', 'image_type', 'created_at']


class JobHistorySerializer(serializers.ModelSerializer):
    class Meta:
        model = JobHistory
        fields = ['id', 'old_status', 'new_status', 'changed_by', 'notes', 'created_at']


class JobListSerializer(serializers.ModelSerializer):
    jewel_type = serializers.CharField(source='jewel.jewel_type', read_only=True)
    worker_name = serializers.CharField(source='worker.full_name', read_only=True)
    
    class Meta:
        model = Job
        fields = ['id', 'job_number', 'jewel', 'jewel_type', 'worker', 'worker_name',
                  'job_stage', 'status', 'before_weight', 'after_weight',
                  'assigned_at', 'accepted_at', 'rejected_at', 'started_at',
                  'submitted_at', 'completed_at', 'created_at']


class JobDetailSerializer(serializers.ModelSerializer):
    jewel = JewelSerializer(read_only=True)
    worker = WorkerSerializer(read_only=True)
    images = JobImageSerializer(many=True, read_only=True)
    history = JobHistorySerializer(many=True, read_only=True)
    
    class Meta:
        model = Job
        fields = ['id', 'job_number', 'jewel', 'client', 'worker', 'job_stage',
                  'job_description', 'status', 'before_weight', 'after_weight',
                  'worker_send_back_count', 'client_send_back_count', 'last_send_back_reason',
                  'assigned_at', 'accepted_at', 'rejected_at', 'started_at',
                  'submitted_at', 'completed_at', 'images', 'history', 'created_at', 'updated_at']


class JobCreateSerializer(serializers.ModelSerializer):
    class Meta:
        model = Job
        fields = ['jewel', 'worker', 'job_stage', 'job_description', 'before_weight']
    
    def create(self, validated_data):
        client = self.context['request'].user.client_profile
        return Job.objects.create(client=client, **validated_data)


class JobAcceptSerializer(serializers.Serializer):
    pass  # No additional fields needed


class JobRejectSerializer(serializers.Serializer):
    reason = serializers.CharField(required=False, allow_blank=True)


class JobSubmitSerializer(serializers.Serializer):
    after_weight = serializers.DecimalField(max_digits=10, decimal_places=3, required=True)
    notes = serializers.CharField(required=False, allow_blank=True)


class JobApproveSerializer(serializers.Serializer):
    notes = serializers.CharField(required=False, allow_blank=True)


class JobSendBackSerializer(serializers.Serializer):
    reason = serializers.CharField(required=True)
    notes = serializers.CharField(required=False, allow_blank=True)

