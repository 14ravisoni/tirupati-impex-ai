from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework import status
from django.shortcuts import get_object_or_404
from django.utils import timezone
from .models import Job, JobImage, JobHistory
from .serializers import (
    JobListSerializer, JobDetailSerializer, JobCreateSerializer,
    JobAcceptSerializer, JobRejectSerializer, JobSubmitSerializer,
    JobApproveSerializer, JobSendBackSerializer, JobImageSerializer
)
from apps.authentication.permissions import IsClient, IsWorker
from apps.notifications.models import Notification


@api_view(['GET'])
@permission_classes([IsAuthenticated])
def list_jobs(request):
    if request.user.user_type == 'client':
        jobs = Job.objects.filter(client=request.user.client_profile)
    else:
        jobs = Job.objects.filter(worker__user=request.user)
    
    # Filtering
    status_filter = request.query_params.get('status')
    if status_filter:
        jobs = jobs.filter(status=status_filter)
    
    stage_filter = request.query_params.get('stage')
    if stage_filter:
        jobs = jobs.filter(job_stage=stage_filter)
    
    serializer = JobListSerializer(jobs, many=True)
    return Response(serializer.data)


@api_view(['POST'])
@permission_classes([IsAuthenticated, IsClient])
def create_job(request):
    serializer = JobCreateSerializer(data=request.data, context={'request': request})
    if serializer.is_valid():
        job = serializer.save()
        
        # Create notification for worker
        Notification.objects.create(
            user=job.worker.user,
            notification_type='job_assigned',
            title='New Job Assigned',
            message=f'You have been assigned a new {job.job_stage} job: {job.job_number}',
            reference_id=job.id
        )
        
        return Response(JobDetailSerializer(job).data, status=status.HTTP_201_CREATED)
    return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


@api_view(['GET'])
@permission_classes([IsAuthenticated])
def get_job(request, job_id):
    job = get_object_or_404(Job, id=job_id)
    
    # Check permissions
    if request.user.user_type == 'client':
        if job.client != request.user.client_profile:
            return Response({'error': 'Permission denied'}, status=status.HTTP_403_FORBIDDEN)
    else:
        if job.worker.user != request.user:
            return Response({'error': 'Permission denied'}, status=status.HTTP_403_FORBIDDEN)
    
    serializer = JobDetailSerializer(job)
    return Response(serializer.data)


@api_view(['PUT'])
@permission_classes([IsAuthenticated, IsClient])
def reassign_job(request, job_id):
    client = request.user.client_profile
    job = get_object_or_404(Job, id=job_id, client=client)
    
    if job.status not in ['pending_acceptance', 'rejected']:
        return Response({'error': 'Job cannot be reassigned in current status'}, status=status.HTTP_400_BAD_REQUEST)
    
    from apps.workers.models import Worker
    worker_id = request.data.get('worker_id')
    if not worker_id:
        return Response({'error': 'worker_id is required'}, status=status.HTTP_400_BAD_REQUEST)
    
    new_worker = get_object_or_404(Worker, id=worker_id, client=client)
    job.worker = new_worker
    job.status = 'pending_acceptance'
    job.save()
    
    # Create notification
    Notification.objects.create(
        user=new_worker.user,
        notification_type='job_assigned',
        title='New Job Assigned',
        message=f'You have been assigned a new {job.job_stage} job: {job.job_number}',
        reference_id=job.id
    )
    
    return Response(JobDetailSerializer(job).data)


# Worker APIs
@api_view(['GET'])
@permission_classes([IsAuthenticated, IsWorker])
def get_my_jobs(request):
    worker = request.user.worker_profile
    jobs = Job.objects.filter(worker=worker)
    
    status_filter = request.query_params.get('status')
    if status_filter:
        jobs = jobs.filter(status=status_filter)
    
    serializer = JobListSerializer(jobs, many=True)
    return Response(serializer.data)


@api_view(['GET'])
@permission_classes([IsAuthenticated, IsWorker])
def get_pending_jobs(request):
    worker = request.user.worker_profile
    jobs = Job.objects.filter(worker=worker, status='pending_acceptance')
    serializer = JobListSerializer(jobs, many=True)
    return Response(serializer.data)


@api_view(['POST'])
@permission_classes([IsAuthenticated, IsWorker])
def accept_job(request, job_id):
    worker = request.user.worker_profile
    job = get_object_or_404(Job, id=job_id, worker=worker)
    
    if job.status != 'pending_acceptance':
        return Response({'error': 'Job is not in pending acceptance status'}, status=status.HTTP_400_BAD_REQUEST)
    
    old_status = job.status
    job.status = 'accepted'
    job.accepted_at = timezone.now()
    job.save()
    
    # Create history
    JobHistory.objects.create(
        job=job,
        old_status=old_status,
        new_status='accepted',
        changed_by=request.user.email
    )
    
    # Create notification
    Notification.objects.create(
        user=job.client.user,
        notification_type='job_accepted',
        title='Job Accepted',
        message=f'Worker {worker.full_name} accepted job {job.job_number}',
        reference_id=job.id
    )
    
    return Response(JobDetailSerializer(job).data)


@api_view(['POST'])
@permission_classes([IsAuthenticated, IsWorker])
def reject_job(request, job_id):
    worker = request.user.worker_profile
    job = get_object_or_404(Job, id=job_id, worker=worker)
    
    if job.status != 'pending_acceptance':
        return Response({'error': 'Job is not in pending acceptance status'}, status=status.HTTP_400_BAD_REQUEST)
    
    serializer = JobRejectSerializer(data=request.data)
    if serializer.is_valid():
        old_status = job.status
        job.status = 'rejected'
        job.rejected_at = timezone.now()
        job.save()
        
        # Create history
        JobHistory.objects.create(
            job=job,
            old_status=old_status,
            new_status='rejected',
            changed_by=request.user.email,
            notes=serializer.validated_data.get('reason', '')
        )
        
        # Create notification
        Notification.objects.create(
            user=job.client.user,
            notification_type='job_rejected',
            title='Job Rejected',
            message=f'Worker {worker.full_name} rejected job {job.job_number}',
            reference_id=job.id
        )
        
        return Response(JobDetailSerializer(job).data)
    return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


@api_view(['POST'])
@permission_classes([IsAuthenticated, IsWorker])
def start_job(request, job_id):
    worker = request.user.worker_profile
    job = get_object_or_404(Job, id=job_id, worker=worker)
    
    if job.status != 'accepted':
        return Response({'error': 'Job must be accepted before starting'}, status=status.HTTP_400_BAD_REQUEST)
    
    old_status = job.status
    job.status = 'in_progress'
    job.started_at = timezone.now()
    job.save()
    
    # Create history
    JobHistory.objects.create(
        job=job,
        old_status=old_status,
        new_status='in_progress',
        changed_by=request.user.email
    )
    
    return Response(JobDetailSerializer(job).data)


@api_view(['POST'])
@permission_classes([IsAuthenticated, IsWorker])
def upload_before_image(request, job_id):
    worker = request.user.worker_profile
    job = get_object_or_404(Job, id=job_id, worker=worker)
    
    if 'image' not in request.FILES:
        return Response({'error': 'No image provided'}, status=status.HTTP_400_BAD_REQUEST)
    
    image = JobImage.objects.create(
        job=job,
        image=request.FILES['image'],
        image_type='before'
    )
    return Response(JobImageSerializer(image).data, status=status.HTTP_201_CREATED)


@api_view(['POST'])
@permission_classes([IsAuthenticated, IsWorker])
def upload_after_image(request, job_id):
    worker = request.user.worker_profile
    job = get_object_or_404(Job, id=job_id, worker=worker)
    
    if 'image' not in request.FILES:
        return Response({'error': 'No image provided'}, status=status.HTTP_400_BAD_REQUEST)
    
    image = JobImage.objects.create(
        job=job,
        image=request.FILES['image'],
        image_type='after'
    )
    return Response(JobImageSerializer(image).data, status=status.HTTP_201_CREATED)


@api_view(['POST'])
@permission_classes([IsAuthenticated, IsWorker])
def submit_job(request, job_id):
    worker = request.user.worker_profile
    job = get_object_or_404(Job, id=job_id, worker=worker)
    
    if job.status not in ['in_progress', 'sent_back_by_client']:
        return Response({'error': 'Job cannot be submitted in current status'}, status=status.HTTP_400_BAD_REQUEST)
    
    serializer = JobSubmitSerializer(data=request.data)
    if serializer.is_valid():
        old_status = job.status
        job.status = 'submitted_for_review'
        job.after_weight = serializer.validated_data['after_weight']
        job.submitted_at = timezone.now()
        job.save()
        
        # Create history
        JobHistory.objects.create(
            job=job,
            old_status=old_status,
            new_status='submitted_for_review',
            changed_by=request.user.email,
            notes=serializer.validated_data.get('notes', '')
        )
        
        # Create notification
        Notification.objects.create(
            user=job.client.user,
            notification_type='job_submitted',
            title='Job Submitted for Review',
            message=f'Worker {worker.full_name} submitted job {job.job_number} for review',
            reference_id=job.id
        )
        
        return Response(JobDetailSerializer(job).data)
    return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


@api_view(['POST'])
@permission_classes([IsAuthenticated, IsWorker])
def worker_send_back(request, job_id):
    worker = request.user.worker_profile
    job = get_object_or_404(Job, id=job_id, worker=worker)
    
    serializer = JobSendBackSerializer(data=request.data)
    if serializer.is_valid():
        old_status = job.status
        job.status = 'sent_back_by_worker'
        job.worker_send_back_count += 1
        job.last_send_back_reason = serializer.validated_data['reason']
        job.save()
        
        # Create history
        JobHistory.objects.create(
            job=job,
            old_status=old_status,
            new_status='sent_back_by_worker',
            changed_by=request.user.email,
            notes=serializer.validated_data.get('notes', '')
        )
        
        # Create notification
        Notification.objects.create(
            user=job.client.user,
            notification_type='job_sent_back',
            title='Job Sent Back by Worker',
            message=f'Worker {worker.full_name} sent back job {job.job_number}: {serializer.validated_data["reason"]}',
            reference_id=job.id
        )
        
        return Response(JobDetailSerializer(job).data)
    return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


# Client APIs
@api_view(['POST'])
@permission_classes([IsAuthenticated, IsClient])
def approve_job(request, job_id):
    client = request.user.client_profile
    job = get_object_or_404(Job, id=job_id, client=client)
    
    if job.status != 'submitted_for_review':
        return Response({'error': 'Job is not in submitted for review status'}, status=status.HTTP_400_BAD_REQUEST)
    
    serializer = JobApproveSerializer(data=request.data)
    if serializer.is_valid():
        old_status = job.status
        job.status = 'completed'
        job.completed_at = timezone.now()
        job.save()
        
        # Create history
        JobHistory.objects.create(
            job=job,
            old_status=old_status,
            new_status='completed',
            changed_by=request.user.email,
            notes=serializer.validated_data.get('notes', '')
        )
        
        # Create notification
        Notification.objects.create(
            user=job.worker.user,
            notification_type='job_approved',
            title='Job Approved',
            message=f'Your job {job.job_number} has been approved',
            reference_id=job.id
        )
        
        return Response(JobDetailSerializer(job).data)
    return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


@api_view(['POST'])
@permission_classes([IsAuthenticated, IsClient])
def client_send_back(request, job_id):
    client = request.user.client_profile
    job = get_object_or_404(Job, id=job_id, client=client)
    
    if job.status != 'submitted_for_review':
        return Response({'error': 'Job is not in submitted for review status'}, status=status.HTTP_400_BAD_REQUEST)
    
    serializer = JobSendBackSerializer(data=request.data)
    if serializer.is_valid():
        old_status = job.status
        job.status = 'sent_back_by_client'
        job.client_send_back_count += 1
        job.last_send_back_reason = serializer.validated_data['reason']
        job.save()
        
        # Create history
        JobHistory.objects.create(
            job=job,
            old_status=old_status,
            new_status='sent_back_by_client',
            changed_by=request.user.email,
            notes=serializer.validated_data.get('notes', '')
        )
        
        # Create notification
        Notification.objects.create(
            user=job.worker.user,
            notification_type='job_sent_back',
            title='Job Sent Back for Corrections',
            message=f'Job {job.job_number} has been sent back: {serializer.validated_data["reason"]}',
            reference_id=job.id
        )
        
        return Response(JobDetailSerializer(job).data)
    return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


@api_view(['GET'])
@permission_classes([IsAuthenticated, IsClient])
def get_pending_review_jobs(request):
    client = request.user.client_profile
    jobs = Job.objects.filter(client=client, status='submitted_for_review')
    serializer = JobListSerializer(jobs, many=True)
    return Response(serializer.data)

