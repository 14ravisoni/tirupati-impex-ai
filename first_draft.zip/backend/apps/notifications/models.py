import uuid
from django.db import models
from apps.users.models import User


class Notification(models.Model):
    NOTIFICATION_TYPE_CHOICES = [
        ('job_assigned', 'Job Assigned'),
        ('job_accepted', 'Job Accepted'),
        ('job_rejected', 'Job Rejected'),
        ('job_submitted', 'Job Submitted'),
        ('job_approved', 'Job Approved'),
        ('job_sent_back', 'Job Sent Back'),
        ('job_completed', 'Job Completed'),
        ('system', 'System Notification'),
    ]
    
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='notifications')
    notification_type = models.CharField(max_length=30, choices=NOTIFICATION_TYPE_CHOICES)
    title = models.CharField(max_length=255)
    message = models.TextField()
    is_read = models.BooleanField(default=False)
    reference_id = models.UUIDField(null=True, blank=True)  # For linking to jobs, jewels, etc.
    created_at = models.DateTimeField(auto_now_add=True)
    
    class Meta:
        db_table = 'notifications'
        ordering = ['-created_at']
    
    def __str__(self):
        return f"{self.user.email} - {self.title}"

