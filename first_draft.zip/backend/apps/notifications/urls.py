from django.urls import path
from . import views

urlpatterns = [
    path('', views.list_notifications, name='list_notifications'),
    path('unread/', views.get_unread_notifications, name='get_unread_notifications'),
    path('unread-count/', views.get_unread_count, name='get_unread_count'),
    path('<uuid:notification_id>/mark-read/', views.mark_notification_read, name='mark_notification_read'),
    path('mark-all-read/', views.mark_all_read, name='mark_all_read'),
]

