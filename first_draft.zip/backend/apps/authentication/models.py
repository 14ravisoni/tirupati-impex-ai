# Authentication app doesn't need models, using JWT tokens

