from rest_framework import serializers
from apps.users.models import User, Client
from apps.workers.models import Worker


class ClientRegistrationSerializer(serializers.ModelSerializer):
    email = serializers.EmailField()
    password = serializers.CharField(write_only=True, min_length=8)
    phone = serializers.CharField(required=False, allow_blank=True, max_length=20)
    
    class Meta:
        model = Client
        fields = ['email', 'password', 'business_name', 'full_name', 'phone', 'address']
        extra_kwargs = {
            'phone': {'write_only': True}  # phone is not on Client model, handle separately
        }
    
    def create(self, validated_data):
        email = validated_data.pop('email')
        password = validated_data.pop('password')
        phone = validated_data.pop('phone', '')
        user = User.objects.create_user(
            email=email,
            password=password,
            user_type='client',
            phone=phone
        )
        client = Client.objects.create(user=user, **validated_data)
        return client


class LoginSerializer(serializers.Serializer):
    email = serializers.EmailField()
    password = serializers.CharField(write_only=True)

