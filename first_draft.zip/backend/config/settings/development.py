from .base import *

DEBUG = True
ALLOWED_HOSTS = ['localhost', '127.0.0.1', '*']

CORS_ALLOW_ALL_ORIGINS = True

INSTALLED_APPS += ['debug_toolbar']
MIDDLEWARE += ['debug_toolbar.middleware.DebugToolbarMiddleware']

INTERNAL_IPS = ['127.0.0.1']

# Test database configuration - use existing database
import sys
if 'pytest' in sys.modules or 'test' in sys.argv:
    # For tests, use existing database instead of creating test database
    DATABASES['default']['TEST'] = {
        'NAME': DATABASES['default']['NAME'],
    }

