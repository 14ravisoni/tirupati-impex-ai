# Tirupati Impex - Jewelry Inventory Management System

A comprehensive Django REST API backend for managing jewelry manufacturing, inventory, worker assignments, and sales workflows.

**Note:** This project uses Django 3.2 LTS to support PostgreSQL 11+ (including PostgreSQL 11.19).

## 📋 Table of Contents

1. [Prerequisites](#prerequisites)
2. [Step 1: Database Setup](#step-1-database-setup)
3. [Step 2: Project Setup](#step-2-project-setup)
4. [Step 3: Virtual Environment & Dependencies](#step-3-virtual-environment--dependencies)
5. [Step 4: Django Configuration](#step-4-django-configuration)
6. [Step 5: Initial Data Setup](#step-5-initial-data-setup)
7. [Step 6: Running the Server](#step-6-running-the-server)
8. [Step 7: Testing the Installation](#step-7-testing-the-installation)
9. [Troubleshooting](#troubleshooting)

---

## Prerequisites

Before starting, ensure you have the following installed:

- **Python 3.10 or higher** - [Download Python](https://www.python.org/downloads/)
- **PostgreSQL 11 or higher** - [Download PostgreSQL](https://www.postgresql.org/download/)
  - **Minimum:** PostgreSQL 11 (supported by Django 3.2 LTS)
  - **Supported versions:** PostgreSQL 11, 12, 13, 14, 15, 16, 17, 18
  - **Recommended:** PostgreSQL 12 or higher for better performance
  - **Note:** This project uses Django 3.2 LTS which supports PostgreSQL 11+
- **Git** (if cloning from repository) - [Download Git](https://git-scm.com/downloads)
- **pip** (Python package manager - usually comes with Python)
- **PostgreSQL client tools** (psql command-line tool)

### Verify Installations

Open a terminal/command prompt and verify:

```bash
python --version    # Should show Python 3.10 or higher
psql --version      # Should show PostgreSQL 11 or higher (e.g., PostgreSQL 11.x, 12.x, 13.x, 14.x, 15.x, 16.x, 17.x, 18.x)
pip --version       # Should show pip version
```

**Note:** This project uses Django 3.2 LTS which supports PostgreSQL 11+. If you have PostgreSQL 10 or earlier, you must upgrade to at least PostgreSQL 11.

---

## Step 1: Database Setup

### 1.1 Start PostgreSQL Server

Before connecting to PostgreSQL, ensure the PostgreSQL service is running:

**Windows:**
```bash
# Check if PostgreSQL service is running
# Open Services (services.msc) and look for "postgresql-x64-XX" service
# Or use PowerShell:
Get-Service -Name postgresql*

# Start PostgreSQL service if not running
Start-Service postgresql-x64-XX
# Replace XX with your PostgreSQL version number (e.g., 15, 16)
```

Alternatively, you can start it from Services:
1. Press `Win + R`, type `services.msc`, press Enter
2. Find "PostgreSQL" service
3. Right-click and select "Start" if it's stopped

**Linux (Ubuntu/Debian):**
```bash
# Check status
sudo systemctl status postgresql

# Start PostgreSQL service
sudo systemctl start postgresql

# Enable to start on boot (optional)
sudo systemctl enable postgresql
```

**Linux (CentOS/RHEL):**
```bash
# Check status
sudo systemctl status postgresql-XX
# Replace XX with your PostgreSQL version

# Start PostgreSQL service
sudo systemctl start postgresql-XX
```

**Mac (Homebrew):**
```bash
# Start PostgreSQL
brew services start postgresql@XX
# Replace XX with your PostgreSQL version (e.g., 15, 16)

# Or use pg_ctl
pg_ctl -D /usr/local/var/postgres start
```

### 1.2 Connect to PostgreSQL

Connect to PostgreSQL as the superuser (usually `postgres`) to create the database and user. The method varies by operating system:

#### Windows (Command Prompt - CMD)

Open Command Prompt and run:

```cmd
psql -U postgres
```

If you're prompted for a password, enter the PostgreSQL superuser password you set during installation.

#### Windows (PowerShell)

Open PowerShell and run:

```powershell
psql -U postgres
```

If you're prompted for a password, enter the PostgreSQL superuser password you set during installation.

#### Mac (macOS)

Open Terminal and run:

```bash
psql -U postgres
```

**Note:** If this doesn't work, try:
```bash
psql -U postgres -d postgres
```

Or if you installed PostgreSQL via Homebrew:
```bash
psql postgres
```

If you're prompted for a password, enter the PostgreSQL superuser password you set during installation.

#### Linux

Open Terminal and run:

```bash
sudo -u postgres psql
```

**Alternative (if sudo doesn't work):**
```bash
psql -U postgres
```

If you're prompted for a password, enter the PostgreSQL superuser password you set during installation.

### 1.3 Create Database

Once connected to PostgreSQL, run the following SQL commands:

```sql
-- Create the database
CREATE DATABASE tirupati_impex_dev;

-- Verify database was created
\l
```

You should see `tirupati_impex_dev` in the list of databases.

### 1.4 Create Database User

Create a dedicated user for the application:

```sql
-- Create user
CREATE USER tirupati WITH PASSWORD 'tirupati';

-- Verify user was created
\du
```

**Note:** We're using `tirupati` as both username and password for simplicity. In production, use a strong password.

### 1.5 Grant Privileges

Grant all necessary privileges to the user on the database:

```sql
-- Grant CREATEDB permission (required for running Django tests)
ALTER USER tirupati CREATEDB;

-- Grant all privileges on the database
GRANT ALL PRIVILEGES ON DATABASE tirupati_impex_dev TO tirupati;

-- Connect to the database
\c tirupati_impex_dev

-- Grant schema privileges (PostgreSQL 15+)
GRANT ALL ON SCHEMA public TO tirupati;
ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT ALL ON TABLES TO tirupati;
ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT ALL ON SEQUENCES TO tirupati;

-- Exit PostgreSQL
\q
```

**Important:** The `CREATEDB` permission is required for running Django tests, as Django's test framework needs to create a test database. Without this permission, tests will fail with a "permission denied to create database" error.

### 1.6 Test Database Connection

Test that you can connect with the new user. The method varies by operating system:

#### Windows (Command Prompt - CMD)

Open Command Prompt and run:

```cmd
psql -U tirupati -d tirupati_impex_dev -h localhost
```

**Note:** If no password is prompted, PostgreSQL might be using trust authentication for local connections. This is normal for development setups.

If password is prompted, enter: `tirupati`

If successful, you'll see the PostgreSQL prompt:
```
tirupati_impex_dev=>
```

Type `\q` and press Enter to exit.

#### Windows (PowerShell)

Open PowerShell and run:

```powershell
psql -U tirupati -d tirupati_impex_dev -h localhost
```

**Note:** If no password is prompted, PostgreSQL might be using trust authentication for local connections. This is normal for development setups.

If password is prompted, enter: `tirupati`

If successful, you'll see the PostgreSQL prompt. Type `\q` and press Enter to exit.

#### Mac (macOS)

Open Terminal and run:

```bash
psql -U tirupati -d tirupati_impex_dev -h localhost
```

**Note:** If no password is prompted, PostgreSQL might be using trust authentication for local connections. This is normal for development setups.

If password is prompted, enter: `tirupati`

If successful, you'll see the PostgreSQL prompt:
```
tirupati_impex_dev=>
```

Type `\q` and press Enter to exit.

#### Linux

Open Terminal and run:

```bash
psql -U tirupati -d tirupati_impex_dev -h localhost
```

**Note:** If no password is prompted, PostgreSQL might be using trust or peer authentication for local connections. This is normal for development setups.

If password is prompted, enter: `tirupati`

If successful, you'll see the PostgreSQL prompt:
```
tirupati_impex_dev=>
```

Type `\q` and press Enter to exit.

#### Why Password Might Not Be Asked

PostgreSQL may not prompt for a password if:

1. **Trust Authentication**: PostgreSQL is configured to trust local connections (common in development)
2. **Peer Authentication**: On Linux/Mac, PostgreSQL uses your system username for authentication
3. **Password File**: You have a `.pgpass` file storing credentials

**This is normal and safe for local development.** The password is still required when Django connects to the database, which is what matters for the application.

#### Troubleshooting Connection Issues

If connection fails, check:
- PostgreSQL service is running (see Step 1.1)
- Database name is correct: `tirupati_impex_dev`
- Username is correct: `tirupati`
- User has proper privileges (from Step 1.5)
- If using a remote host, ensure `-h localhost` is correct or use the actual hostname/IP

---

## Step 2: Project Setup

### 2.1 Extract/Clone the Project

#### Option A: From ZIP File

1. Extract the ZIP file to your desired location (e.g., `C:\Projects\` or `~/projects/`)
2. Navigate to the extracted folder:
   ```bash
   cd path/to/extracted/folder
   ```
3. You should see a `backend` folder containing the Django project

#### Option B: From Git Repository

1. Clone the repository:
   ```bash
   git clone <repository-url>
   cd <repository-name>
   ```
2. Navigate to the backend folder:
   ```bash
   cd backend
   ```

### 2.2 Verify Project Structure

Ensure you have the following structure:

```
backend/
├── config/
├── apps/
├── requirements/
├── manage.py
├── README.md
└── .env.example
```

---

## Step 3: Virtual Environment & Dependencies

### 3.1 Create Virtual Environment

Navigate to the `backend` directory and create a virtual environment:

**Windows:**
```bash
cd backend
python -m venv venv
```

**Linux/Mac:**
```bash
cd backend
python3 -m venv venv
```

This creates a `venv` folder in your backend directory.

### 3.2 Activate Virtual Environment

**Windows (PowerShell):**
```bash
.\venv\Scripts\Activate.ps1
```

**Windows (Command Prompt):**
```bash
venv\Scripts\activate.bat
```

**Linux/Mac:**
```bash
source venv/bin/activate
```

You should see `(venv)` at the beginning of your command prompt, indicating the virtual environment is active.

**Note:** If you get an execution policy error on Windows PowerShell, run:
```powershell
Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser
```

### 3.3 Upgrade pip

Upgrade pip to the latest version:

```bash
python -m pip install --upgrade pip
```

### 3.4 Install Dependencies

Install all required packages:

```bash
pip install -r requirements/development.txt
```

This will install:
- Django 3.2.25 (LTS - supports PostgreSQL 11+)
- Django REST Framework
- PostgreSQL adapter (psycopg2)
- JWT authentication
- And all other dependencies

**Note:** If you encounter errors installing `psycopg2-binary`:
- On Windows: Usually works out of the box
- On Linux: You may need: `sudo apt-get install libpq-dev python3-dev`
- On Mac: You may need: `brew install postgresql`

### 3.5 Verify Installation

Verify Django is installed correctly:

```bash
python manage.py --version
```

You should see: `3.2.25` (or the Django version you installed)

---

## Step 4: Django Configuration

### 4.1 Create Environment File

Copy the example environment file:

**Windows:**
```bash
copy env.example .env
```

**Linux/Mac:**
```bash
cp env.example .env
```

### 4.2 Configure Environment Variables

Open `.env` file in a text editor and update the following values:

```env
DJANGO_ENVIRONMENT=development
SECRET_KEY=your-very-secret-key-change-this-in-production-min-50-chars
DB_NAME=tirupati_impex_dev
DB_USER=tirupati
DB_PASSWORD=tirupati
DB_HOST=localhost
DB_PORT=5432
```

**Important:**
- `DB_USER` is set to `tirupati` (created in Step 1.4)
- `DB_PASSWORD` is set to `tirupati` (set in Step 1.4)
- Replace `SECRET_KEY` with a secure random string (you can generate one using Python: `python -c "import secrets; print(secrets.token_urlsafe(50))"`)
- **For production:** Use strong, unique passwords and keep them secure

### 4.3 Test Database Connection

Test that Django can connect to your database:

```bash
python manage.py check --database default
```

If successful, you'll see: `System check identified no issues (0 silenced).`

If there's an error, verify:
- Database name, user, and password in `.env` are correct (should be `tirupati_impex_dev`, `tirupati`, `tirupati`)
- PostgreSQL service is running (see Step 1.1)
- Database and user exist (from Steps 1.3 and 1.4)

---

## Step 5: Initial Data Setup

### 5.1 Create Database Migrations

Create migration files for all apps:

```bash
python manage.py makemigrations
```

You should see output like:
```
Migrations for 'users':
  apps/users/migrations/0001_initial.py
    - Create model User
    - Create model Client
...
```

### 5.2 Apply Migrations

Run migrations to create all database tables:

```bash
python manage.py migrate
```

You should see output like:
```
Operations to perform:
  Apply all migrations: admin, auth, contenttypes, sessions, users, workers, ...
Running migrations:
  Applying contenttypes.0001_initial... OK
  Applying auth.0001_initial... OK
  ...
```

### 5.3 Create Superuser

Create an admin superuser account:

```bash
python manage.py createsuperuser
```

Follow the prompts:
- Email address: (enter your email)
- Password: (enter a secure password)
- Password (again): (confirm password)

**Note:** This creates a superuser, but for the application, you'll typically register clients through the API.

### 5.4 Load Initial Data (Stone Types)

Open Django shell:

```bash
python manage.py shell
```

Run the following Python code:

```python
from apps.jewels.models import StoneType

# Create stone types
stone_types = ['Diamond', 'Emerald', 'Ruby', 'Sapphire', 'Pearl']
for name in stone_types:
    stone_type, created = StoneType.objects.get_or_create(name=name)
    if created:
        print(f"Created: {name}")
    else:
        print(f"Already exists: {name}")

# Verify
print("\nAll stone types:")
for stone in StoneType.objects.all():
    print(f"  - {stone.name}")

# Exit shell
exit()
```

### 5.5 Verify Database Tables

Connect to PostgreSQL and verify tables were created. Use the appropriate command for your operating system:

#### Windows (Command Prompt or PowerShell)

```cmd
psql -U tirupati -d tirupati_impex_dev -h localhost
```

#### Mac (macOS)

```bash
psql -U tirupati -d tirupati_impex_dev -h localhost
```

#### Linux

```bash
psql -U tirupati -d tirupati_impex_dev -h localhost
```

**Note:** If no password is prompted, that's normal (see Step 1.6 for explanation). If prompted, enter: `tirupati`

Once connected, run these SQL commands:

```sql
-- List all tables
\dt

-- Check a specific table structure
\d users

-- Count records in a table (optional)
SELECT COUNT(*) FROM users;

-- Exit
\q
```

You should see tables like: `users`, `clients`, `workers`, `jewels`, `jobs`, `sales`, `inventory_transactions`, `notifications`, etc.

---

## Step 6: Running the Server

### 6.1 Start Development Server

Make sure your virtual environment is activated, then run:

```bash
python manage.py runserver
```

You should see:
```
Watching for file changes with StatReloader
Performing system checks...

System check identified no issues (0 silenced).
Django version 3.2.25, using settings 'config.settings'
Starting development server at http://127.0.0.1:8000/
Quit the server with CTRL-BREAK.
```

### 6.2 Access the Application

- **API Base URL:** http://127.0.0.1:8000/api/v1/
- **Admin Panel:** http://127.0.0.1:8000/admin/
- **API Documentation:** Available at various endpoints

### 6.3 Stop the Server

Press `CTRL+C` (or `CTRL+BREAK` on Windows) to stop the server.

---

## Step 7: Testing the Installation

### 7.1 Test Admin Panel

1. Open browser and go to: http://127.0.0.1:8000/admin/
2. Login with the superuser credentials you created in Step 5.3
3. You should see the Django admin interface with all models

### 7.2 Test API Registration

Test the client registration endpoint using curl or Postman:

**Using curl:**
```bash
curl -X POST http://127.0.0.1:8000/api/v1/auth/register/client/ \
  -H "Content-Type: application/json" \
  -d '{
    "email": "test@example.com",
    "password": "testpass123",
    "business_name": "Test Jewelers",
    "full_name": "Test Client",
    "phone": "+91-9876543210"
  }'
```

**Expected Response:**
```json
{
  "access": "eyJ0eXAiOiJKV1QiLCJhbGc...",
  "refresh": "eyJ0eXAiOiJKV1QiLCJhbGc...",
  "user": {
    "id": "...",
    "email": "test@example.com",
    "userType": "client",
    ...
  }
}
```

### 7.3 Test API Login

```bash
curl -X POST http://127.0.0.1:8000/api/v1/auth/login/ \
  -H "Content-Type: application/json" \
  -d '{
    "email": "test@example.com",
    "password": "testpass123"
  }'
```

### 7.4 Test Protected Endpoint

Use the access token from login to test a protected endpoint:

```bash
curl -X GET http://127.0.0.1:8000/api/v1/users/me/ \
  -H "Authorization: Bearer YOUR_ACCESS_TOKEN_HERE"
```

### 7.5 Run Django Tests (Optional)

Run the built-in Django test suite:

```bash
python manage.py test
```

---

## Troubleshooting

### Database Version Errors

**Error: `PostgreSQL 12 or later is required (found 11.19)`**

This error should NOT occur with this project, as we're using Django 3.2 LTS which supports PostgreSQL 11+.

**If you see this error:**
1. Verify you're using the correct requirements file: `pip install -r requirements/development.txt`
2. Check Django version: `python -m django --version` (should show 3.2.25)
3. If you see Django 4.x or 5.x, reinstall dependencies:
   ```bash
   pip install --upgrade -r requirements/development.txt
   ```

**If you want to upgrade PostgreSQL anyway (optional):**

**Windows:**
1. Download PostgreSQL from: https://www.postgresql.org/download/windows/
   - **Recommended:** PostgreSQL 15 or 16 (stable)
   - **Latest:** PostgreSQL 18 (newest features)
2. Run the installer
3. During installation:
   - Choose the same data directory (to preserve existing databases) OR
   - Choose a new data directory if you want a fresh install
   - Set a password for the postgres superuser
4. After installation, verify version:
   ```powershell
   psql --version
   ```
5. If you kept the same data directory, your existing databases should still be accessible
6. Restart the PostgreSQL service (replace XX with your version number):
   ```powershell
   Restart-Service postgresql-x64-XX
   # Examples:
   # Restart-Service postgresql-x64-15
   # Restart-Service postgresql-x64-16
   # Restart-Service postgresql-x64-18
   ```

**Installing PostgreSQL 18 specifically:**
- Download PostgreSQL 18 from: https://www.postgresql.org/download/windows/
- Or use EnterpriseDB installer: https://www.enterprisedb.com/downloads/postgres-postgresql-downloads
- Follow the same installation steps above

**Alternative: Use PostgreSQL 12+ alongside version 11**
- Install PostgreSQL 12+ to a different port (e.g., 5433)
- Update `.env` file: `DB_PORT=5433`
- Migrate your data if needed

**Mac (Homebrew):**
```bash
# Uninstall old version
brew uninstall postgresql@11

# Install PostgreSQL 15 (stable) or 18 (latest)
brew install postgresql@15
# OR
brew install postgresql@18

# Start new version
brew services start postgresql@15
# OR
brew services start postgresql@18
```

**Linux (Ubuntu/Debian):**
```bash
# Add PostgreSQL official repository
sudo sh -c 'echo "deb http://apt.postgresql.org/pub/repos/apt $(lsb_release -cs)-pgdg main" > /etc/apt/sources.list.d/pgdg.list'
wget --quiet -O - https://www.postgresql.org/media/keys/ACCC4CF8.asc | sudo apt-key add -
sudo apt-get update

# Install PostgreSQL 15 (stable) or 18 (latest)
sudo apt-get install postgresql-15
# OR
sudo apt-get install postgresql-18

# Start service
sudo systemctl start postgresql@15-main
# OR
sudo systemctl start postgresql@18-main
```

**Check your current PostgreSQL version:**
```bash
psql --version
```

### Database Connection Errors

**Error: `could not connect to server`**
- Verify PostgreSQL service is running (see Step 1.1 - Start PostgreSQL Server)
- Check `DB_HOST` and `DB_PORT` in `.env` (should be `localhost` and `5432`)
- Ensure firewall allows PostgreSQL connections
- On Windows: Check if PostgreSQL service is started in Services (services.msc)

**Error: `password authentication failed`**
- Verify username and password in `.env` are `tirupati` and `tirupati` (from Step 1.4)
- Try connecting manually:
  - **Windows:** `psql -U tirupati -d tirupati_impex_dev -h localhost`
  - **Mac/Linux:** `psql -U tirupati -d tirupati_impex_dev -h localhost`
- If password is not prompted when using psql, that's normal (trust authentication). Django will still use the password from `.env`

**Error: `database does not exist`**
- Verify database name in `.env` matches Step 1.3 (`tirupati_impex_dev`)
- Check database exists: `psql -U postgres -l`

### Migration Errors

**Error: `No changes detected`**
- Ensure all apps are in `INSTALLED_APPS` in `config/settings/base.py`
- Check app directories have `migrations` folder

**Error: `table already exists`**
- If starting fresh, you can reset: `python manage.py migrate --run-syncdb`
- Or drop and recreate database (Step 1.2)

### Import Errors

**Error: `ModuleNotFoundError`**
- Ensure virtual environment is activated
- Reinstall dependencies: `pip install -r requirements/development.txt`

**Error: `No module named 'apps'`**
- Ensure you're running commands from the `backend` directory
- Check `PYTHONPATH` includes the backend directory

### Port Already in Use

**Error: `That port is already in use`**
- Stop other Django servers running on port 8000
- Or use a different port: `python manage.py runserver 8001`

### Permission Errors (Linux/Mac)

**Error: `Permission denied`**
- Ensure you have read/write permissions in the project directory
- Check PostgreSQL user permissions (Step 1.4)

---

## Quick Reference Commands

```bash
# Activate virtual environment
# Windows: venv\Scripts\activate
# Linux/Mac: source venv/bin/activate

# Install dependencies
pip install -r requirements/development.txt

# Create migrations
python manage.py makemigrations

# Apply migrations
python manage.py migrate

# Create superuser
python manage.py createsuperuser

# Run server
python manage.py runserver

# Run tests
python manage.py test

# Django shell
python manage.py shell

# Check for issues
python manage.py check
```

---

## Project Structure

```
backend/
├── config/                 # Django project configuration
│   ├── settings/           # Environment-specific settings
│   ├── urls.py            # Main URL configuration
│   └── wsgi.py            # WSGI configuration
├── apps/                   # Django applications
│   ├── authentication/     # JWT authentication
│   ├── users/             # User and client models
│   ├── workers/           # Worker management
│   ├── jewels/           # Jewelry management
│   ├── jobs/             # Job workflow
│   ├── inventory/        # Inventory tracking
│   ├── sales/           # Sales management
│   └── notifications/   # Notification system
├── requirements/          # Python dependencies
├── media/                # Uploaded files (created automatically)
├── static/               # Static files (created automatically)
├── manage.py            # Django management script
├── .env                  # Environment variables (create from env.example)
└── README.md            # This file
```

---

## API Endpoints Overview

### Authentication
- `POST /api/v1/auth/register/client/` - Register new client
- `POST /api/v1/auth/login/` - Login
- `POST /api/v1/auth/refresh/` - Refresh JWT token
- `POST /api/v1/auth/logout/` - Logout

### Users
- `GET /api/v1/users/me/` - Get current user profile
- `PUT /api/v1/users/me/update/` - Update profile

### Workers (Client Only)
- `GET /api/v1/workers/` - List workers
- `POST /api/v1/workers/create/` - Create worker
- `GET /api/v1/workers/{id}/` - Get worker details

### Jewels
- `GET /api/v1/jewels/` - List jewels
- `POST /api/v1/jewels/create/` - Create jewel
- `GET /api/v1/jewels/{id}/` - Get jewel details

### Jobs
- `GET /api/v1/jobs/` - List jobs
- `POST /api/v1/jobs/create/` - Create job (Client)
- `POST /api/v1/jobs/{id}/accept/` - Accept job (Worker)

### Sales
- `GET /api/v1/sales/` - List sales
- `POST /api/v1/sales/create/` - Record sale

### Inventory
- `GET /api/v1/inventory/transactions/` - List transactions
- `POST /api/v1/inventory/add-metal/` - Add metal

### Notifications
- `GET /api/v1/notifications/` - List notifications
- `GET /api/v1/notifications/unread/` - Get unread notifications

### Dashboard
- `GET /api/v1/dashboard/summary/` - Dashboard summary
- `GET /api/v1/dashboard/jewels-by-stage/` - Jewels by stage

**Full API documentation:** See `tirupati-impex-complete-documentation.md` for complete endpoint list.

---

## Next Steps

1. **Frontend Integration:** Connect your React/React Native frontend to these APIs
2. **Production Deployment:** Configure production settings (see `config/settings/production.py`)
3. **Email/SMS Notifications:** Integrate email and SMS services
4. **WebSocket Support:** Enable real-time updates using Django Channels
5. **API Documentation:** Generate Swagger/OpenAPI documentation

---

## Support & Documentation

- **Complete System Documentation:** See `tirupati-impex-complete-documentation.md`
- **Django Documentation:** https://docs.djangoproject.com/
- **Django REST Framework:** https://www.django-rest-framework.org/

---

## License

This project is proprietary software developed for Tirupati Impex.

---

**Version:** 1.0.0  
**Last Updated:** 2024  
**Backend Status:** 100% Complete
