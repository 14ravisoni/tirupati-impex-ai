#!/bin/bash
# Test Runner Shell Script for Linux/Mac

echo "========================================"
echo "Tirupati Impex Backend - Test Runner"
echo "========================================"
echo ""

# Activate virtual environment if it exists
if [ -f "../venv/bin/activate" ]; then
    source ../venv/bin/activate
elif [ -f "venv/bin/activate" ]; then
    source venv/bin/activate
elif [ -f "../.venv/bin/activate" ]; then
    source ../.venv/bin/activate
fi

# Run the test script
python run_tests.py "$@"

echo ""
echo "========================================"
echo "Test execution completed"
echo "========================================"

