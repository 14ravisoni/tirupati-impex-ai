#!/usr/bin/env python
"""
Test Runner Script for Tirupati Impex Backend

This script runs all pytest tests and generates a comprehensive report.

Usage:
    python run_tests.py
    python run_tests.py --html    # Generate HTML report
    python run_tests.py --json    # Generate JSON report
    python run_tests.py --verbose # Verbose output
"""

import os
import sys
import json
import subprocess
import datetime
from pathlib import Path

# Add backend to path
BASE_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(BASE_DIR))


def run_tests(html_report=False, json_report=False, verbose=False):
    """Run all pytest tests and generate reports."""
    
    print("=" * 80)
    print("Tirupati Impex Backend - Test Suite Runner")
    print("=" * 80)
    print(f"Started at: {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print()
    
    # Build pytest command
    cmd = ['pytest']
    
    if verbose:
        cmd.append('-v')
    else:
        cmd.append('--tb=short')
    
    # Add coverage
    cmd.extend([
        '--cov=apps',
        '--cov-report=term-missing',
        '--cov-report=html:tests/output/htmlcov',
    ])
    
    if json_report:
        cmd.append('--cov-report=json:tests/output/coverage.json')
    
    # Add test paths
    cmd.extend(['tests'])
    
    print(f"Running command: {' '.join(cmd)}")
    print()
    print("-" * 80)
    
    # Run tests
    try:
        result = subprocess.run(
            cmd,
            cwd=BASE_DIR,
            capture_output=False,
            text=True
        )
        
        exit_code = result.returncode
        
    except Exception as e:
        print(f"Error running tests: {e}")
        exit_code = 1
    
    print("-" * 80)
    print()
    
    # Generate summary report
    generate_summary_report(exit_code, html_report, json_report)
    
    return exit_code


def generate_summary_report(exit_code, html_report, json_report):
    """Generate a summary report of test results."""
    
    # Ensure output directory exists
    output_dir = BASE_DIR / 'tests' / 'output'
    output_dir.mkdir(parents=True, exist_ok=True)
    
    report_file = output_dir / 'test_report.txt'
    json_report_file = output_dir / 'test_report.json'
    
    # Count tests from documentation
    total_tests = 60  # From TEST_DOCUMENTATION
    
    summary = {
        'timestamp': datetime.datetime.now().isoformat(),
        'exit_code': exit_code,
        'status': 'PASSED' if exit_code == 0 else 'FAILED',
        'total_tests': total_tests,
        'test_categories': {
            'authentication': 9,
            'users': 4,
            'workers': 8,
            'jewels': 9,
            'jobs': 9,
            'inventory': 7,
            'sales': 6,
            'notifications': 5
        },
        'reports_generated': {
            'html': html_report or True,  # HTML is always generated
            'json': json_report,
            'text': True
        }
    }
    
    # Write text report
    with open(report_file, 'w') as f:
        f.write("=" * 80 + "\n")
        f.write("Tirupati Impex Backend - Test Report\n")
        f.write("=" * 80 + "\n")
        f.write(f"Generated at: {summary['timestamp']}\n")
        f.write(f"Status: {summary['status']}\n")
        f.write(f"Exit Code: {exit_code}\n")
        f.write(f"Total Tests: {summary['total_tests']}\n")
        f.write("\n")
        f.write("Test Categories:\n")
        for category, count in summary['test_categories'].items():
            f.write(f"  - {category.capitalize()}: {count} tests\n")
        f.write("\n")
        f.write("Reports Generated:\n")
        f.write(f"  - HTML Coverage Report: tests/output/htmlcov/index.html\n")
        if json_report:
            f.write(f"  - JSON Coverage Report: tests/output/coverage.json\n")
        f.write(f"  - Text Report: tests/output/test_report.txt\n")
        f.write(f"  - JSON Summary: tests/output/test_report.json\n")
        f.write("\n")
        f.write("=" * 80 + "\n")
        f.write("\n")
        f.write("To view detailed test results, run:\n")
        f.write("  pytest -v tests\n")
        f.write("\n")
        f.write("To view HTML coverage report:\n")
        f.write("  Open tests/output/htmlcov/index.html in your browser\n")
        f.write("\n")
        f.write("Test Documentation:\n")
        f.write("  - tests/documentation/TEST_DOCUMENTATION.md - Detailed test documentation\n")
        f.write("  - tests/documentation/TEST_DOCUMENTATION.csv - Test list in CSV format (can be opened in Excel)\n")
        f.write("  - tests/documentation/TEST_README.md - Testing guide\n")
    
    # Write JSON report
    with open(json_report_file, 'w') as f:
        json.dump(summary, f, indent=2)
    
    print("=" * 80)
    print("Test Report Summary")
    print("=" * 80)
    print(f"Status: {summary['status']}")
    print(f"Exit Code: {exit_code}")
    print(f"Total Tests: {summary['total_tests']}")
    print()
    print("Test Categories:")
    for category, count in summary['test_categories'].items():
        print(f"  - {category.capitalize()}: {count} tests")
    print()
    print("Reports Generated:")
    print(f"  ✓ Text Report: {report_file}")
    print(f"  ✓ JSON Report: {json_report_file}")
    print(f"  ✓ HTML Coverage: tests/output/htmlcov/index.html")
    if json_report:
        print(f"  ✓ JSON Coverage: tests/output/coverage.json")
    print()
    print("Test Documentation:")
    print("  - tests/documentation/TEST_DOCUMENTATION.md")
    print("  - tests/documentation/TEST_DOCUMENTATION.csv (can be opened in Excel)")
    print("  - tests/documentation/TEST_README.md")
    print()
    print("=" * 80)


if __name__ == '__main__':
    import argparse
    
    parser = argparse.ArgumentParser(description='Run all tests and generate reports')
    parser.add_argument('--html', action='store_true', help='Generate HTML report (always generated)')
    parser.add_argument('--json', action='store_true', help='Generate JSON coverage report')
    parser.add_argument('--verbose', '-v', action='store_true', help='Verbose output')
    
    args = parser.parse_args()
    
    exit_code = run_tests(
        html_report=args.html,
        json_report=args.json,
        verbose=args.verbose
    )
    
    sys.exit(exit_code)
